﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMain))
        Me.tbcControls1 = New System.Windows.Forms.TabControl()
        Me.tbpBanks = New System.Windows.Forms.TabPage()
        Me.lstBanks = New System.Windows.Forms.ListBox()
        Me.cmdBankDelete = New System.Windows.Forms.Button()
        Me.cmdBankRename = New System.Windows.Forms.Button()
        Me.cmdBankNew = New System.Windows.Forms.Button()
        Me.tbpPresets = New System.Windows.Forms.TabPage()
        Me.lstPresetsSongChanges2 = New System.Windows.Forms.ListBox()
        Me.cmdPresetsSkip2 = New System.Windows.Forms.Button()
        Me.cmdPresetsSkip = New System.Windows.Forms.Button()
        Me.lblPresetsMP3PositionMilli2 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.lblPresetsMP3Position2 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.lblPresetsMP3Duration2 = New System.Windows.Forms.Label()
        Me.cmdPresetsStop2 = New System.Windows.Forms.Button()
        Me.cmdPresetsPlay2 = New System.Windows.Forms.Button()
        Me.trkPresetsVolume2 = New System.Windows.Forms.TrackBar()
        Me.lstPresetsSongs2 = New System.Windows.Forms.ListBox()
        Me.lblPresetsMP3PositionMilli = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.lblPresetsMP3Position = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.lblPresetsMP3Duration = New System.Windows.Forms.Label()
        Me.cmdPresetsStop = New System.Windows.Forms.Button()
        Me.cmdPresetsPlay = New System.Windows.Forms.Button()
        Me.lstPresetsSongs = New System.Windows.Forms.ListBox()
        Me.lstPresetsSongChanges = New System.Windows.Forms.ListBox()
        Me.trkPresetsVolume = New System.Windows.Forms.TrackBar()
        Me.cmdReloadPresetLocations = New System.Windows.Forms.Button()
        Me.cmdPresetP7 = New System.Windows.Forms.Button()
        Me.cmdPresetP8 = New System.Windows.Forms.Button()
        Me.cmdPresetP5 = New System.Windows.Forms.Button()
        Me.cmdPresetP6 = New System.Windows.Forms.Button()
        Me.cmdPresetP3 = New System.Windows.Forms.Button()
        Me.cmdPresetP4 = New System.Windows.Forms.Button()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.cmdPresetsBlackoutAllInstant = New System.Windows.Forms.Button()
        Me.cmdPresetsBlackoutAllTimer = New System.Windows.Forms.Button()
        Me.cmdPresetP1 = New System.Windows.Forms.Button()
        Me.cmdPresetP2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.tbpChannels = New System.Windows.Forms.TabPage()
        Me.cmdChannelsSave = New System.Windows.Forms.Button()
        Me.cmbChannelPresetSelection = New System.Windows.Forms.ComboBox()
        Me.cmdReloadChannelLocations = New System.Windows.Forms.Button()
        Me.cmdChannelFadersDown = New System.Windows.Forms.Button()
        Me.cmdChannelFadersUp = New System.Windows.Forms.Button()
        Me.numChannelFadersStart = New System.Windows.Forms.NumericUpDown()
        Me.tbpMusic = New System.Windows.Forms.TabPage()
        Me.CustomWaves1 = New Super_Awesome_Lighting_DMX_board_v4.CustomWaves()
        Me.cmdEditUpdate = New System.Windows.Forms.Button()
        Me.txtEditTime = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.chkRecordspace = New System.Windows.Forms.CheckBox()
        Me.numFadeIn = New System.Windows.Forms.NumericUpDown()
        Me.lblFadeIn = New System.Windows.Forms.Label()
        Me.numFadeOut = New System.Windows.Forms.NumericUpDown()
        Me.lblFadeOut = New System.Windows.Forms.Label()
        Me.vSongEdit = New Super_Awesome_Lighting_DMX_board_v4.GScrollBar()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.lstSongEditPresets = New System.Windows.Forms.ListBox()
        Me.cmdEditSongCopyNew = New System.Windows.Forms.Button()
        Me.cmdEditSongSave = New System.Windows.Forms.Button()
        Me.cmdCreatelink = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lbleditRemaining = New System.Windows.Forms.Label()
        Me.lbleditPositionMilli = New System.Windows.Forms.Label()
        Me.lbleditposition = New System.Windows.Forms.Label()
        Me.cmdEditStop = New System.Windows.Forms.Button()
        Me.cmdEditPlay = New System.Windows.Forms.Button()
        Me.chkEnableSongEdit = New System.Windows.Forms.CheckBox()
        Me.lstMusicSongChanges2 = New System.Windows.Forms.ListBox()
        Me.cmdMusicSkip2 = New System.Windows.Forms.Button()
        Me.cmdMusicSkip = New System.Windows.Forms.Button()
        Me.lblMusicMP3PositionMilli2 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblMusicMP3Position2 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblMusicMP3Duration2 = New System.Windows.Forms.Label()
        Me.cmdMusicStop2 = New System.Windows.Forms.Button()
        Me.cmdMusicPlay2 = New System.Windows.Forms.Button()
        Me.trkMusicVolume2 = New System.Windows.Forms.TrackBar()
        Me.lstMusicSongs2 = New System.Windows.Forms.ListBox()
        Me.lblMusicMP3PositionMilli = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblMusicMP3Position = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblMusicMP3Duration = New System.Windows.Forms.Label()
        Me.cmdMusicStop = New System.Windows.Forms.Button()
        Me.cmdMusicPlay = New System.Windows.Forms.Button()
        Me.lstMusicSongs = New System.Windows.Forms.ListBox()
        Me.lstMusicSongChanges = New System.Windows.Forms.ListBox()
        Me.trkMusicVolume = New System.Windows.Forms.TrackBar()
        Me.tbpDramaChanges = New System.Windows.Forms.TabPage()
        Me.cmdDramaBlackoutAllInstant = New System.Windows.Forms.Button()
        Me.cmdDramaBlackoutAllTimer = New System.Windows.Forms.Button()
        Me.lstDramaPresets = New System.Windows.Forms.ListBox()
        Me.lstDramaViewSongChanges2 = New System.Windows.Forms.ListBox()
        Me.cmdDramaViewSkip2 = New System.Windows.Forms.Button()
        Me.cmdDramaViewSkip = New System.Windows.Forms.Button()
        Me.lblDramaViewMP3PositionMilli2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblDramaViewMP3Position2 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lblDramaViewMP3Duration2 = New System.Windows.Forms.Label()
        Me.cmdDramaViewStop2 = New System.Windows.Forms.Button()
        Me.cmdDramaViewPlay2 = New System.Windows.Forms.Button()
        Me.trkDramaViewVolume2 = New System.Windows.Forms.TrackBar()
        Me.lstDramaViewSongs2 = New System.Windows.Forms.ListBox()
        Me.lblDramaViewMP3PositionMilli = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.lblDramaViewMP3Position = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.lblDramaViewMP3Duration = New System.Windows.Forms.Label()
        Me.cmdDramaViewStop = New System.Windows.Forms.Button()
        Me.cmdDramaViewPlay = New System.Windows.Forms.Button()
        Me.lstDramaViewSongs = New System.Windows.Forms.ListBox()
        Me.lstDramaViewSongChanges = New System.Windows.Forms.ListBox()
        Me.trkDramaViewVolume = New System.Windows.Forms.TrackBar()
        Me.tbpSettings = New System.Windows.Forms.TabPage()
        Me.lblArduino1 = New System.Windows.Forms.Label()
        Me.cmdSaveSettings = New System.Windows.Forms.Button()
        Me.lblSceneLabelColour = New System.Windows.Forms.Label()
        Me.cmdSceneLabelColour = New System.Windows.Forms.Button()
        Me.cmdSerialClear = New System.Windows.Forms.Button()
        Me.lblUpDownTest = New System.Windows.Forms.Label()
        Me.txtSerialIn = New System.Windows.Forms.TextBox()
        Me.lblChannelNumberColour = New System.Windows.Forms.Label()
        Me.cmdChannelNumberColour = New System.Windows.Forms.Button()
        Me.lblSceneFillColour = New System.Windows.Forms.Label()
        Me.lblSceneUpColour = New System.Windows.Forms.Label()
        Me.lblSceneBlackoutColour = New System.Windows.Forms.Label()
        Me.cmdSceneFillColour = New System.Windows.Forms.Button()
        Me.cmdSceneUpColour = New System.Windows.Forms.Button()
        Me.cmdSceneBlackoutColour = New System.Windows.Forms.Button()
        Me.lblChannelFillColour = New System.Windows.Forms.Label()
        Me.lblChannelBackColour = New System.Windows.Forms.Label()
        Me.lblChannelBulletColour = New System.Windows.Forms.Label()
        Me.cmdChannelFillColour = New System.Windows.Forms.Button()
        Me.cmdChannelBackColour = New System.Windows.Forms.Button()
        Me.cmdChannelBulletColour = New System.Windows.Forms.Button()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.chkLoadonChange = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.numEndChannel = New System.Windows.Forms.NumericUpDown()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.numChangeMS = New System.Windows.Forms.NumericUpDown()
        Me.cmdMasterFull = New System.Windows.Forms.Button()
        Me.cmdMasterBlackout = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtMaster = New System.Windows.Forms.TextBox()
        Me.cmdOpenTouchpad = New System.Windows.Forms.Button()
        Me.cmdSelectedFull = New System.Windows.Forms.Button()
        Me.cmdSelectedBlackout = New System.Windows.Forms.Button()
        Me.txtSelected = New System.Windows.Forms.TextBox()
        Me.tmrMP3 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrMP32 = New System.Windows.Forms.Timer(Me.components)
        Me.ctxCMDs = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ctxDimmerAutomation = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ctxNameofbutton = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmd4KSize = New System.Windows.Forms.Button()
        Me.chkEditMode = New System.Windows.Forms.CheckBox()
        Me.ctxPresetLabelActions = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ctxPresetLabelEditChannels = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxPresetRenameScene = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ctxPresetLabelName = New System.Windows.Forms.ToolStripMenuItem()
        Me.tmrMaster = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdColourTest = New System.Windows.Forms.Button()
        Me.ctxFixtureLabels = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ctxPickRGBColourTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxFixtureFavourites = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ctxFixtureLabelsControlName = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.lblAudioActive = New System.Windows.Forms.Label()
        Me.vsSelected = New Super_Awesome_Lighting_DMX_board_v4.GScrollBar()
        Me.vsMaster = New Super_Awesome_Lighting_DMX_board_v4.GScrollBar()
        Me.tbcControls1.SuspendLayout()
        Me.tbpBanks.SuspendLayout()
        Me.tbpPresets.SuspendLayout()
        CType(Me.trkPresetsVolume2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkPresetsVolume, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbpChannels.SuspendLayout()
        CType(Me.numChannelFadersStart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbpMusic.SuspendLayout()
        CType(Me.numFadeIn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numFadeOut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkMusicVolume2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkMusicVolume, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbpDramaChanges.SuspendLayout()
        CType(Me.trkDramaViewVolume2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkDramaViewVolume, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbpSettings.SuspendLayout()
        CType(Me.numEndChannel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numChangeMS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ctxCMDs.SuspendLayout()
        Me.ctxPresetLabelActions.SuspendLayout()
        Me.ctxFixtureLabels.SuspendLayout()
        Me.SuspendLayout()
        '
        'tbcControls1
        '
        Me.tbcControls1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbcControls1.Controls.Add(Me.tbpBanks)
        Me.tbcControls1.Controls.Add(Me.tbpPresets)
        Me.tbcControls1.Controls.Add(Me.tbpChannels)
        Me.tbcControls1.Controls.Add(Me.tbpMusic)
        Me.tbcControls1.Controls.Add(Me.tbpDramaChanges)
        Me.tbcControls1.Controls.Add(Me.tbpSettings)
        Me.tbcControls1.Location = New System.Drawing.Point(0, 22)
        Me.tbcControls1.Name = "tbcControls1"
        Me.tbcControls1.SelectedIndex = 0
        Me.tbcControls1.Size = New System.Drawing.Size(1834, 953)
        Me.tbcControls1.TabIndex = 0
        '
        'tbpBanks
        '
        Me.tbpBanks.Controls.Add(Me.lstBanks)
        Me.tbpBanks.Controls.Add(Me.cmdBankDelete)
        Me.tbpBanks.Controls.Add(Me.cmdBankRename)
        Me.tbpBanks.Controls.Add(Me.cmdBankNew)
        Me.tbpBanks.Location = New System.Drawing.Point(4, 22)
        Me.tbpBanks.Name = "tbpBanks"
        Me.tbpBanks.Size = New System.Drawing.Size(1826, 927)
        Me.tbpBanks.TabIndex = 5
        Me.tbpBanks.Text = "Banks"
        Me.tbpBanks.UseVisualStyleBackColor = True
        '
        'lstBanks
        '
        Me.lstBanks.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstBanks.FormattingEnabled = True
        Me.lstBanks.Location = New System.Drawing.Point(8, 13)
        Me.lstBanks.Name = "lstBanks"
        Me.lstBanks.Size = New System.Drawing.Size(196, 472)
        Me.lstBanks.TabIndex = 253
        '
        'cmdBankDelete
        '
        Me.cmdBankDelete.Enabled = False
        Me.cmdBankDelete.ForeColor = System.Drawing.Color.White
        Me.cmdBankDelete.Location = New System.Drawing.Point(476, 13)
        Me.cmdBankDelete.Name = "cmdBankDelete"
        Me.cmdBankDelete.Size = New System.Drawing.Size(36, 23)
        Me.cmdBankDelete.TabIndex = 252
        Me.cmdBankDelete.Text = "Del"
        Me.cmdBankDelete.UseVisualStyleBackColor = True
        Me.cmdBankDelete.Visible = False
        '
        'cmdBankRename
        '
        Me.cmdBankRename.Location = New System.Drawing.Point(406, 13)
        Me.cmdBankRename.Name = "cmdBankRename"
        Me.cmdBankRename.Size = New System.Drawing.Size(64, 23)
        Me.cmdBankRename.TabIndex = 251
        Me.cmdBankRename.Text = "Rename"
        Me.cmdBankRename.UseVisualStyleBackColor = True
        '
        'cmdBankNew
        '
        Me.cmdBankNew.Location = New System.Drawing.Point(300, 13)
        Me.cmdBankNew.Name = "cmdBankNew"
        Me.cmdBankNew.Size = New System.Drawing.Size(100, 23)
        Me.cmdBankNew.TabIndex = 250
        Me.cmdBankNew.Text = "New Bank"
        Me.cmdBankNew.UseVisualStyleBackColor = True
        '
        'tbpPresets
        '
        Me.tbpPresets.Controls.Add(Me.lstPresetsSongChanges2)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsSkip2)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsSkip)
        Me.tbpPresets.Controls.Add(Me.lblPresetsMP3PositionMilli2)
        Me.tbpPresets.Controls.Add(Me.Label40)
        Me.tbpPresets.Controls.Add(Me.lblPresetsMP3Position2)
        Me.tbpPresets.Controls.Add(Me.Label42)
        Me.tbpPresets.Controls.Add(Me.lblPresetsMP3Duration2)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsStop2)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsPlay2)
        Me.tbpPresets.Controls.Add(Me.trkPresetsVolume2)
        Me.tbpPresets.Controls.Add(Me.lstPresetsSongs2)
        Me.tbpPresets.Controls.Add(Me.lblPresetsMP3PositionMilli)
        Me.tbpPresets.Controls.Add(Me.Label45)
        Me.tbpPresets.Controls.Add(Me.lblPresetsMP3Position)
        Me.tbpPresets.Controls.Add(Me.Label47)
        Me.tbpPresets.Controls.Add(Me.lblPresetsMP3Duration)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsStop)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsPlay)
        Me.tbpPresets.Controls.Add(Me.lstPresetsSongs)
        Me.tbpPresets.Controls.Add(Me.lstPresetsSongChanges)
        Me.tbpPresets.Controls.Add(Me.trkPresetsVolume)
        Me.tbpPresets.Controls.Add(Me.cmdReloadPresetLocations)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP7)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP8)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP5)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP6)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP3)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP4)
        Me.tbpPresets.Controls.Add(Me.NumericUpDown2)
        Me.tbpPresets.Controls.Add(Me.NumericUpDown1)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsBlackoutAllInstant)
        Me.tbpPresets.Controls.Add(Me.cmdPresetsBlackoutAllTimer)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP1)
        Me.tbpPresets.Controls.Add(Me.cmdPresetP2)
        Me.tbpPresets.Controls.Add(Me.Button3)
        Me.tbpPresets.Controls.Add(Me.Button4)
        Me.tbpPresets.Controls.Add(Me.Label8)
        Me.tbpPresets.Controls.Add(Me.TextBox2)
        Me.tbpPresets.Controls.Add(Me.Button1)
        Me.tbpPresets.Controls.Add(Me.Button2)
        Me.tbpPresets.Controls.Add(Me.Label7)
        Me.tbpPresets.Controls.Add(Me.TextBox1)
        Me.tbpPresets.Location = New System.Drawing.Point(4, 22)
        Me.tbpPresets.Name = "tbpPresets"
        Me.tbpPresets.Padding = New System.Windows.Forms.Padding(3)
        Me.tbpPresets.Size = New System.Drawing.Size(1826, 927)
        Me.tbpPresets.TabIndex = 1
        Me.tbpPresets.Text = "Scenes"
        Me.tbpPresets.UseVisualStyleBackColor = True
        '
        'lstPresetsSongChanges2
        '
        Me.lstPresetsSongChanges2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstPresetsSongChanges2.FormattingEnabled = True
        Me.lstPresetsSongChanges2.Location = New System.Drawing.Point(1073, 720)
        Me.lstPresetsSongChanges2.Name = "lstPresetsSongChanges2"
        Me.lstPresetsSongChanges2.Size = New System.Drawing.Size(231, 199)
        Me.lstPresetsSongChanges2.TabIndex = 625
        '
        'cmdPresetsSkip2
        '
        Me.cmdPresetsSkip2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsSkip2.Location = New System.Drawing.Point(948, 811)
        Me.cmdPresetsSkip2.Name = "cmdPresetsSkip2"
        Me.cmdPresetsSkip2.Size = New System.Drawing.Size(37, 23)
        Me.cmdPresetsSkip2.TabIndex = 624
        Me.cmdPresetsSkip2.Text = "Skip"
        Me.cmdPresetsSkip2.UseVisualStyleBackColor = True
        '
        'cmdPresetsSkip
        '
        Me.cmdPresetsSkip.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsSkip.Location = New System.Drawing.Point(297, 810)
        Me.cmdPresetsSkip.Name = "cmdPresetsSkip"
        Me.cmdPresetsSkip.Size = New System.Drawing.Size(37, 23)
        Me.cmdPresetsSkip.TabIndex = 623
        Me.cmdPresetsSkip.Text = "Skip"
        Me.cmdPresetsSkip.UseVisualStyleBackColor = True
        '
        'lblPresetsMP3PositionMilli2
        '
        Me.lblPresetsMP3PositionMilli2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPresetsMP3PositionMilli2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPresetsMP3PositionMilli2.ForeColor = System.Drawing.Color.Lime
        Me.lblPresetsMP3PositionMilli2.Location = New System.Drawing.Point(944, 871)
        Me.lblPresetsMP3PositionMilli2.Name = "lblPresetsMP3PositionMilli2"
        Me.lblPresetsMP3PositionMilli2.Size = New System.Drawing.Size(71, 20)
        Me.lblPresetsMP3PositionMilli2.TabIndex = 621
        Me.lblPresetsMP3PositionMilli2.Text = "000000"
        '
        'Label40
        '
        Me.Label40.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Lime
        Me.Label40.Location = New System.Drawing.Point(945, 835)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(47, 13)
        Me.Label40.TabIndex = 620
        Me.Label40.Text = "Position:"
        '
        'lblPresetsMP3Position2
        '
        Me.lblPresetsMP3Position2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPresetsMP3Position2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPresetsMP3Position2.ForeColor = System.Drawing.Color.Lime
        Me.lblPresetsMP3Position2.Location = New System.Drawing.Point(944, 851)
        Me.lblPresetsMP3Position2.Name = "lblPresetsMP3Position2"
        Me.lblPresetsMP3Position2.Size = New System.Drawing.Size(71, 20)
        Me.lblPresetsMP3Position2.TabIndex = 619
        Me.lblPresetsMP3Position2.Text = "00:00.00"
        '
        'Label42
        '
        Me.Label42.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Lime
        Me.Label42.Location = New System.Drawing.Point(945, 775)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(50, 13)
        Me.Label42.TabIndex = 618
        Me.Label42.Text = "Duration:"
        '
        'lblPresetsMP3Duration2
        '
        Me.lblPresetsMP3Duration2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPresetsMP3Duration2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPresetsMP3Duration2.ForeColor = System.Drawing.Color.Lime
        Me.lblPresetsMP3Duration2.Location = New System.Drawing.Point(944, 791)
        Me.lblPresetsMP3Duration2.Name = "lblPresetsMP3Duration2"
        Me.lblPresetsMP3Duration2.Size = New System.Drawing.Size(71, 20)
        Me.lblPresetsMP3Duration2.TabIndex = 617
        Me.lblPresetsMP3Duration2.Text = "00:00:00"
        '
        'cmdPresetsStop2
        '
        Me.cmdPresetsStop2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsStop2.Location = New System.Drawing.Point(948, 751)
        Me.cmdPresetsStop2.Name = "cmdPresetsStop2"
        Me.cmdPresetsStop2.Size = New System.Drawing.Size(75, 23)
        Me.cmdPresetsStop2.TabIndex = 616
        Me.cmdPresetsStop2.Text = "Stop"
        Me.cmdPresetsStop2.UseVisualStyleBackColor = True
        '
        'cmdPresetsPlay2
        '
        Me.cmdPresetsPlay2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsPlay2.Location = New System.Drawing.Point(948, 722)
        Me.cmdPresetsPlay2.Name = "cmdPresetsPlay2"
        Me.cmdPresetsPlay2.Size = New System.Drawing.Size(75, 23)
        Me.cmdPresetsPlay2.TabIndex = 615
        Me.cmdPresetsPlay2.Text = "Play"
        Me.cmdPresetsPlay2.UseVisualStyleBackColor = True
        '
        'trkPresetsVolume2
        '
        Me.trkPresetsVolume2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.trkPresetsVolume2.Location = New System.Drawing.Point(1018, 791)
        Me.trkPresetsVolume2.Maximum = 100
        Me.trkPresetsVolume2.Name = "trkPresetsVolume2"
        Me.trkPresetsVolume2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.trkPresetsVolume2.Size = New System.Drawing.Size(45, 71)
        Me.trkPresetsVolume2.TabIndex = 622
        Me.trkPresetsVolume2.TickFrequency = 0
        Me.trkPresetsVolume2.Value = 100
        '
        'lstPresetsSongs2
        '
        Me.lstPresetsSongs2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstPresetsSongs2.FormattingEnabled = True
        Me.lstPresetsSongs2.Location = New System.Drawing.Point(659, 722)
        Me.lstPresetsSongs2.Name = "lstPresetsSongs2"
        Me.lstPresetsSongs2.Size = New System.Drawing.Size(283, 199)
        Me.lstPresetsSongs2.TabIndex = 614
        '
        'lblPresetsMP3PositionMilli
        '
        Me.lblPresetsMP3PositionMilli.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPresetsMP3PositionMilli.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPresetsMP3PositionMilli.ForeColor = System.Drawing.Color.Lime
        Me.lblPresetsMP3PositionMilli.Location = New System.Drawing.Point(293, 871)
        Me.lblPresetsMP3PositionMilli.Name = "lblPresetsMP3PositionMilli"
        Me.lblPresetsMP3PositionMilli.Size = New System.Drawing.Size(71, 20)
        Me.lblPresetsMP3PositionMilli.TabIndex = 611
        Me.lblPresetsMP3PositionMilli.Text = "000000"
        '
        'Label45
        '
        Me.Label45.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Lime
        Me.Label45.Location = New System.Drawing.Point(294, 835)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(47, 13)
        Me.Label45.TabIndex = 610
        Me.Label45.Text = "Position:"
        '
        'lblPresetsMP3Position
        '
        Me.lblPresetsMP3Position.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPresetsMP3Position.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPresetsMP3Position.ForeColor = System.Drawing.Color.Lime
        Me.lblPresetsMP3Position.Location = New System.Drawing.Point(293, 851)
        Me.lblPresetsMP3Position.Name = "lblPresetsMP3Position"
        Me.lblPresetsMP3Position.Size = New System.Drawing.Size(71, 20)
        Me.lblPresetsMP3Position.TabIndex = 609
        Me.lblPresetsMP3Position.Text = "00:00.00"
        '
        'Label47
        '
        Me.Label47.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Lime
        Me.Label47.Location = New System.Drawing.Point(294, 775)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(50, 13)
        Me.Label47.TabIndex = 608
        Me.Label47.Text = "Duration:"
        '
        'lblPresetsMP3Duration
        '
        Me.lblPresetsMP3Duration.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPresetsMP3Duration.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPresetsMP3Duration.ForeColor = System.Drawing.Color.Lime
        Me.lblPresetsMP3Duration.Location = New System.Drawing.Point(293, 791)
        Me.lblPresetsMP3Duration.Name = "lblPresetsMP3Duration"
        Me.lblPresetsMP3Duration.Size = New System.Drawing.Size(71, 20)
        Me.lblPresetsMP3Duration.TabIndex = 607
        Me.lblPresetsMP3Duration.Text = "00:00:00"
        '
        'cmdPresetsStop
        '
        Me.cmdPresetsStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsStop.Location = New System.Drawing.Point(297, 751)
        Me.cmdPresetsStop.Name = "cmdPresetsStop"
        Me.cmdPresetsStop.Size = New System.Drawing.Size(75, 23)
        Me.cmdPresetsStop.TabIndex = 606
        Me.cmdPresetsStop.Text = "Stop"
        Me.cmdPresetsStop.UseVisualStyleBackColor = True
        '
        'cmdPresetsPlay
        '
        Me.cmdPresetsPlay.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsPlay.Location = New System.Drawing.Point(297, 722)
        Me.cmdPresetsPlay.Name = "cmdPresetsPlay"
        Me.cmdPresetsPlay.Size = New System.Drawing.Size(75, 23)
        Me.cmdPresetsPlay.TabIndex = 605
        Me.cmdPresetsPlay.Text = "Play"
        Me.cmdPresetsPlay.UseVisualStyleBackColor = True
        '
        'lstPresetsSongs
        '
        Me.lstPresetsSongs.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstPresetsSongs.FormattingEnabled = True
        Me.lstPresetsSongs.Location = New System.Drawing.Point(8, 722)
        Me.lstPresetsSongs.Name = "lstPresetsSongs"
        Me.lstPresetsSongs.Size = New System.Drawing.Size(283, 199)
        Me.lstPresetsSongs.TabIndex = 604
        '
        'lstPresetsSongChanges
        '
        Me.lstPresetsSongChanges.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstPresetsSongChanges.FormattingEnabled = True
        Me.lstPresetsSongChanges.Location = New System.Drawing.Point(422, 722)
        Me.lstPresetsSongChanges.Name = "lstPresetsSongChanges"
        Me.lstPresetsSongChanges.Size = New System.Drawing.Size(231, 199)
        Me.lstPresetsSongChanges.TabIndex = 612
        '
        'trkPresetsVolume
        '
        Me.trkPresetsVolume.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.trkPresetsVolume.Location = New System.Drawing.Point(367, 791)
        Me.trkPresetsVolume.Maximum = 100
        Me.trkPresetsVolume.Name = "trkPresetsVolume"
        Me.trkPresetsVolume.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.trkPresetsVolume.Size = New System.Drawing.Size(45, 71)
        Me.trkPresetsVolume.TabIndex = 613
        Me.trkPresetsVolume.TickFrequency = 0
        Me.trkPresetsVolume.Value = 100
        '
        'cmdReloadPresetLocations
        '
        Me.cmdReloadPresetLocations.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdReloadPresetLocations.Location = New System.Drawing.Point(1730, 383)
        Me.cmdReloadPresetLocations.Name = "cmdReloadPresetLocations"
        Me.cmdReloadPresetLocations.Size = New System.Drawing.Size(90, 35)
        Me.cmdReloadPresetLocations.TabIndex = 603
        Me.cmdReloadPresetLocations.Text = "Reload Locations"
        Me.cmdReloadPresetLocations.UseVisualStyleBackColor = True
        '
        'cmdPresetP7
        '
        Me.cmdPresetP7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP7.Location = New System.Drawing.Point(1730, 95)
        Me.cmdPresetP7.Name = "cmdPresetP7"
        Me.cmdPresetP7.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP7.TabIndex = 597
        Me.cmdPresetP7.Text = "P7"
        Me.cmdPresetP7.UseVisualStyleBackColor = True
        Me.cmdPresetP7.Visible = False
        '
        'cmdPresetP8
        '
        Me.cmdPresetP8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP8.Location = New System.Drawing.Point(1781, 95)
        Me.cmdPresetP8.Name = "cmdPresetP8"
        Me.cmdPresetP8.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP8.TabIndex = 596
        Me.cmdPresetP8.Text = "P8"
        Me.cmdPresetP8.UseVisualStyleBackColor = True
        Me.cmdPresetP8.Visible = False
        '
        'cmdPresetP5
        '
        Me.cmdPresetP5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP5.Location = New System.Drawing.Point(1730, 66)
        Me.cmdPresetP5.Name = "cmdPresetP5"
        Me.cmdPresetP5.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP5.TabIndex = 595
        Me.cmdPresetP5.Text = "P5"
        Me.cmdPresetP5.UseVisualStyleBackColor = True
        '
        'cmdPresetP6
        '
        Me.cmdPresetP6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP6.Location = New System.Drawing.Point(1781, 66)
        Me.cmdPresetP6.Name = "cmdPresetP6"
        Me.cmdPresetP6.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP6.TabIndex = 594
        Me.cmdPresetP6.Text = "P6"
        Me.cmdPresetP6.UseVisualStyleBackColor = True
        Me.cmdPresetP6.Visible = False
        '
        'cmdPresetP3
        '
        Me.cmdPresetP3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP3.Location = New System.Drawing.Point(1730, 37)
        Me.cmdPresetP3.Name = "cmdPresetP3"
        Me.cmdPresetP3.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP3.TabIndex = 593
        Me.cmdPresetP3.Text = "P3"
        Me.cmdPresetP3.UseVisualStyleBackColor = True
        '
        'cmdPresetP4
        '
        Me.cmdPresetP4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP4.Location = New System.Drawing.Point(1781, 37)
        Me.cmdPresetP4.Name = "cmdPresetP4"
        Me.cmdPresetP4.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP4.TabIndex = 592
        Me.cmdPresetP4.Text = "P4"
        Me.cmdPresetP4.UseVisualStyleBackColor = True
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Location = New System.Drawing.Point(127, 78)
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(45, 20)
        Me.NumericUpDown2.TabIndex = 573
        Me.NumericUpDown2.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown2.Visible = False
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(127, 29)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(45, 20)
        Me.NumericUpDown1.TabIndex = 572
        Me.NumericUpDown1.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown1.Visible = False
        '
        'cmdPresetsBlackoutAllInstant
        '
        Me.cmdPresetsBlackoutAllInstant.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsBlackoutAllInstant.Location = New System.Drawing.Point(1730, 189)
        Me.cmdPresetsBlackoutAllInstant.Name = "cmdPresetsBlackoutAllInstant"
        Me.cmdPresetsBlackoutAllInstant.Size = New System.Drawing.Size(90, 45)
        Me.cmdPresetsBlackoutAllInstant.TabIndex = 571
        Me.cmdPresetsBlackoutAllInstant.Text = "Blackout All Instant"
        Me.cmdPresetsBlackoutAllInstant.UseVisualStyleBackColor = True
        '
        'cmdPresetsBlackoutAllTimer
        '
        Me.cmdPresetsBlackoutAllTimer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetsBlackoutAllTimer.Location = New System.Drawing.Point(1730, 138)
        Me.cmdPresetsBlackoutAllTimer.Name = "cmdPresetsBlackoutAllTimer"
        Me.cmdPresetsBlackoutAllTimer.Size = New System.Drawing.Size(90, 45)
        Me.cmdPresetsBlackoutAllTimer.TabIndex = 570
        Me.cmdPresetsBlackoutAllTimer.Text = "Blackout All Timer"
        Me.cmdPresetsBlackoutAllTimer.UseVisualStyleBackColor = True
        '
        'cmdPresetP1
        '
        Me.cmdPresetP1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP1.BackColor = System.Drawing.Color.Red
        Me.cmdPresetP1.ForeColor = System.Drawing.Color.White
        Me.cmdPresetP1.Location = New System.Drawing.Point(1730, 8)
        Me.cmdPresetP1.Name = "cmdPresetP1"
        Me.cmdPresetP1.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP1.TabIndex = 569
        Me.cmdPresetP1.Text = "P1"
        Me.cmdPresetP1.UseVisualStyleBackColor = False
        '
        'cmdPresetP2
        '
        Me.cmdPresetP2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdPresetP2.Location = New System.Drawing.Point(1781, 8)
        Me.cmdPresetP2.Name = "cmdPresetP2"
        Me.cmdPresetP2.Size = New System.Drawing.Size(39, 23)
        Me.cmdPresetP2.TabIndex = 568
        Me.cmdPresetP2.Text = "P2"
        Me.cmdPresetP2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(178, 77)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(60, 23)
        Me.Button3.TabIndex = 549
        Me.Button3.Text = "Full"
        Me.Button3.UseVisualStyleBackColor = True
        Me.Button3.Visible = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Blue
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Location = New System.Drawing.Point(237, 77)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(60, 23)
        Me.Button4.TabIndex = 548
        Me.Button4.Text = "Blackout"
        Me.Button4.UseVisualStyleBackColor = False
        Me.Button4.Visible = False
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.ForeColor = System.Drawing.Color.Lime
        Me.Label8.Location = New System.Drawing.Point(8, 57)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 42)
        Me.Label8.TabIndex = 547
        Me.Label8.Text = "Master:"
        Me.Label8.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(127, 57)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(42, 20)
        Me.TextBox2.TabIndex = 546
        Me.TextBox2.Text = "100"
        Me.TextBox2.Visible = False
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(178, 29)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(60, 23)
        Me.Button1.TabIndex = 545
        Me.Button1.Text = "Full"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(237, 29)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(60, 23)
        Me.Button2.TabIndex = 544
        Me.Button2.Text = "Blackout"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.ForeColor = System.Drawing.Color.Lime
        Me.Label7.Location = New System.Drawing.Point(8, 8)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 42)
        Me.Label7.TabIndex = 543
        Me.Label7.Text = "01 funky mushroom blue wash crazy"
        Me.Label7.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(127, 8)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(42, 20)
        Me.TextBox1.TabIndex = 542
        Me.TextBox1.Text = "100"
        Me.TextBox1.Visible = False
        '
        'tbpChannels
        '
        Me.tbpChannels.Controls.Add(Me.cmdChannelsSave)
        Me.tbpChannels.Controls.Add(Me.cmbChannelPresetSelection)
        Me.tbpChannels.Controls.Add(Me.cmdReloadChannelLocations)
        Me.tbpChannels.Controls.Add(Me.cmdChannelFadersDown)
        Me.tbpChannels.Controls.Add(Me.cmdChannelFadersUp)
        Me.tbpChannels.Controls.Add(Me.numChannelFadersStart)
        Me.tbpChannels.Location = New System.Drawing.Point(4, 22)
        Me.tbpChannels.Name = "tbpChannels"
        Me.tbpChannels.Size = New System.Drawing.Size(1826, 927)
        Me.tbpChannels.TabIndex = 6
        Me.tbpChannels.Text = "Channels"
        Me.tbpChannels.UseVisualStyleBackColor = True
        '
        'cmdChannelsSave
        '
        Me.cmdChannelsSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdChannelsSave.Location = New System.Drawing.Point(740, 4)
        Me.cmdChannelsSave.Name = "cmdChannelsSave"
        Me.cmdChannelsSave.Size = New System.Drawing.Size(102, 23)
        Me.cmdChannelsSave.TabIndex = 196
        Me.cmdChannelsSave.Text = "Save (Overwrite)"
        Me.cmdChannelsSave.UseVisualStyleBackColor = True
        '
        'cmbChannelPresetSelection
        '
        Me.cmbChannelPresetSelection.FormattingEnabled = True
        Me.cmbChannelPresetSelection.Location = New System.Drawing.Point(982, 6)
        Me.cmbChannelPresetSelection.MaxDropDownItems = 20
        Me.cmbChannelPresetSelection.Name = "cmbChannelPresetSelection"
        Me.cmbChannelPresetSelection.Size = New System.Drawing.Size(398, 21)
        Me.cmbChannelPresetSelection.TabIndex = 195
        '
        'cmdReloadChannelLocations
        '
        Me.cmdReloadChannelLocations.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdReloadChannelLocations.Location = New System.Drawing.Point(1464, 4)
        Me.cmdReloadChannelLocations.Name = "cmdReloadChannelLocations"
        Me.cmdReloadChannelLocations.Size = New System.Drawing.Size(102, 23)
        Me.cmdReloadChannelLocations.TabIndex = 194
        Me.cmdReloadChannelLocations.Text = "Reload Locations"
        Me.cmdReloadChannelLocations.UseVisualStyleBackColor = True
        '
        'cmdChannelFadersDown
        '
        Me.cmdChannelFadersDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdChannelFadersDown.Location = New System.Drawing.Point(1732, 4)
        Me.cmdChannelFadersDown.Name = "cmdChannelFadersDown"
        Me.cmdChannelFadersDown.Size = New System.Drawing.Size(39, 23)
        Me.cmdChannelFadersDown.TabIndex = 193
        Me.cmdChannelFadersDown.Text = "-80"
        Me.cmdChannelFadersDown.UseVisualStyleBackColor = True
        '
        'cmdChannelFadersUp
        '
        Me.cmdChannelFadersUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdChannelFadersUp.Location = New System.Drawing.Point(1783, 4)
        Me.cmdChannelFadersUp.Name = "cmdChannelFadersUp"
        Me.cmdChannelFadersUp.Size = New System.Drawing.Size(39, 23)
        Me.cmdChannelFadersUp.TabIndex = 192
        Me.cmdChannelFadersUp.Text = "+80"
        Me.cmdChannelFadersUp.UseVisualStyleBackColor = True
        '
        'numChannelFadersStart
        '
        Me.numChannelFadersStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numChannelFadersStart.Location = New System.Drawing.Point(1636, 4)
        Me.numChannelFadersStart.Maximum = New Decimal(New Integer() {2046, 0, 0, 0})
        Me.numChannelFadersStart.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numChannelFadersStart.Name = "numChannelFadersStart"
        Me.numChannelFadersStart.Size = New System.Drawing.Size(90, 20)
        Me.numChannelFadersStart.TabIndex = 191
        Me.numChannelFadersStart.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'tbpMusic
        '
        Me.tbpMusic.Controls.Add(Me.CustomWaves1)
        Me.tbpMusic.Controls.Add(Me.cmdEditUpdate)
        Me.tbpMusic.Controls.Add(Me.txtEditTime)
        Me.tbpMusic.Controls.Add(Me.Label25)
        Me.tbpMusic.Controls.Add(Me.chkRecordspace)
        Me.tbpMusic.Controls.Add(Me.numFadeIn)
        Me.tbpMusic.Controls.Add(Me.lblFadeIn)
        Me.tbpMusic.Controls.Add(Me.numFadeOut)
        Me.tbpMusic.Controls.Add(Me.lblFadeOut)
        Me.tbpMusic.Controls.Add(Me.vSongEdit)
        Me.tbpMusic.Controls.Add(Me.ListBox1)
        Me.tbpMusic.Controls.Add(Me.lstSongEditPresets)
        Me.tbpMusic.Controls.Add(Me.cmdEditSongCopyNew)
        Me.tbpMusic.Controls.Add(Me.cmdEditSongSave)
        Me.tbpMusic.Controls.Add(Me.cmdCreatelink)
        Me.tbpMusic.Controls.Add(Me.Label20)
        Me.tbpMusic.Controls.Add(Me.lbleditRemaining)
        Me.tbpMusic.Controls.Add(Me.lbleditPositionMilli)
        Me.tbpMusic.Controls.Add(Me.lbleditposition)
        Me.tbpMusic.Controls.Add(Me.cmdEditStop)
        Me.tbpMusic.Controls.Add(Me.cmdEditPlay)
        Me.tbpMusic.Controls.Add(Me.chkEnableSongEdit)
        Me.tbpMusic.Controls.Add(Me.lstMusicSongChanges2)
        Me.tbpMusic.Controls.Add(Me.cmdMusicSkip2)
        Me.tbpMusic.Controls.Add(Me.cmdMusicSkip)
        Me.tbpMusic.Controls.Add(Me.lblMusicMP3PositionMilli2)
        Me.tbpMusic.Controls.Add(Me.Label9)
        Me.tbpMusic.Controls.Add(Me.lblMusicMP3Position2)
        Me.tbpMusic.Controls.Add(Me.Label12)
        Me.tbpMusic.Controls.Add(Me.lblMusicMP3Duration2)
        Me.tbpMusic.Controls.Add(Me.cmdMusicStop2)
        Me.tbpMusic.Controls.Add(Me.cmdMusicPlay2)
        Me.tbpMusic.Controls.Add(Me.trkMusicVolume2)
        Me.tbpMusic.Controls.Add(Me.lstMusicSongs2)
        Me.tbpMusic.Controls.Add(Me.lblMusicMP3PositionMilli)
        Me.tbpMusic.Controls.Add(Me.Label4)
        Me.tbpMusic.Controls.Add(Me.lblMusicMP3Position)
        Me.tbpMusic.Controls.Add(Me.Label6)
        Me.tbpMusic.Controls.Add(Me.lblMusicMP3Duration)
        Me.tbpMusic.Controls.Add(Me.cmdMusicStop)
        Me.tbpMusic.Controls.Add(Me.cmdMusicPlay)
        Me.tbpMusic.Controls.Add(Me.lstMusicSongs)
        Me.tbpMusic.Controls.Add(Me.lstMusicSongChanges)
        Me.tbpMusic.Controls.Add(Me.trkMusicVolume)
        Me.tbpMusic.Location = New System.Drawing.Point(4, 22)
        Me.tbpMusic.Name = "tbpMusic"
        Me.tbpMusic.Size = New System.Drawing.Size(1826, 927)
        Me.tbpMusic.TabIndex = 2
        Me.tbpMusic.Text = "Music Editor"
        Me.tbpMusic.UseVisualStyleBackColor = True
        '
        'CustomWaves1
        '
        Me.CustomWaves1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CustomWaves1.Location = New System.Drawing.Point(1693, 14)
        Me.CustomWaves1.Name = "CustomWaves1"
        Me.CustomWaves1.PenColor = System.Drawing.Color.Empty
        Me.CustomWaves1.PenWidth = 0!
        Me.CustomWaves1.SamplesPerPixel = 128
        Me.CustomWaves1.Size = New System.Drawing.Size(119, 95)
        Me.CustomWaves1.StartPosition = CType(0, Long)
        Me.CustomWaves1.TabIndex = 336
        Me.CustomWaves1.Visible = False
        Me.CustomWaves1.WaveStream = Nothing
        '
        'cmdEditUpdate
        '
        Me.cmdEditUpdate.Location = New System.Drawing.Point(367, 770)
        Me.cmdEditUpdate.Name = "cmdEditUpdate"
        Me.cmdEditUpdate.Size = New System.Drawing.Size(75, 23)
        Me.cmdEditUpdate.TabIndex = 334
        Me.cmdEditUpdate.Text = "Update"
        Me.cmdEditUpdate.UseVisualStyleBackColor = True
        '
        'txtEditTime
        '
        Me.txtEditTime.Location = New System.Drawing.Point(367, 737)
        Me.txtEditTime.Name = "txtEditTime"
        Me.txtEditTime.Size = New System.Drawing.Size(88, 20)
        Me.txtEditTime.TabIndex = 333
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.ForeColor = System.Drawing.Color.Lime
        Me.Label25.Location = New System.Drawing.Point(364, 718)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(33, 13)
        Me.Label25.TabIndex = 332
        Me.Label25.Text = "Time:"
        Me.Label25.Visible = False
        '
        'chkRecordspace
        '
        Me.chkRecordspace.AutoSize = True
        Me.chkRecordspace.ForeColor = System.Drawing.Color.Lime
        Me.chkRecordspace.Location = New System.Drawing.Point(949, 683)
        Me.chkRecordspace.Name = "chkRecordspace"
        Me.chkRecordspace.Size = New System.Drawing.Size(145, 17)
        Me.chkRecordspace.TabIndex = 331
        Me.chkRecordspace.Text = "Record Spacebar events"
        Me.chkRecordspace.UseVisualStyleBackColor = True
        Me.chkRecordspace.Visible = False
        '
        'numFadeIn
        '
        Me.numFadeIn.Location = New System.Drawing.Point(367, 635)
        Me.numFadeIn.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.numFadeIn.Name = "numFadeIn"
        Me.numFadeIn.Size = New System.Drawing.Size(75, 20)
        Me.numFadeIn.TabIndex = 330
        Me.numFadeIn.Visible = False
        '
        'lblFadeIn
        '
        Me.lblFadeIn.AutoSize = True
        Me.lblFadeIn.ForeColor = System.Drawing.Color.Lime
        Me.lblFadeIn.Location = New System.Drawing.Point(364, 616)
        Me.lblFadeIn.Name = "lblFadeIn"
        Me.lblFadeIn.Size = New System.Drawing.Size(46, 13)
        Me.lblFadeIn.TabIndex = 329
        Me.lblFadeIn.Text = "Fade In:"
        Me.lblFadeIn.Visible = False
        '
        'numFadeOut
        '
        Me.numFadeOut.Location = New System.Drawing.Point(367, 685)
        Me.numFadeOut.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.numFadeOut.Name = "numFadeOut"
        Me.numFadeOut.Size = New System.Drawing.Size(75, 20)
        Me.numFadeOut.TabIndex = 328
        Me.numFadeOut.Visible = False
        '
        'lblFadeOut
        '
        Me.lblFadeOut.AutoSize = True
        Me.lblFadeOut.ForeColor = System.Drawing.Color.Lime
        Me.lblFadeOut.Location = New System.Drawing.Point(364, 666)
        Me.lblFadeOut.Name = "lblFadeOut"
        Me.lblFadeOut.Size = New System.Drawing.Size(54, 13)
        Me.lblFadeOut.TabIndex = 327
        Me.lblFadeOut.Text = "Fade Out:"
        Me.lblFadeOut.Visible = False
        '
        'vSongEdit
        '
        Me.vSongEdit.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.vSongEdit.BackColor = System.Drawing.Color.White
        Me.vSongEdit.BulletColor = System.Drawing.Color.Red
        Me.vSongEdit.FillColor = System.Drawing.Color.Black
        Me.vSongEdit.Location = New System.Drawing.Point(8, 434)
        Me.vSongEdit.Maximum = 5000000
        Me.vSongEdit.Name = "vSongEdit"
        Me.vSongEdit.Size = New System.Drawing.Size(1804, 42)
        Me.vSongEdit.TabIndex = 335
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(461, 516)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(268, 225)
        Me.ListBox1.TabIndex = 326
        Me.ListBox1.Visible = False
        '
        'lstSongEditPresets
        '
        Me.lstSongEditPresets.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstSongEditPresets.FormattingEnabled = True
        Me.lstSongEditPresets.Location = New System.Drawing.Point(76, 516)
        Me.lstSongEditPresets.Name = "lstSongEditPresets"
        Me.lstSongEditPresets.Size = New System.Drawing.Size(268, 381)
        Me.lstSongEditPresets.TabIndex = 325
        Me.lstSongEditPresets.Visible = False
        '
        'cmdEditSongCopyNew
        '
        Me.cmdEditSongCopyNew.Location = New System.Drawing.Point(367, 546)
        Me.cmdEditSongCopyNew.Name = "cmdEditSongCopyNew"
        Me.cmdEditSongCopyNew.Size = New System.Drawing.Size(75, 52)
        Me.cmdEditSongCopyNew.TabIndex = 324
        Me.cmdEditSongCopyNew.Text = "Copy Scene to New and create link"
        Me.cmdEditSongCopyNew.UseVisualStyleBackColor = True
        Me.cmdEditSongCopyNew.Visible = False
        '
        'cmdEditSongSave
        '
        Me.cmdEditSongSave.Location = New System.Drawing.Point(367, 817)
        Me.cmdEditSongSave.Name = "cmdEditSongSave"
        Me.cmdEditSongSave.Size = New System.Drawing.Size(75, 23)
        Me.cmdEditSongSave.TabIndex = 323
        Me.cmdEditSongSave.Text = "Save"
        Me.cmdEditSongSave.UseVisualStyleBackColor = True
        Me.cmdEditSongSave.Visible = False
        '
        'cmdCreatelink
        '
        Me.cmdCreatelink.Location = New System.Drawing.Point(367, 517)
        Me.cmdCreatelink.Name = "cmdCreatelink"
        Me.cmdCreatelink.Size = New System.Drawing.Size(75, 23)
        Me.cmdCreatelink.TabIndex = 322
        Me.cmdCreatelink.Text = "Create link"
        Me.cmdCreatelink.UseVisualStyleBackColor = True
        Me.cmdCreatelink.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Lime
        Me.Label20.Location = New System.Drawing.Point(946, 514)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(60, 13)
        Me.Label20.TabIndex = 321
        Me.Label20.Text = "Remaining:"
        Me.Label20.Visible = False
        '
        'lbleditRemaining
        '
        Me.lbleditRemaining.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbleditRemaining.ForeColor = System.Drawing.Color.Lime
        Me.lbleditRemaining.Location = New System.Drawing.Point(945, 530)
        Me.lbleditRemaining.Name = "lbleditRemaining"
        Me.lbleditRemaining.Size = New System.Drawing.Size(71, 20)
        Me.lbleditRemaining.TabIndex = 320
        Me.lbleditRemaining.Text = "00:00:00"
        Me.lbleditRemaining.Visible = False
        '
        'lbleditPositionMilli
        '
        Me.lbleditPositionMilli.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbleditPositionMilli.ForeColor = System.Drawing.Color.Lime
        Me.lbleditPositionMilli.Location = New System.Drawing.Point(8, 539)
        Me.lbleditPositionMilli.Name = "lbleditPositionMilli"
        Me.lbleditPositionMilli.Size = New System.Drawing.Size(71, 20)
        Me.lbleditPositionMilli.TabIndex = 319
        Me.lbleditPositionMilli.Text = "000000"
        Me.lbleditPositionMilli.Visible = False
        '
        'lbleditposition
        '
        Me.lbleditposition.AutoSize = True
        Me.lbleditposition.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbleditposition.ForeColor = System.Drawing.Color.Lime
        Me.lbleditposition.Location = New System.Drawing.Point(9, 523)
        Me.lbleditposition.Name = "lbleditposition"
        Me.lbleditposition.Size = New System.Drawing.Size(47, 13)
        Me.lbleditposition.TabIndex = 318
        Me.lbleditposition.Text = "Position:"
        Me.lbleditposition.Visible = False
        '
        'cmdEditStop
        '
        Me.cmdEditStop.Location = New System.Drawing.Point(949, 612)
        Me.cmdEditStop.Name = "cmdEditStop"
        Me.cmdEditStop.Size = New System.Drawing.Size(75, 43)
        Me.cmdEditStop.TabIndex = 317
        Me.cmdEditStop.Text = "Stop"
        Me.cmdEditStop.UseVisualStyleBackColor = True
        Me.cmdEditStop.Visible = False
        '
        'cmdEditPlay
        '
        Me.cmdEditPlay.Location = New System.Drawing.Point(949, 563)
        Me.cmdEditPlay.Name = "cmdEditPlay"
        Me.cmdEditPlay.Size = New System.Drawing.Size(75, 43)
        Me.cmdEditPlay.TabIndex = 316
        Me.cmdEditPlay.Text = "Play"
        Me.cmdEditPlay.UseVisualStyleBackColor = True
        Me.cmdEditPlay.Visible = False
        '
        'chkEnableSongEdit
        '
        Me.chkEnableSongEdit.AutoSize = True
        Me.chkEnableSongEdit.ForeColor = System.Drawing.Color.Lime
        Me.chkEnableSongEdit.Location = New System.Drawing.Point(672, 14)
        Me.chkEnableSongEdit.Name = "chkEnableSongEdit"
        Me.chkEnableSongEdit.Size = New System.Drawing.Size(94, 17)
        Me.chkEnableSongEdit.TabIndex = 311
        Me.chkEnableSongEdit.Text = "Enable Editing"
        Me.chkEnableSongEdit.UseVisualStyleBackColor = True
        '
        'lstMusicSongChanges2
        '
        Me.lstMusicSongChanges2.FormattingEnabled = True
        Me.lstMusicSongChanges2.Location = New System.Drawing.Point(422, 211)
        Me.lstMusicSongChanges2.Name = "lstMusicSongChanges2"
        Me.lstMusicSongChanges2.Size = New System.Drawing.Size(231, 199)
        Me.lstMusicSongChanges2.TabIndex = 310
        '
        'cmdMusicSkip2
        '
        Me.cmdMusicSkip2.Location = New System.Drawing.Point(297, 315)
        Me.cmdMusicSkip2.Name = "cmdMusicSkip2"
        Me.cmdMusicSkip2.Size = New System.Drawing.Size(37, 23)
        Me.cmdMusicSkip2.TabIndex = 309
        Me.cmdMusicSkip2.Text = "Skip"
        Me.cmdMusicSkip2.UseVisualStyleBackColor = True
        '
        'cmdMusicSkip
        '
        Me.cmdMusicSkip.Location = New System.Drawing.Point(297, 109)
        Me.cmdMusicSkip.Name = "cmdMusicSkip"
        Me.cmdMusicSkip.Size = New System.Drawing.Size(37, 23)
        Me.cmdMusicSkip.TabIndex = 308
        Me.cmdMusicSkip.Text = "Skip"
        Me.cmdMusicSkip.UseVisualStyleBackColor = True
        '
        'lblMusicMP3PositionMilli2
        '
        Me.lblMusicMP3PositionMilli2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMusicMP3PositionMilli2.ForeColor = System.Drawing.Color.Lime
        Me.lblMusicMP3PositionMilli2.Location = New System.Drawing.Point(293, 375)
        Me.lblMusicMP3PositionMilli2.Name = "lblMusicMP3PositionMilli2"
        Me.lblMusicMP3PositionMilli2.Size = New System.Drawing.Size(71, 20)
        Me.lblMusicMP3PositionMilli2.TabIndex = 306
        Me.lblMusicMP3PositionMilli2.Text = "000000"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Lime
        Me.Label9.Location = New System.Drawing.Point(294, 339)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 13)
        Me.Label9.TabIndex = 305
        Me.Label9.Text = "Position:"
        '
        'lblMusicMP3Position2
        '
        Me.lblMusicMP3Position2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMusicMP3Position2.ForeColor = System.Drawing.Color.Lime
        Me.lblMusicMP3Position2.Location = New System.Drawing.Point(293, 355)
        Me.lblMusicMP3Position2.Name = "lblMusicMP3Position2"
        Me.lblMusicMP3Position2.Size = New System.Drawing.Size(71, 20)
        Me.lblMusicMP3Position2.TabIndex = 304
        Me.lblMusicMP3Position2.Text = "00:00.00"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Lime
        Me.Label12.Location = New System.Drawing.Point(294, 279)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(50, 13)
        Me.Label12.TabIndex = 303
        Me.Label12.Text = "Duration:"
        '
        'lblMusicMP3Duration2
        '
        Me.lblMusicMP3Duration2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMusicMP3Duration2.ForeColor = System.Drawing.Color.Lime
        Me.lblMusicMP3Duration2.Location = New System.Drawing.Point(293, 295)
        Me.lblMusicMP3Duration2.Name = "lblMusicMP3Duration2"
        Me.lblMusicMP3Duration2.Size = New System.Drawing.Size(71, 20)
        Me.lblMusicMP3Duration2.TabIndex = 302
        Me.lblMusicMP3Duration2.Text = "00:00:00"
        '
        'cmdMusicStop2
        '
        Me.cmdMusicStop2.Location = New System.Drawing.Point(297, 242)
        Me.cmdMusicStop2.Name = "cmdMusicStop2"
        Me.cmdMusicStop2.Size = New System.Drawing.Size(75, 23)
        Me.cmdMusicStop2.TabIndex = 301
        Me.cmdMusicStop2.Text = "Stop"
        Me.cmdMusicStop2.UseVisualStyleBackColor = True
        '
        'cmdMusicPlay2
        '
        Me.cmdMusicPlay2.Location = New System.Drawing.Point(297, 213)
        Me.cmdMusicPlay2.Name = "cmdMusicPlay2"
        Me.cmdMusicPlay2.Size = New System.Drawing.Size(75, 23)
        Me.cmdMusicPlay2.TabIndex = 300
        Me.cmdMusicPlay2.Text = "Play"
        Me.cmdMusicPlay2.UseVisualStyleBackColor = True
        '
        'trkMusicVolume2
        '
        Me.trkMusicVolume2.Location = New System.Drawing.Point(367, 295)
        Me.trkMusicVolume2.Maximum = 100
        Me.trkMusicVolume2.Name = "trkMusicVolume2"
        Me.trkMusicVolume2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.trkMusicVolume2.Size = New System.Drawing.Size(45, 71)
        Me.trkMusicVolume2.TabIndex = 307
        Me.trkMusicVolume2.TickFrequency = 0
        Me.trkMusicVolume2.Value = 100
        '
        'lstMusicSongs2
        '
        Me.lstMusicSongs2.FormattingEnabled = True
        Me.lstMusicSongs2.Location = New System.Drawing.Point(8, 213)
        Me.lstMusicSongs2.Name = "lstMusicSongs2"
        Me.lstMusicSongs2.Size = New System.Drawing.Size(283, 199)
        Me.lstMusicSongs2.TabIndex = 299
        '
        'lblMusicMP3PositionMilli
        '
        Me.lblMusicMP3PositionMilli.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMusicMP3PositionMilli.ForeColor = System.Drawing.Color.Lime
        Me.lblMusicMP3PositionMilli.Location = New System.Drawing.Point(293, 170)
        Me.lblMusicMP3PositionMilli.Name = "lblMusicMP3PositionMilli"
        Me.lblMusicMP3PositionMilli.Size = New System.Drawing.Size(71, 20)
        Me.lblMusicMP3PositionMilli.TabIndex = 296
        Me.lblMusicMP3PositionMilli.Text = "000000"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Lime
        Me.Label4.Location = New System.Drawing.Point(294, 134)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 295
        Me.Label4.Text = "Position:"
        '
        'lblMusicMP3Position
        '
        Me.lblMusicMP3Position.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMusicMP3Position.ForeColor = System.Drawing.Color.Lime
        Me.lblMusicMP3Position.Location = New System.Drawing.Point(293, 150)
        Me.lblMusicMP3Position.Name = "lblMusicMP3Position"
        Me.lblMusicMP3Position.Size = New System.Drawing.Size(71, 20)
        Me.lblMusicMP3Position.TabIndex = 294
        Me.lblMusicMP3Position.Text = "00:00.00"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Lime
        Me.Label6.Location = New System.Drawing.Point(294, 74)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 13)
        Me.Label6.TabIndex = 293
        Me.Label6.Text = "Duration:"
        '
        'lblMusicMP3Duration
        '
        Me.lblMusicMP3Duration.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMusicMP3Duration.ForeColor = System.Drawing.Color.Lime
        Me.lblMusicMP3Duration.Location = New System.Drawing.Point(293, 90)
        Me.lblMusicMP3Duration.Name = "lblMusicMP3Duration"
        Me.lblMusicMP3Duration.Size = New System.Drawing.Size(71, 20)
        Me.lblMusicMP3Duration.TabIndex = 292
        Me.lblMusicMP3Duration.Text = "00:00:00"
        '
        'cmdMusicStop
        '
        Me.cmdMusicStop.Location = New System.Drawing.Point(297, 37)
        Me.cmdMusicStop.Name = "cmdMusicStop"
        Me.cmdMusicStop.Size = New System.Drawing.Size(75, 23)
        Me.cmdMusicStop.TabIndex = 291
        Me.cmdMusicStop.Text = "Stop"
        Me.cmdMusicStop.UseVisualStyleBackColor = True
        '
        'cmdMusicPlay
        '
        Me.cmdMusicPlay.Location = New System.Drawing.Point(297, 8)
        Me.cmdMusicPlay.Name = "cmdMusicPlay"
        Me.cmdMusicPlay.Size = New System.Drawing.Size(75, 23)
        Me.cmdMusicPlay.TabIndex = 290
        Me.cmdMusicPlay.Text = "Play"
        Me.cmdMusicPlay.UseVisualStyleBackColor = True
        '
        'lstMusicSongs
        '
        Me.lstMusicSongs.FormattingEnabled = True
        Me.lstMusicSongs.Location = New System.Drawing.Point(8, 8)
        Me.lstMusicSongs.Name = "lstMusicSongs"
        Me.lstMusicSongs.Size = New System.Drawing.Size(283, 199)
        Me.lstMusicSongs.TabIndex = 289
        '
        'lstMusicSongChanges
        '
        Me.lstMusicSongChanges.FormattingEnabled = True
        Me.lstMusicSongChanges.Location = New System.Drawing.Point(422, 8)
        Me.lstMusicSongChanges.Name = "lstMusicSongChanges"
        Me.lstMusicSongChanges.Size = New System.Drawing.Size(231, 199)
        Me.lstMusicSongChanges.TabIndex = 297
        '
        'trkMusicVolume
        '
        Me.trkMusicVolume.Location = New System.Drawing.Point(367, 90)
        Me.trkMusicVolume.Maximum = 100
        Me.trkMusicVolume.Name = "trkMusicVolume"
        Me.trkMusicVolume.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.trkMusicVolume.Size = New System.Drawing.Size(45, 71)
        Me.trkMusicVolume.TabIndex = 298
        Me.trkMusicVolume.TickFrequency = 0
        Me.trkMusicVolume.Value = 100
        '
        'tbpDramaChanges
        '
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaBlackoutAllInstant)
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaBlackoutAllTimer)
        Me.tbpDramaChanges.Controls.Add(Me.lstDramaPresets)
        Me.tbpDramaChanges.Controls.Add(Me.lstDramaViewSongChanges2)
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaViewSkip2)
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaViewSkip)
        Me.tbpDramaChanges.Controls.Add(Me.lblDramaViewMP3PositionMilli2)
        Me.tbpDramaChanges.Controls.Add(Me.Label3)
        Me.tbpDramaChanges.Controls.Add(Me.lblDramaViewMP3Position2)
        Me.tbpDramaChanges.Controls.Add(Me.Label28)
        Me.tbpDramaChanges.Controls.Add(Me.lblDramaViewMP3Duration2)
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaViewStop2)
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaViewPlay2)
        Me.tbpDramaChanges.Controls.Add(Me.trkDramaViewVolume2)
        Me.tbpDramaChanges.Controls.Add(Me.lstDramaViewSongs2)
        Me.tbpDramaChanges.Controls.Add(Me.lblDramaViewMP3PositionMilli)
        Me.tbpDramaChanges.Controls.Add(Me.Label33)
        Me.tbpDramaChanges.Controls.Add(Me.lblDramaViewMP3Position)
        Me.tbpDramaChanges.Controls.Add(Me.Label37)
        Me.tbpDramaChanges.Controls.Add(Me.lblDramaViewMP3Duration)
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaViewStop)
        Me.tbpDramaChanges.Controls.Add(Me.cmdDramaViewPlay)
        Me.tbpDramaChanges.Controls.Add(Me.lstDramaViewSongs)
        Me.tbpDramaChanges.Controls.Add(Me.lstDramaViewSongChanges)
        Me.tbpDramaChanges.Controls.Add(Me.trkDramaViewVolume)
        Me.tbpDramaChanges.Location = New System.Drawing.Point(4, 22)
        Me.tbpDramaChanges.Name = "tbpDramaChanges"
        Me.tbpDramaChanges.Size = New System.Drawing.Size(1826, 927)
        Me.tbpDramaChanges.TabIndex = 3
        Me.tbpDramaChanges.Text = "Quick Changes (Drama)"
        Me.tbpDramaChanges.UseVisualStyleBackColor = True
        '
        'cmdDramaBlackoutAllInstant
        '
        Me.cmdDramaBlackoutAllInstant.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdDramaBlackoutAllInstant.Location = New System.Drawing.Point(282, 65)
        Me.cmdDramaBlackoutAllInstant.Name = "cmdDramaBlackoutAllInstant"
        Me.cmdDramaBlackoutAllInstant.Size = New System.Drawing.Size(90, 45)
        Me.cmdDramaBlackoutAllInstant.TabIndex = 573
        Me.cmdDramaBlackoutAllInstant.Text = "Blackout All Instant"
        Me.cmdDramaBlackoutAllInstant.UseVisualStyleBackColor = True
        '
        'cmdDramaBlackoutAllTimer
        '
        Me.cmdDramaBlackoutAllTimer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdDramaBlackoutAllTimer.Location = New System.Drawing.Point(282, 14)
        Me.cmdDramaBlackoutAllTimer.Name = "cmdDramaBlackoutAllTimer"
        Me.cmdDramaBlackoutAllTimer.Size = New System.Drawing.Size(90, 45)
        Me.cmdDramaBlackoutAllTimer.TabIndex = 572
        Me.cmdDramaBlackoutAllTimer.Text = "Blackout All Timer"
        Me.cmdDramaBlackoutAllTimer.UseVisualStyleBackColor = True
        '
        'lstDramaPresets
        '
        Me.lstDramaPresets.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstDramaPresets.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstDramaPresets.FormattingEnabled = True
        Me.lstDramaPresets.ItemHeight = 16
        Me.lstDramaPresets.Location = New System.Drawing.Point(8, 7)
        Me.lstDramaPresets.Name = "lstDramaPresets"
        Me.lstDramaPresets.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstDramaPresets.Size = New System.Drawing.Size(268, 820)
        Me.lstDramaPresets.TabIndex = 333
        '
        'lstDramaViewSongChanges2
        '
        Me.lstDramaViewSongChanges2.FormattingEnabled = True
        Me.lstDramaViewSongChanges2.Location = New System.Drawing.Point(1588, 399)
        Me.lstDramaViewSongChanges2.Name = "lstDramaViewSongChanges2"
        Me.lstDramaViewSongChanges2.Size = New System.Drawing.Size(231, 381)
        Me.lstDramaViewSongChanges2.TabIndex = 332
        '
        'cmdDramaViewSkip2
        '
        Me.cmdDramaViewSkip2.Location = New System.Drawing.Point(1463, 503)
        Me.cmdDramaViewSkip2.Name = "cmdDramaViewSkip2"
        Me.cmdDramaViewSkip2.Size = New System.Drawing.Size(37, 23)
        Me.cmdDramaViewSkip2.TabIndex = 331
        Me.cmdDramaViewSkip2.Text = "Skip"
        Me.cmdDramaViewSkip2.UseVisualStyleBackColor = True
        '
        'cmdDramaViewSkip
        '
        Me.cmdDramaViewSkip.Location = New System.Drawing.Point(1463, 108)
        Me.cmdDramaViewSkip.Name = "cmdDramaViewSkip"
        Me.cmdDramaViewSkip.Size = New System.Drawing.Size(37, 23)
        Me.cmdDramaViewSkip.TabIndex = 330
        Me.cmdDramaViewSkip.Text = "Skip"
        Me.cmdDramaViewSkip.UseVisualStyleBackColor = True
        '
        'lblDramaViewMP3PositionMilli2
        '
        Me.lblDramaViewMP3PositionMilli2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDramaViewMP3PositionMilli2.ForeColor = System.Drawing.Color.Lime
        Me.lblDramaViewMP3PositionMilli2.Location = New System.Drawing.Point(1459, 563)
        Me.lblDramaViewMP3PositionMilli2.Name = "lblDramaViewMP3PositionMilli2"
        Me.lblDramaViewMP3PositionMilli2.Size = New System.Drawing.Size(71, 20)
        Me.lblDramaViewMP3PositionMilli2.TabIndex = 328
        Me.lblDramaViewMP3PositionMilli2.Text = "000000"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Lime
        Me.Label3.Location = New System.Drawing.Point(1460, 527)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 327
        Me.Label3.Text = "Position:"
        '
        'lblDramaViewMP3Position2
        '
        Me.lblDramaViewMP3Position2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDramaViewMP3Position2.ForeColor = System.Drawing.Color.Lime
        Me.lblDramaViewMP3Position2.Location = New System.Drawing.Point(1459, 543)
        Me.lblDramaViewMP3Position2.Name = "lblDramaViewMP3Position2"
        Me.lblDramaViewMP3Position2.Size = New System.Drawing.Size(71, 20)
        Me.lblDramaViewMP3Position2.TabIndex = 326
        Me.lblDramaViewMP3Position2.Text = "00:00.00"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Lime
        Me.Label28.Location = New System.Drawing.Point(1460, 467)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(50, 13)
        Me.Label28.TabIndex = 325
        Me.Label28.Text = "Duration:"
        '
        'lblDramaViewMP3Duration2
        '
        Me.lblDramaViewMP3Duration2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDramaViewMP3Duration2.ForeColor = System.Drawing.Color.Lime
        Me.lblDramaViewMP3Duration2.Location = New System.Drawing.Point(1459, 483)
        Me.lblDramaViewMP3Duration2.Name = "lblDramaViewMP3Duration2"
        Me.lblDramaViewMP3Duration2.Size = New System.Drawing.Size(71, 20)
        Me.lblDramaViewMP3Duration2.TabIndex = 324
        Me.lblDramaViewMP3Duration2.Text = "00:00:00"
        '
        'cmdDramaViewStop2
        '
        Me.cmdDramaViewStop2.Location = New System.Drawing.Point(1463, 430)
        Me.cmdDramaViewStop2.Name = "cmdDramaViewStop2"
        Me.cmdDramaViewStop2.Size = New System.Drawing.Size(75, 23)
        Me.cmdDramaViewStop2.TabIndex = 323
        Me.cmdDramaViewStop2.Text = "Stop"
        Me.cmdDramaViewStop2.UseVisualStyleBackColor = True
        '
        'cmdDramaViewPlay2
        '
        Me.cmdDramaViewPlay2.Location = New System.Drawing.Point(1463, 401)
        Me.cmdDramaViewPlay2.Name = "cmdDramaViewPlay2"
        Me.cmdDramaViewPlay2.Size = New System.Drawing.Size(75, 23)
        Me.cmdDramaViewPlay2.TabIndex = 322
        Me.cmdDramaViewPlay2.Text = "Play"
        Me.cmdDramaViewPlay2.UseVisualStyleBackColor = True
        '
        'trkDramaViewVolume2
        '
        Me.trkDramaViewVolume2.Location = New System.Drawing.Point(1533, 483)
        Me.trkDramaViewVolume2.Maximum = 100
        Me.trkDramaViewVolume2.Name = "trkDramaViewVolume2"
        Me.trkDramaViewVolume2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.trkDramaViewVolume2.Size = New System.Drawing.Size(45, 71)
        Me.trkDramaViewVolume2.TabIndex = 329
        Me.trkDramaViewVolume2.TickFrequency = 0
        Me.trkDramaViewVolume2.Value = 100
        '
        'lstDramaViewSongs2
        '
        Me.lstDramaViewSongs2.FormattingEnabled = True
        Me.lstDramaViewSongs2.Location = New System.Drawing.Point(1174, 401)
        Me.lstDramaViewSongs2.Name = "lstDramaViewSongs2"
        Me.lstDramaViewSongs2.Size = New System.Drawing.Size(283, 381)
        Me.lstDramaViewSongs2.TabIndex = 321
        '
        'lblDramaViewMP3PositionMilli
        '
        Me.lblDramaViewMP3PositionMilli.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDramaViewMP3PositionMilli.ForeColor = System.Drawing.Color.Lime
        Me.lblDramaViewMP3PositionMilli.Location = New System.Drawing.Point(1459, 169)
        Me.lblDramaViewMP3PositionMilli.Name = "lblDramaViewMP3PositionMilli"
        Me.lblDramaViewMP3PositionMilli.Size = New System.Drawing.Size(71, 20)
        Me.lblDramaViewMP3PositionMilli.TabIndex = 318
        Me.lblDramaViewMP3PositionMilli.Text = "000000"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Lime
        Me.Label33.Location = New System.Drawing.Point(1460, 133)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(47, 13)
        Me.Label33.TabIndex = 317
        Me.Label33.Text = "Position:"
        '
        'lblDramaViewMP3Position
        '
        Me.lblDramaViewMP3Position.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDramaViewMP3Position.ForeColor = System.Drawing.Color.Lime
        Me.lblDramaViewMP3Position.Location = New System.Drawing.Point(1459, 149)
        Me.lblDramaViewMP3Position.Name = "lblDramaViewMP3Position"
        Me.lblDramaViewMP3Position.Size = New System.Drawing.Size(71, 20)
        Me.lblDramaViewMP3Position.TabIndex = 316
        Me.lblDramaViewMP3Position.Text = "00:00.00"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Lime
        Me.Label37.Location = New System.Drawing.Point(1460, 73)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(50, 13)
        Me.Label37.TabIndex = 315
        Me.Label37.Text = "Duration:"
        '
        'lblDramaViewMP3Duration
        '
        Me.lblDramaViewMP3Duration.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDramaViewMP3Duration.ForeColor = System.Drawing.Color.Lime
        Me.lblDramaViewMP3Duration.Location = New System.Drawing.Point(1459, 89)
        Me.lblDramaViewMP3Duration.Name = "lblDramaViewMP3Duration"
        Me.lblDramaViewMP3Duration.Size = New System.Drawing.Size(71, 20)
        Me.lblDramaViewMP3Duration.TabIndex = 314
        Me.lblDramaViewMP3Duration.Text = "00:00:00"
        '
        'cmdDramaViewStop
        '
        Me.cmdDramaViewStop.Location = New System.Drawing.Point(1463, 36)
        Me.cmdDramaViewStop.Name = "cmdDramaViewStop"
        Me.cmdDramaViewStop.Size = New System.Drawing.Size(75, 23)
        Me.cmdDramaViewStop.TabIndex = 313
        Me.cmdDramaViewStop.Text = "Stop"
        Me.cmdDramaViewStop.UseVisualStyleBackColor = True
        '
        'cmdDramaViewPlay
        '
        Me.cmdDramaViewPlay.Location = New System.Drawing.Point(1463, 7)
        Me.cmdDramaViewPlay.Name = "cmdDramaViewPlay"
        Me.cmdDramaViewPlay.Size = New System.Drawing.Size(75, 23)
        Me.cmdDramaViewPlay.TabIndex = 312
        Me.cmdDramaViewPlay.Text = "Play"
        Me.cmdDramaViewPlay.UseVisualStyleBackColor = True
        '
        'lstDramaViewSongs
        '
        Me.lstDramaViewSongs.FormattingEnabled = True
        Me.lstDramaViewSongs.Location = New System.Drawing.Point(1174, 7)
        Me.lstDramaViewSongs.Name = "lstDramaViewSongs"
        Me.lstDramaViewSongs.Size = New System.Drawing.Size(283, 381)
        Me.lstDramaViewSongs.TabIndex = 311
        '
        'lstDramaViewSongChanges
        '
        Me.lstDramaViewSongChanges.FormattingEnabled = True
        Me.lstDramaViewSongChanges.Location = New System.Drawing.Point(1588, 7)
        Me.lstDramaViewSongChanges.Name = "lstDramaViewSongChanges"
        Me.lstDramaViewSongChanges.Size = New System.Drawing.Size(231, 381)
        Me.lstDramaViewSongChanges.TabIndex = 319
        '
        'trkDramaViewVolume
        '
        Me.trkDramaViewVolume.Location = New System.Drawing.Point(1533, 89)
        Me.trkDramaViewVolume.Maximum = 100
        Me.trkDramaViewVolume.Name = "trkDramaViewVolume"
        Me.trkDramaViewVolume.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.trkDramaViewVolume.Size = New System.Drawing.Size(45, 71)
        Me.trkDramaViewVolume.TabIndex = 320
        Me.trkDramaViewVolume.TickFrequency = 0
        Me.trkDramaViewVolume.Value = 100
        '
        'tbpSettings
        '
        Me.tbpSettings.Controls.Add(Me.lblArduino1)
        Me.tbpSettings.Controls.Add(Me.cmdSaveSettings)
        Me.tbpSettings.Controls.Add(Me.lblSceneLabelColour)
        Me.tbpSettings.Controls.Add(Me.cmdSceneLabelColour)
        Me.tbpSettings.Controls.Add(Me.cmdSerialClear)
        Me.tbpSettings.Controls.Add(Me.lblUpDownTest)
        Me.tbpSettings.Controls.Add(Me.txtSerialIn)
        Me.tbpSettings.Controls.Add(Me.lblChannelNumberColour)
        Me.tbpSettings.Controls.Add(Me.cmdChannelNumberColour)
        Me.tbpSettings.Controls.Add(Me.lblSceneFillColour)
        Me.tbpSettings.Controls.Add(Me.lblSceneUpColour)
        Me.tbpSettings.Controls.Add(Me.lblSceneBlackoutColour)
        Me.tbpSettings.Controls.Add(Me.cmdSceneFillColour)
        Me.tbpSettings.Controls.Add(Me.cmdSceneUpColour)
        Me.tbpSettings.Controls.Add(Me.cmdSceneBlackoutColour)
        Me.tbpSettings.Controls.Add(Me.lblChannelFillColour)
        Me.tbpSettings.Controls.Add(Me.lblChannelBackColour)
        Me.tbpSettings.Controls.Add(Me.lblChannelBulletColour)
        Me.tbpSettings.Controls.Add(Me.cmdChannelFillColour)
        Me.tbpSettings.Controls.Add(Me.cmdChannelBackColour)
        Me.tbpSettings.Controls.Add(Me.cmdChannelBulletColour)
        Me.tbpSettings.Controls.Add(Me.lbl2)
        Me.tbpSettings.Controls.Add(Me.lbl1)
        Me.tbpSettings.Controls.Add(Me.chkLoadonChange)
        Me.tbpSettings.Controls.Add(Me.Label1)
        Me.tbpSettings.Controls.Add(Me.numEndChannel)
        Me.tbpSettings.Location = New System.Drawing.Point(4, 22)
        Me.tbpSettings.Name = "tbpSettings"
        Me.tbpSettings.Size = New System.Drawing.Size(1826, 927)
        Me.tbpSettings.TabIndex = 4
        Me.tbpSettings.Text = "Settings"
        Me.tbpSettings.UseVisualStyleBackColor = True
        '
        'lblArduino1
        '
        Me.lblArduino1.AutoSize = True
        Me.lblArduino1.ForeColor = System.Drawing.Color.Lime
        Me.lblArduino1.Location = New System.Drawing.Point(282, 262)
        Me.lblArduino1.Name = "lblArduino1"
        Me.lblArduino1.Size = New System.Drawing.Size(49, 13)
        Me.lblArduino1.TabIndex = 319
        Me.lblArduino1.Text = "Arduino1"
        '
        'cmdSaveSettings
        '
        Me.cmdSaveSettings.Location = New System.Drawing.Point(285, 72)
        Me.cmdSaveSettings.Name = "cmdSaveSettings"
        Me.cmdSaveSettings.Size = New System.Drawing.Size(112, 50)
        Me.cmdSaveSettings.TabIndex = 314
        Me.cmdSaveSettings.Text = "Save Settings"
        Me.cmdSaveSettings.UseVisualStyleBackColor = True
        '
        'lblSceneLabelColour
        '
        Me.lblSceneLabelColour.BackColor = System.Drawing.Color.Magenta
        Me.lblSceneLabelColour.Location = New System.Drawing.Point(160, 571)
        Me.lblSceneLabelColour.Name = "lblSceneLabelColour"
        Me.lblSceneLabelColour.Size = New System.Drawing.Size(100, 23)
        Me.lblSceneLabelColour.TabIndex = 269
        Me.lblSceneLabelColour.Text = "..."
        Me.lblSceneLabelColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdSceneLabelColour
        '
        Me.cmdSceneLabelColour.Location = New System.Drawing.Point(8, 571)
        Me.cmdSceneLabelColour.Name = "cmdSceneLabelColour"
        Me.cmdSceneLabelColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdSceneLabelColour.TabIndex = 268
        Me.cmdSceneLabelColour.Text = "Scene Label Colour"
        Me.cmdSceneLabelColour.UseVisualStyleBackColor = True
        '
        'cmdSerialClear
        '
        Me.cmdSerialClear.Location = New System.Drawing.Point(1045, 35)
        Me.cmdSerialClear.Name = "cmdSerialClear"
        Me.cmdSerialClear.Size = New System.Drawing.Size(75, 23)
        Me.cmdSerialClear.TabIndex = 318
        Me.cmdSerialClear.Text = "Serial Clear"
        Me.cmdSerialClear.UseVisualStyleBackColor = True
        '
        'lblUpDownTest
        '
        Me.lblUpDownTest.AutoSize = True
        Me.lblUpDownTest.ForeColor = System.Drawing.Color.Lime
        Me.lblUpDownTest.Location = New System.Drawing.Point(450, 207)
        Me.lblUpDownTest.Name = "lblUpDownTest"
        Me.lblUpDownTest.Size = New System.Drawing.Size(49, 13)
        Me.lblUpDownTest.TabIndex = 313
        Me.lblUpDownTest.Text = "UpDown"
        '
        'txtSerialIn
        '
        Me.txtSerialIn.Location = New System.Drawing.Point(591, 34)
        Me.txtSerialIn.Multiline = True
        Me.txtSerialIn.Name = "txtSerialIn"
        Me.txtSerialIn.Size = New System.Drawing.Size(448, 560)
        Me.txtSerialIn.TabIndex = 317
        '
        'lblChannelNumberColour
        '
        Me.lblChannelNumberColour.BackColor = System.Drawing.Color.Magenta
        Me.lblChannelNumberColour.Location = New System.Drawing.Point(160, 402)
        Me.lblChannelNumberColour.Name = "lblChannelNumberColour"
        Me.lblChannelNumberColour.Size = New System.Drawing.Size(100, 23)
        Me.lblChannelNumberColour.TabIndex = 267
        Me.lblChannelNumberColour.Text = "..."
        Me.lblChannelNumberColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdChannelNumberColour
        '
        Me.cmdChannelNumberColour.Location = New System.Drawing.Point(8, 402)
        Me.cmdChannelNumberColour.Name = "cmdChannelNumberColour"
        Me.cmdChannelNumberColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdChannelNumberColour.TabIndex = 266
        Me.cmdChannelNumberColour.Text = "Channel Number Colour"
        Me.cmdChannelNumberColour.UseVisualStyleBackColor = True
        '
        'lblSceneFillColour
        '
        Me.lblSceneFillColour.BackColor = System.Drawing.Color.Black
        Me.lblSceneFillColour.Location = New System.Drawing.Point(160, 542)
        Me.lblSceneFillColour.Name = "lblSceneFillColour"
        Me.lblSceneFillColour.Size = New System.Drawing.Size(100, 23)
        Me.lblSceneFillColour.TabIndex = 265
        Me.lblSceneFillColour.Text = "..."
        Me.lblSceneFillColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblSceneFillColour.Visible = False
        '
        'lblSceneUpColour
        '
        Me.lblSceneUpColour.BackColor = System.Drawing.Color.Green
        Me.lblSceneUpColour.Location = New System.Drawing.Point(160, 513)
        Me.lblSceneUpColour.Name = "lblSceneUpColour"
        Me.lblSceneUpColour.Size = New System.Drawing.Size(100, 23)
        Me.lblSceneUpColour.TabIndex = 264
        Me.lblSceneUpColour.Text = "..."
        Me.lblSceneUpColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSceneBlackoutColour
        '
        Me.lblSceneBlackoutColour.BackColor = System.Drawing.Color.Blue
        Me.lblSceneBlackoutColour.Location = New System.Drawing.Point(160, 484)
        Me.lblSceneBlackoutColour.Name = "lblSceneBlackoutColour"
        Me.lblSceneBlackoutColour.Size = New System.Drawing.Size(100, 23)
        Me.lblSceneBlackoutColour.TabIndex = 263
        Me.lblSceneBlackoutColour.Text = "..."
        Me.lblSceneBlackoutColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdSceneFillColour
        '
        Me.cmdSceneFillColour.Location = New System.Drawing.Point(8, 542)
        Me.cmdSceneFillColour.Name = "cmdSceneFillColour"
        Me.cmdSceneFillColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdSceneFillColour.TabIndex = 262
        Me.cmdSceneFillColour.Text = "Scene Fill Colour"
        Me.cmdSceneFillColour.UseVisualStyleBackColor = True
        Me.cmdSceneFillColour.Visible = False
        '
        'cmdSceneUpColour
        '
        Me.cmdSceneUpColour.Location = New System.Drawing.Point(8, 513)
        Me.cmdSceneUpColour.Name = "cmdSceneUpColour"
        Me.cmdSceneUpColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdSceneUpColour.TabIndex = 261
        Me.cmdSceneUpColour.Text = "Scene Up Colour"
        Me.cmdSceneUpColour.UseVisualStyleBackColor = True
        '
        'cmdSceneBlackoutColour
        '
        Me.cmdSceneBlackoutColour.Location = New System.Drawing.Point(8, 484)
        Me.cmdSceneBlackoutColour.Name = "cmdSceneBlackoutColour"
        Me.cmdSceneBlackoutColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdSceneBlackoutColour.TabIndex = 260
        Me.cmdSceneBlackoutColour.Text = "Scene Blackout Colour"
        Me.cmdSceneBlackoutColour.UseVisualStyleBackColor = True
        '
        'lblChannelFillColour
        '
        Me.lblChannelFillColour.BackColor = System.Drawing.Color.Black
        Me.lblChannelFillColour.Location = New System.Drawing.Point(160, 372)
        Me.lblChannelFillColour.Name = "lblChannelFillColour"
        Me.lblChannelFillColour.Size = New System.Drawing.Size(100, 23)
        Me.lblChannelFillColour.TabIndex = 259
        Me.lblChannelFillColour.Text = "..."
        Me.lblChannelFillColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblChannelBackColour
        '
        Me.lblChannelBackColour.BackColor = System.Drawing.Color.DimGray
        Me.lblChannelBackColour.Location = New System.Drawing.Point(160, 343)
        Me.lblChannelBackColour.Name = "lblChannelBackColour"
        Me.lblChannelBackColour.Size = New System.Drawing.Size(100, 23)
        Me.lblChannelBackColour.TabIndex = 258
        Me.lblChannelBackColour.Text = "..."
        Me.lblChannelBackColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblChannelBulletColour
        '
        Me.lblChannelBulletColour.BackColor = System.Drawing.Color.Magenta
        Me.lblChannelBulletColour.Location = New System.Drawing.Point(160, 314)
        Me.lblChannelBulletColour.Name = "lblChannelBulletColour"
        Me.lblChannelBulletColour.Size = New System.Drawing.Size(100, 23)
        Me.lblChannelBulletColour.TabIndex = 257
        Me.lblChannelBulletColour.Text = "..."
        Me.lblChannelBulletColour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdChannelFillColour
        '
        Me.cmdChannelFillColour.Location = New System.Drawing.Point(8, 372)
        Me.cmdChannelFillColour.Name = "cmdChannelFillColour"
        Me.cmdChannelFillColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdChannelFillColour.TabIndex = 256
        Me.cmdChannelFillColour.Text = "Channel Fill Colour"
        Me.cmdChannelFillColour.UseVisualStyleBackColor = True
        '
        'cmdChannelBackColour
        '
        Me.cmdChannelBackColour.Location = New System.Drawing.Point(8, 343)
        Me.cmdChannelBackColour.Name = "cmdChannelBackColour"
        Me.cmdChannelBackColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdChannelBackColour.TabIndex = 255
        Me.cmdChannelBackColour.Text = "Channel Back Colour"
        Me.cmdChannelBackColour.UseVisualStyleBackColor = True
        '
        'cmdChannelBulletColour
        '
        Me.cmdChannelBulletColour.Location = New System.Drawing.Point(8, 314)
        Me.cmdChannelBulletColour.Name = "cmdChannelBulletColour"
        Me.cmdChannelBulletColour.Size = New System.Drawing.Size(146, 23)
        Me.cmdChannelBulletColour.TabIndex = 254
        Me.cmdChannelBulletColour.Text = "Channel Bullet Colour"
        Me.cmdChannelBulletColour.UseVisualStyleBackColor = True
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.BackColor = System.Drawing.Color.Black
        Me.lbl2.ForeColor = System.Drawing.Color.Yellow
        Me.lbl2.Location = New System.Drawing.Point(450, 176)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(45, 13)
        Me.lbl2.TabIndex = 252
        Me.lbl2.Text = "Label21"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.Black
        Me.lbl1.ForeColor = System.Drawing.Color.Yellow
        Me.lbl1.Location = New System.Drawing.Point(450, 150)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(39, 13)
        Me.lbl1.TabIndex = 251
        Me.lbl1.Text = "Label5"
        '
        'chkLoadonChange
        '
        Me.chkLoadonChange.AutoSize = True
        Me.chkLoadonChange.ForeColor = System.Drawing.Color.Lime
        Me.chkLoadonChange.Location = New System.Drawing.Point(8, 153)
        Me.chkLoadonChange.Name = "chkLoadonChange"
        Me.chkLoadonChange.Size = New System.Drawing.Size(105, 17)
        Me.chkLoadonChange.TabIndex = 250
        Me.chkLoadonChange.Text = "Load on Change"
        Me.chkLoadonChange.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Lime
        Me.Label1.Location = New System.Drawing.Point(5, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 246
        Me.Label1.Text = "Max Channels:"
        '
        'numEndChannel
        '
        Me.numEndChannel.Location = New System.Drawing.Point(8, 35)
        Me.numEndChannel.Maximum = New Decimal(New Integer() {2048, 0, 0, 0})
        Me.numEndChannel.Minimum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.numEndChannel.Name = "numEndChannel"
        Me.numEndChannel.Size = New System.Drawing.Size(90, 20)
        Me.numEndChannel.TabIndex = 245
        Me.numEndChannel.Value = New Decimal(New Integer() {512, 0, 0, 0})
        '
        'Label82
        '
        Me.Label82.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label82.AutoSize = True
        Me.Label82.ForeColor = System.Drawing.Color.Lime
        Me.Label82.Location = New System.Drawing.Point(1848, 9)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(42, 13)
        Me.Label82.TabIndex = 201
        Me.Label82.Text = "Master:"
        '
        'numChangeMS
        '
        Me.numChangeMS.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numChangeMS.Location = New System.Drawing.Point(1841, 354)
        Me.numChangeMS.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.numChangeMS.Name = "numChangeMS"
        Me.numChangeMS.Size = New System.Drawing.Size(57, 20)
        Me.numChangeMS.TabIndex = 278
        Me.numChangeMS.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        '
        'cmdMasterFull
        '
        Me.cmdMasterFull.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdMasterFull.Location = New System.Drawing.Point(1840, 325)
        Me.cmdMasterFull.Name = "cmdMasterFull"
        Me.cmdMasterFull.Size = New System.Drawing.Size(60, 23)
        Me.cmdMasterFull.TabIndex = 277
        Me.cmdMasterFull.Text = "Full"
        Me.cmdMasterFull.UseVisualStyleBackColor = True
        '
        'cmdMasterBlackout
        '
        Me.cmdMasterBlackout.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdMasterBlackout.Location = New System.Drawing.Point(1840, 296)
        Me.cmdMasterBlackout.Name = "cmdMasterBlackout"
        Me.cmdMasterBlackout.Size = New System.Drawing.Size(60, 23)
        Me.cmdMasterBlackout.TabIndex = 276
        Me.cmdMasterBlackout.Text = "Blackout"
        Me.cmdMasterBlackout.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.Color.Lime
        Me.Label19.Location = New System.Drawing.Point(1844, 387)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(52, 13)
        Me.Label19.TabIndex = 279
        Me.Label19.Text = "Selected:"
        '
        'txtMaster
        '
        Me.txtMaster.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMaster.Location = New System.Drawing.Point(1850, 270)
        Me.txtMaster.Name = "txtMaster"
        Me.txtMaster.Size = New System.Drawing.Size(42, 20)
        Me.txtMaster.TabIndex = 275
        Me.txtMaster.Text = "100"
        '
        'cmdOpenTouchpad
        '
        Me.cmdOpenTouchpad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdOpenTouchpad.Location = New System.Drawing.Point(1833, 801)
        Me.cmdOpenTouchpad.Name = "cmdOpenTouchpad"
        Me.cmdOpenTouchpad.Size = New System.Drawing.Size(67, 33)
        Me.cmdOpenTouchpad.TabIndex = 281
        Me.cmdOpenTouchpad.Text = "Touchpad"
        Me.cmdOpenTouchpad.UseVisualStyleBackColor = True
        '
        'cmdSelectedFull
        '
        Me.cmdSelectedFull.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdSelectedFull.Location = New System.Drawing.Point(1838, 674)
        Me.cmdSelectedFull.Name = "cmdSelectedFull"
        Me.cmdSelectedFull.Size = New System.Drawing.Size(60, 23)
        Me.cmdSelectedFull.TabIndex = 284
        Me.cmdSelectedFull.Text = "Full"
        Me.cmdSelectedFull.UseVisualStyleBackColor = True
        '
        'cmdSelectedBlackout
        '
        Me.cmdSelectedBlackout.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdSelectedBlackout.Location = New System.Drawing.Point(1838, 703)
        Me.cmdSelectedBlackout.Name = "cmdSelectedBlackout"
        Me.cmdSelectedBlackout.Size = New System.Drawing.Size(60, 23)
        Me.cmdSelectedBlackout.TabIndex = 283
        Me.cmdSelectedBlackout.Text = "Blackout"
        Me.cmdSelectedBlackout.UseVisualStyleBackColor = True
        '
        'txtSelected
        '
        Me.txtSelected.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSelected.Location = New System.Drawing.Point(1850, 648)
        Me.txtSelected.Name = "txtSelected"
        Me.txtSelected.Size = New System.Drawing.Size(42, 20)
        Me.txtSelected.TabIndex = 282
        Me.txtSelected.Text = "0"
        '
        'tmrMP3
        '
        Me.tmrMP3.Interval = 10
        '
        'tmrMP32
        '
        Me.tmrMP32.Interval = 10
        '
        'ctxCMDs
        '
        Me.ctxCMDs.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ctxDimmerAutomation, Me.ToolStripSeparator1, Me.ctxNameofbutton})
        Me.ctxCMDs.Name = "ctxCMDs"
        Me.ctxCMDs.Size = New System.Drawing.Size(150, 54)
        '
        'ctxDimmerAutomation
        '
        Me.ctxDimmerAutomation.Name = "ctxDimmerAutomation"
        Me.ctxDimmerAutomation.Size = New System.Drawing.Size(149, 22)
        Me.ctxDimmerAutomation.Text = "Automation"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(146, 6)
        '
        'ctxNameofbutton
        '
        Me.ctxNameofbutton.Name = "ctxNameofbutton"
        Me.ctxNameofbutton.Size = New System.Drawing.Size(149, 22)
        Me.ctxNameofbutton.Text = "Control Name"
        '
        'cmd4KSize
        '
        Me.cmd4KSize.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmd4KSize.Location = New System.Drawing.Point(1344, 5)
        Me.cmd4KSize.Name = "cmd4KSize"
        Me.cmd4KSize.Size = New System.Drawing.Size(67, 23)
        Me.cmd4KSize.TabIndex = 195
        Me.cmd4KSize.Text = "4k"
        Me.cmd4KSize.UseVisualStyleBackColor = True
        Me.cmd4KSize.Visible = False
        '
        'chkEditMode
        '
        Me.chkEditMode.AutoSize = True
        Me.chkEditMode.Location = New System.Drawing.Point(1546, 5)
        Me.chkEditMode.Name = "chkEditMode"
        Me.chkEditMode.Size = New System.Drawing.Size(74, 17)
        Me.chkEditMode.TabIndex = 312
        Me.chkEditMode.Text = "Edit Mode"
        Me.chkEditMode.UseVisualStyleBackColor = True
        Me.chkEditMode.Visible = False
        '
        'ctxPresetLabelActions
        '
        Me.ctxPresetLabelActions.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ctxPresetLabelEditChannels, Me.ctxPresetRenameScene, Me.ToolStripSeparator2, Me.ctxPresetLabelName})
        Me.ctxPresetLabelActions.Name = "ctxPresetLabelActions"
        Me.ctxPresetLabelActions.Size = New System.Drawing.Size(152, 76)
        '
        'ctxPresetLabelEditChannels
        '
        Me.ctxPresetLabelEditChannels.Name = "ctxPresetLabelEditChannels"
        Me.ctxPresetLabelEditChannels.Size = New System.Drawing.Size(151, 22)
        Me.ctxPresetLabelEditChannels.Text = "Edit Channels"
        '
        'ctxPresetRenameScene
        '
        Me.ctxPresetRenameScene.Name = "ctxPresetRenameScene"
        Me.ctxPresetRenameScene.Size = New System.Drawing.Size(151, 22)
        Me.ctxPresetRenameScene.Text = "Rename Scene"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(148, 6)
        '
        'ctxPresetLabelName
        '
        Me.ctxPresetLabelName.Name = "ctxPresetLabelName"
        Me.ctxPresetLabelName.Size = New System.Drawing.Size(151, 22)
        Me.ctxPresetLabelName.Text = "Control Name"
        '
        'tmrMaster
        '
        '
        'ToolTip1
        '
        Me.ToolTip1.AutoPopDelay = 30000
        Me.ToolTip1.InitialDelay = 500
        Me.ToolTip1.ReshowDelay = 100
        Me.ToolTip1.ToolTipTitle = "Description"
        '
        'cmdColourTest
        '
        Me.cmdColourTest.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdColourTest.Location = New System.Drawing.Point(1836, 840)
        Me.cmdColourTest.Name = "cmdColourTest"
        Me.cmdColourTest.Size = New System.Drawing.Size(60, 34)
        Me.cmdColourTest.TabIndex = 313
        Me.cmdColourTest.Text = "Colour Test"
        Me.cmdColourTest.UseVisualStyleBackColor = True
        '
        'ctxFixtureLabels
        '
        Me.ctxFixtureLabels.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ctxPickRGBColourTool, Me.ctxFixtureFavourites, Me.ToolStripSeparator3, Me.ctxFixtureLabelsControlName})
        Me.ctxFixtureLabels.Name = "ctxFixtureLabels"
        Me.ctxFixtureLabels.Size = New System.Drawing.Size(161, 76)
        '
        'ctxPickRGBColourTool
        '
        Me.ctxPickRGBColourTool.Name = "ctxPickRGBColourTool"
        Me.ctxPickRGBColourTool.Size = New System.Drawing.Size(160, 22)
        Me.ctxPickRGBColourTool.Text = "Pick RGB Colour"
        '
        'ctxFixtureFavourites
        '
        Me.ctxFixtureFavourites.Name = "ctxFixtureFavourites"
        Me.ctxFixtureFavourites.Size = New System.Drawing.Size(160, 22)
        Me.ctxFixtureFavourites.Text = "Favourites >"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(157, 6)
        '
        'ctxFixtureLabelsControlName
        '
        Me.ctxFixtureLabelsControlName.Name = "ctxFixtureLabelsControlName"
        Me.ctxFixtureLabelsControlName.Size = New System.Drawing.Size(160, 22)
        Me.ctxFixtureLabelsControlName.Text = "Control Name"
        '
        'Button5
        '
        Me.Button5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button5.Location = New System.Drawing.Point(1838, 880)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(60, 34)
        Me.Button5.TabIndex = 315
        Me.Button5.Text = "Colour Test"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.Location = New System.Drawing.Point(1838, 920)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(60, 25)
        Me.Button6.TabIndex = 316
        Me.Button6.Text = "Serial"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'lblAudioActive
        '
        Me.lblAudioActive.AutoSize = True
        Me.lblAudioActive.Location = New System.Drawing.Point(421, 7)
        Me.lblAudioActive.Name = "lblAudioActive"
        Me.lblAudioActive.Size = New System.Drawing.Size(112, 13)
        Me.lblAudioActive.TabIndex = 317
        Me.lblAudioActive.Text = "Incoming Audio Signal"
        '
        'vsSelected
        '
        Me.vsSelected.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.vsSelected.BackColor = System.Drawing.Color.White
        Me.vsSelected.BulletColor = System.Drawing.Color.Red
        Me.vsSelected.FillColor = System.Drawing.Color.Black
        Me.vsSelected.Location = New System.Drawing.Point(1849, 403)
        Me.vsSelected.Maximum = 255
        Me.vsSelected.Name = "vsSelected"
        Me.vsSelected.Orientation = Super_Awesome_Lighting_DMX_board_v4.modGUI.GControlOrientation.Vertical
        Me.vsSelected.Size = New System.Drawing.Size(42, 239)
        Me.vsSelected.TabIndex = 280
        Me.vsSelected.Value = 255
        '
        'vsMaster
        '
        Me.vsMaster.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.vsMaster.BackColor = System.Drawing.Color.White
        Me.vsMaster.BulletColor = System.Drawing.Color.Red
        Me.vsMaster.FillColor = System.Drawing.Color.Black
        Me.vsMaster.Location = New System.Drawing.Point(1849, 25)
        Me.vsMaster.Name = "vsMaster"
        Me.vsMaster.Orientation = Super_Awesome_Lighting_DMX_board_v4.modGUI.GControlOrientation.Vertical
        Me.vsMaster.Size = New System.Drawing.Size(42, 239)
        Me.vsMaster.TabIndex = 202
        Me.vsMaster.Value = 100
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1904, 987)
        Me.Controls.Add(Me.lblAudioActive)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.cmdColourTest)
        Me.Controls.Add(Me.chkEditMode)
        Me.Controls.Add(Me.cmd4KSize)
        Me.Controls.Add(Me.cmdOpenTouchpad)
        Me.Controls.Add(Me.cmdSelectedFull)
        Me.Controls.Add(Me.cmdSelectedBlackout)
        Me.Controls.Add(Me.txtSelected)
        Me.Controls.Add(Me.vsSelected)
        Me.Controls.Add(Me.numChangeMS)
        Me.Controls.Add(Me.cmdMasterFull)
        Me.Controls.Add(Me.cmdMasterBlackout)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtMaster)
        Me.Controls.Add(Me.vsMaster)
        Me.Controls.Add(Me.Label82)
        Me.Controls.Add(Me.tbcControls1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Super Awesome Lighting DMX Board v4"
        Me.tbcControls1.ResumeLayout(False)
        Me.tbpBanks.ResumeLayout(False)
        Me.tbpPresets.ResumeLayout(False)
        Me.tbpPresets.PerformLayout()
        CType(Me.trkPresetsVolume2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkPresetsVolume, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbpChannels.ResumeLayout(False)
        CType(Me.numChannelFadersStart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbpMusic.ResumeLayout(False)
        Me.tbpMusic.PerformLayout()
        CType(Me.numFadeIn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numFadeOut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkMusicVolume2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkMusicVolume, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbpDramaChanges.ResumeLayout(False)
        Me.tbpDramaChanges.PerformLayout()
        CType(Me.trkDramaViewVolume2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkDramaViewVolume, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbpSettings.ResumeLayout(False)
        Me.tbpSettings.PerformLayout()
        CType(Me.numEndChannel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numChangeMS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ctxCMDs.ResumeLayout(False)
        Me.ctxPresetLabelActions.ResumeLayout(False)
        Me.ctxFixtureLabels.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbcControls1 As TabControl
    Friend WithEvents tbpPresets As TabPage
    Friend WithEvents Label82 As Label
    Friend WithEvents vsMaster As GScrollBar
    Friend WithEvents numChangeMS As NumericUpDown
    Friend WithEvents cmdMasterFull As Button
    Friend WithEvents cmdMasterBlackout As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents txtMaster As TextBox
    Friend WithEvents vsSelected As GScrollBar
    Friend WithEvents cmdOpenTouchpad As Button
    Friend WithEvents cmdSelectedFull As Button
    Friend WithEvents cmdSelectedBlackout As Button
    Friend WithEvents txtSelected As TextBox
    Public WithEvents tmrMP3 As Timer
    Public WithEvents tmrMP32 As Timer
    Friend WithEvents tbpMusic As TabPage
    Friend WithEvents tbpDramaChanges As TabPage
    Friend WithEvents tbpSettings As TabPage
    Friend WithEvents tbpBanks As TabPage
    Friend WithEvents tbpChannels As TabPage
    Friend WithEvents Label1 As Label
    Friend WithEvents numEndChannel As NumericUpDown
    Friend WithEvents cmdBankDelete As Button
    Friend WithEvents cmdBankRename As Button
    Friend WithEvents cmdBankNew As Button
    Friend WithEvents chkLoadonChange As CheckBox
    Friend WithEvents cmdChannelFadersDown As Button
    Friend WithEvents cmdChannelFadersUp As Button
    Friend WithEvents numChannelFadersStart As NumericUpDown
    Friend WithEvents ctxCMDs As ContextMenuStrip
    Friend WithEvents ctxNameofbutton As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ctxDimmerAutomation As ToolStripMenuItem
    Friend WithEvents lstBanks As ListBox
    Friend WithEvents cmdEditUpdate As Button
    Friend WithEvents txtEditTime As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents chkRecordspace As CheckBox
    Friend WithEvents numFadeIn As NumericUpDown
    Friend WithEvents lblFadeIn As Label
    Friend WithEvents numFadeOut As NumericUpDown
    Friend WithEvents lblFadeOut As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents lstSongEditPresets As ListBox
    Friend WithEvents cmdEditSongCopyNew As Button
    Friend WithEvents cmdEditSongSave As Button
    Friend WithEvents cmdCreatelink As Button
    Friend WithEvents Label20 As Label
    Friend WithEvents lbleditRemaining As Label
    Friend WithEvents lbleditPositionMilli As Label
    Friend WithEvents lbleditposition As Label
    Friend WithEvents cmdEditStop As Button
    Friend WithEvents cmdEditPlay As Button
    Friend WithEvents chkEnableSongEdit As CheckBox
    Friend WithEvents lstMusicSongChanges2 As ListBox
    Friend WithEvents cmdMusicSkip2 As Button
    Friend WithEvents cmdMusicSkip As Button
    Friend WithEvents lblMusicMP3PositionMilli2 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblMusicMP3Position2 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblMusicMP3Duration2 As Label
    Friend WithEvents cmdMusicStop2 As Button
    Friend WithEvents cmdMusicPlay2 As Button
    Friend WithEvents trkMusicVolume2 As TrackBar
    Friend WithEvents lstMusicSongs2 As ListBox
    Friend WithEvents lblMusicMP3PositionMilli As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblMusicMP3Position As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblMusicMP3Duration As Label
    Friend WithEvents cmdMusicStop As Button
    Friend WithEvents cmdMusicPlay As Button
    Friend WithEvents lstMusicSongs As ListBox
    Friend WithEvents lstMusicSongChanges As ListBox
    Friend WithEvents trkMusicVolume As TrackBar
    Friend WithEvents vSongEdit As GScrollBar
    Friend WithEvents cmdPresetP7 As Button
    Friend WithEvents cmdPresetP8 As Button
    Friend WithEvents cmdPresetP5 As Button
    Friend WithEvents cmdPresetP6 As Button
    Friend WithEvents cmdPresetP3 As Button
    Friend WithEvents cmdPresetP4 As Button
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents cmdPresetsBlackoutAllInstant As Button
    Friend WithEvents cmdPresetsBlackoutAllTimer As Button
    Friend WithEvents cmdPresetP1 As Button
    Friend WithEvents cmdPresetP2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents cmdReloadChannelLocations As Button
    Friend WithEvents cmdReloadPresetLocations As Button
    Friend WithEvents cmd4KSize As Button
    Friend WithEvents lstPresetsSongChanges2 As ListBox
    Friend WithEvents cmdPresetsSkip2 As Button
    Friend WithEvents cmdPresetsSkip As Button
    Friend WithEvents lblPresetsMP3PositionMilli2 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents lblPresetsMP3Position2 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents lblPresetsMP3Duration2 As Label
    Friend WithEvents cmdPresetsStop2 As Button
    Friend WithEvents cmdPresetsPlay2 As Button
    Friend WithEvents trkPresetsVolume2 As TrackBar
    Friend WithEvents lstPresetsSongs2 As ListBox
    Friend WithEvents lblPresetsMP3PositionMilli As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents lblPresetsMP3Position As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents lblPresetsMP3Duration As Label
    Friend WithEvents cmdPresetsStop As Button
    Friend WithEvents cmdPresetsPlay As Button
    Friend WithEvents lstPresetsSongs As ListBox
    Friend WithEvents lstPresetsSongChanges As ListBox
    Friend WithEvents trkPresetsVolume As TrackBar
    Friend WithEvents lstDramaViewSongChanges2 As ListBox
    Friend WithEvents cmdDramaViewSkip2 As Button
    Friend WithEvents cmdDramaViewSkip As Button
    Friend WithEvents lblDramaViewMP3PositionMilli2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblDramaViewMP3Position2 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents lblDramaViewMP3Duration2 As Label
    Friend WithEvents cmdDramaViewStop2 As Button
    Friend WithEvents cmdDramaViewPlay2 As Button
    Friend WithEvents trkDramaViewVolume2 As TrackBar
    Friend WithEvents lstDramaViewSongs2 As ListBox
    Friend WithEvents lblDramaViewMP3PositionMilli As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents lblDramaViewMP3Position As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents lblDramaViewMP3Duration As Label
    Friend WithEvents cmdDramaViewStop As Button
    Friend WithEvents cmdDramaViewPlay As Button
    Friend WithEvents lstDramaViewSongs As ListBox
    Friend WithEvents lstDramaViewSongChanges As ListBox
    Friend WithEvents trkDramaViewVolume As TrackBar
    Friend WithEvents lstDramaPresets As ListBox
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents cmbChannelPresetSelection As ComboBox
    Friend WithEvents chkEditMode As CheckBox
    Friend WithEvents ctxPresetLabelActions As ContextMenuStrip
    Friend WithEvents ctxPresetLabelEditChannels As ToolStripMenuItem
    Friend WithEvents ctxPresetLabelName As ToolStripMenuItem
    Friend WithEvents cmdChannelsSave As Button
    Friend WithEvents lblChannelFillColour As Label
    Friend WithEvents lblChannelBackColour As Label
    Friend WithEvents lblChannelBulletColour As Label
    Friend WithEvents cmdChannelFillColour As Button
    Friend WithEvents cmdChannelBackColour As Button
    Friend WithEvents cmdChannelBulletColour As Button
    Friend WithEvents cmdDramaBlackoutAllInstant As Button
    Friend WithEvents cmdDramaBlackoutAllTimer As Button
    Friend WithEvents lblUpDownTest As Label
    Friend WithEvents cmdSceneFillColour As Button
    Friend WithEvents cmdSceneUpColour As Button
    Friend WithEvents cmdSceneBlackoutColour As Button
    Friend WithEvents lblChannelNumberColour As Label
    Friend WithEvents cmdChannelNumberColour As Button
    Friend WithEvents cmdSceneLabelColour As Button
    Friend WithEvents ctxPresetRenameScene As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents tmrMaster As Timer
    Friend WithEvents cmdSaveSettings As Button
    Public WithEvents lblSceneFillColour As Label
    Public WithEvents lblSceneUpColour As Label
    Public WithEvents lblSceneBlackoutColour As Label
    Public WithEvents lblSceneLabelColour As Label
    Friend WithEvents CustomWaves1 As CustomWaves
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents cmdColourTest As Button
    Friend WithEvents ctxFixtureLabels As ContextMenuStrip
    Friend WithEvents Button5 As Button
    Friend WithEvents ctxPickRGBColourTool As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ctxFixtureLabelsControlName As ToolStripMenuItem
    Friend WithEvents Button6 As Button
    Friend WithEvents txtSerialIn As TextBox
    Friend WithEvents cmdSerialClear As Button
    Friend WithEvents lblArduino1 As Label
    Friend WithEvents lblAudioActive As Label
    Friend WithEvents ctxFixtureFavourites As ToolStripMenuItem
End Class
