﻿Option Strict Off
Option Explicit On
Imports System.IO
Imports EnttecOpenDMX.OpenDMX
Imports System.Threading
Imports Midi
Imports System.Runtime.InteropServices
Imports System.ComponentModel
Imports NAudio.Wave
Imports System.Management

Public Class FormMain

    Dim LastSelectedChannel As Integer = 1
    Dim shiftdown As Boolean
    Dim ctrldown As Boolean
    Dim PresetFaderControlModifier As Integer = 0
    Dim PagingChanged As Boolean = False
    Dim BankChanged As Boolean = False

    'Dim NextMP3Change As Double
    Dim tmrchangedmp3 As Boolean = False
    'Dim NextMP3Change2 As Double
    Dim tmrchangedmp32 As Boolean = False
    Dim SongChangeIndexUpTo1 As Integer = -1
    Dim SongChangeIndexUpTo2 As Integer = -1

    Dim closethreads As Boolean = False
    Dim ChannelFaderPageCurrentSceneDataIndex As Integer = 0

    Dim tmrMasterUpto As Integer
    Dim tmrMasterWay As String
    Dim tmrMasterInterval As Integer

#Region "Arduino Connections"
    Sub SetupSerialConnections()
        ' Show all available COM ports.
        'For Each sp As String In My.Computer.Ports.SerialPortNames
        'ListBox1.Items.Add(sp)
        'Next

        'When the form loads
        'Enumerate available Com ports and add to ComboBox1
        Dim comPorts = Ports.SerialPort.GetPortNames

        Dim ArduinoCount As Integer = 0
        For i = 0 To UBound(comPorts)
            Dim searcher As New ManagementObjectSearcher("root\CIMV2", "SELECT * FROM Win32_PnPEntity WHERE Caption like '%(" & comPorts(i) & "%'")
            For Each queryObj As ManagementObject In searcher.Get()
                If InStr((CStr(queryObj("Caption"))), "Arduino") > 0 Then
                    'is an arduino
                    Arduinos(ArduinoCount).DeviceName = (CStr(queryObj("Caption")))
                    Arduinos(ArduinoCount).PortNo = comPorts(i)
                    ArduinoCount += 1
                End If

            Next

            'Arduinos(i).Serial = My.Computer.Ports.OpenSerialPort(comPorts(i))
            'Arduinos(i).Serial.BaudRate = 115200
            'SerialPort1.BaudRate = 115200
            'SerialPort1.Parity = Ports.Parity.None
            'SerialPort1.StopBits = IO.Ports.StopBits.One
            'SerialPort1.DataBits = 8
        Next
        Dim J As Integer = 0
        Do Until J >= Arduinos.Length
            If Arduinos(J).DeviceName <> "" Then
                Try
                    Arduinos(J).Serial = New Ports.SerialPort
                    Arduinos(J).Serial.BaudRate = 115200
                    Arduinos(J).Serial.PortName = Arduinos(J).PortNo
                    Arduinos(J).Serial.DataBits = 8
                    Arduinos(J).Serial.StopBits = IO.Ports.StopBits.One
                    Arduinos(J).Serial.Handshake = IO.Ports.Handshake.None
                    Arduinos(J).Serial.Parity = IO.Ports.Parity.None
                    Arduinos(J).Serial.Open()
                    AddHandler Arduinos(J).Serial.DataReceived, AddressOf SerialPort_DataReceived
                    Arduinos(J).Serial.Write("UID," & Arduinos(J).PortNo & vbCrLf)
                Catch
                    Arduinos(J).Serial.Close()
                End Try

            End If


            J += 1
        Loop
        'Set ComboBox1 text to first available port

        'Set remaining port attributes

    End Sub
    Structure msg1
        Dim msg As String
        Dim portname As String
    End Structure

    Delegate Sub myMethodDelegate(ByVal [text] As msg1)
    Dim myD1 As New myMethodDelegate(AddressOf myShowStringMethod)

    Private Sub SerialPort_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) ' Handles SerialPort.DataReceived
        Dim incmsg As msg1
        incmsg.msg = sender.ReadExisting
        incmsg.portname = sender.portname
        If Mid(incmsg.msg, 1, 3) = "UID" Then
            Dim a() As String = Split(incmsg.msg, ",")

            Dim I As Integer = 0
            If a.Length >= 2 Then
                Do Until I >= Arduinos.Length
                    If Arduinos(I).PortNo = incmsg.portname Then
                        Arduinos(I).UID = a(1)
                        Exit Do
                    End If
                    I += 1
                Loop
            End If


        Else
            'txtSerialIn.AppendText(myString)
        End If


        Invoke(myD1, incmsg)

    End Sub
    Sub myShowStringMethod(ByVal mymsg As msg1)


        If Mid(mymsg.msg, 1, 3) = "UID" Then
            Dim a() As String = Split(mymsg.msg, ",")

            If a.Length >= 2 Then ' not 3 = data garbled
                Dim I As Integer = 0
                Do Until I >= Arduinos.Length
                    If Arduinos(I).PortNo = mymsg.portname Then Exit Do
                    I += 1
                Loop
                'Arduinos(I).UID = a(1)
                lblArduino1.Text = "Arduino1: " & Arduinos(I).UID
            End If

        ElseIf Mid(mymsg.msg, 1, 3) = "AVU" Then
            'Serial.println("AVU," + incomingAudio);
            Dim a() As String = Split(mymsg.msg, ",")
            If a.Length = 2 Then ' not 2 = data garbled
                lblAudioActive.Text = a(1)

            End If
        Else
            'txtSerialIn.AppendText(myString)
        End If
        txtSerialIn.AppendText(mymsg.msg)
    End Sub

#End Region


#Region "Startup application"


    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim cwv As New nsCustomWaveViewer.CustomWaveViewer

        'Me.Controls.Add(cwv)
        frmMain = Me
        frmTouchPad = New FormTouchPad
        frmDimmerAutomation = New FormDimmerAutomation
        frmGradientColour = New FormColourGradient
        frmCustomColourPicker = New FormColourPicker
        ' trkVolume.Value = Player.settings.volume
        ' trkVolume2.Value = Player2.settings.volume

        SetupSerialConnections()

        Player.settings.autoStart = False
        Player2.settings.autoStart = False
        With Me.tmrMP3
            .Interval = 50
            .Start()
            .Enabled = False
        End With
        Player.controls.stop()
        Player.settings.volume = 50

        With Me.tmrMP32
            .Interval = 50
            .Start()
            .Enabled = False
        End With
        Player2.controls.stop()
        Player2.settings.volume = 50


        If Environment.GetCommandLineArgs.Length > 1 Then
            If Environment.GetCommandLineArgs(1) = "-Testmode" Then Testmode = True
        End If
        If File.Exists(Application.StartupPath & "\Testmode.txt") = True Then Testmode = True

        controlcolour = Me.BackColor

        For Each c As Windows.Forms.Control In tbpPresets.Controls
            tbpPresetsControls.Add(c)
        Next
        For Each c As Windows.Forms.Control In tbpChannels.Controls
            tbpChannelsControls.Add(c)
        Next

        'tbpPresetsControls = tbpPresets.Controls
        ' tbpChannelsControls = tbpChannels.Controls

        LoadBanksFromFile()
        LoadSettingsFromFile()
        LoadFixtureInformation()

        LoadScenesFromFile()
        GeneratePresetFormControls()
        RenamePresetFaderControls()

        GenerateChannelFormControls()
        LoadMusicTracks()

        Application.DoEvents()
        SetupThreads()

        For Each c As Windows.Forms.Control In tbpPresetsControls
            tbpPresets.Controls.Add(c)
        Next

        If Testmode = False Then
            EnttecOpenDMX.OpenDMX.start()
        End If

        For Each c As System.Windows.Forms.Control In Me.Controls
            AddHandler c.KeyDown, AddressOf Form1_KeyDown
            AddHandler c.KeyUp, AddressOf Form1_KeyUp
        Next c


        lblAudioActive.BackColor = Color.Black
        lblAudioActive.ForeColor = lblChannelNumberColour.BackColor
        Me.BackColor = Color.Black
        tbpBanks.BackColor = Color.Black
        tbpPresets.BackColor = Color.Black
        tbpChannels.BackColor = Color.Black
        tbpMusic.BackColor = Color.Black
        tbpDramaChanges.BackColor = Color.Black
        tbpSettings.BackColor = Color.Black
        tbcControls1.SelectedIndex = 1
        frmDimmerAutomation.BackColor = Color.Black
        'tbpChannels.BackColor = Color.Black
        'tbpPresets.BackColor = Color.Black
        'tbpSettings.BackColor = Color.Black
        'tbpMusic.BackColor = Color.Black
        'tbpDramaChanges.BackColor = Color.Black
        ChannelFaderPageCurrentSceneDataIndex = 1
        formopened = True
    End Sub
    Private Sub LoadFixtureInformation()
        FileOpen(1, Application.StartupPath & "\Fixtures.ini", OpenMode.Input)
        Dim I As Integer = 1
        Do Until EOF(1)
            Dim sline() As String = Split(LineInput(1), "|")
            Dim ParentChannelNo As Integer = Val(sline(0))
            FixtureControls(ParentChannelNo).BackColour = Color.FromName(sline(2))
            FixtureControls(ParentChannelNo).ForeColour = Color.FromName(sline(3))
            FixtureControls(ParentChannelNo).FixtureName = sline(1)
            FixtureControls(ParentChannelNo).IsFirst = True
            FileOpen(2, Application.StartupPath & "\Fixtures\" & FixtureControls(ParentChannelNo).FixtureName & ".fix", OpenMode.Input)
            Dim channelcount As Integer = 0
            Dim channelupto As Integer = 0
            Do Until EOF(2)
                Dim s As String = LineInput(2)
                Dim a() As String = Split(s, "=")
                If a(0) = "Channels" Then ' is channel count modifier
                    channelcount = Val(a(1))
                    s = LineInput(2)
                End If
                FixtureControls(ParentChannelNo + channelupto).BackColour = Color.FromName(sline(2))
                FixtureControls(ParentChannelNo + channelupto).ForeColour = Color.FromName(sline(3))
                FixtureControls(ParentChannelNo + channelupto).FixtureName = sline(1)
                Dim AnV() As String = Split(s, "|")
                If AnV.Length = 3 Then 'has a long description
                    FixtureControls(ParentChannelNo + channelupto).LongDescr = AnV(2).Replace("`e", vbCrLf)
                End If
                FixtureControls(ParentChannelNo + channelupto).ActionAndValues = AnV(1)
                FixtureControls(ParentChannelNo + channelupto).ChannelOfFixture = channelupto + 1
                If Mid(s, 1, 2) = "D|" Then FixtureControls(ParentChannelNo + channelupto).IsDimmable = True
                channelupto += 1
            Loop
            FileClose(2)
            ReDim FixtureControls(ParentChannelNo).Favourites(100)
            If Directory.Exists(Application.StartupPath & "\Fixtures\" & FixtureControls(ParentChannelNo).FixtureName & "\") Then
                Dim FixFavs() As String = Directory.GetFiles(Application.StartupPath & "\Fixtures\" & FixtureControls(ParentChannelNo).FixtureName & "\")
                For FavsI = 0 To FixFavs.Length - 1
                    FixtureControls(ParentChannelNo).Favourites(FavsI) = System.IO.Path.GetFileNameWithoutExtension(FixFavs(FavsI))
                Next

            End If


        Loop
        FileClose(1)
    End Sub
    Private Sub LoadSettingsFromFile()
        If Directory.Exists(Application.StartupPath & "\Save Files") = False Then
            Directory.CreateDirectory(Application.StartupPath & "\Save Files")
            Directory.CreateDirectory(Application.StartupPath & "\Save Files\Bank1")
            File.Create(Application.StartupPath & "\Save Files\Bank1\All Off.dmr")

        End If

        FileOpen(1, Application.StartupPath & "\Settings.ini", OpenMode.Input)
        Do Until EOF(1)
            Dim a() As String = Split(LineInput(1), "=")
            Select Case a(0)
                Case "ChannelCount"
                    'SetChannelCount(a(1)) - Jaycar usb module
                    numEndChannel.Value = a(1)
                Case "DimmerChannelRows"
                    ChannelControlSetsPerPage = a(1)
                Case "LoadonChange"
                    'chkLoadonChange.Checked = a(1)
                    chkLoadonChange.Checked = Convert.ToBoolean(a(1))
                Case "LastBank"
                    lstBanks.SetSelected(lstBanks.FindString(a(1)), True)
                Case "ChannelBulletColour"
                    lblChannelBulletColour.BackColor = Color.FromArgb(a(1))
                Case "ChannelBackColour"
                    lblChannelBackColour.BackColor = Color.FromArgb(a(1))
                Case "ChannelFillColour"
                    lblChannelFillColour.BackColor = Color.FromArgb(a(1))
                Case "ChannelNumberColour"
                    lblChannelNumberColour.BackColor = Color.FromArgb(a(1))
                Case "SceneBulletColour"
                    'lblSceneBulletColour.BackColor = Color.FromName(a(1))
                    lblSceneBlackoutColour.BackColor = Color.FromArgb(a(1))
                Case "SceneBackColour"
                    lblSceneUpColour.BackColor = Color.FromArgb(a(1))
                Case "SceneFillColour"
                    lblSceneFillColour.BackColor = Color.FromArgb(a(1))
                Case "SceneLabelColour"
                    lblSceneLabelColour.BackColor = Color.FromArgb(a(1))
                Case "MultipleThreadCount"
                    tChannelsMultipleThreads = Convert.ToBoolean(a(1))

            End Select
        Loop
        FileClose(1)

    End Sub
    Private Sub SaveSettingsToFile()

        File.Copy(Application.StartupPath & "\Settings.ini", Application.StartupPath & "\Settings.Backup.ini", True)
        FileOpen(1, Application.StartupPath & "\Settings.ini", OpenMode.Output)
        PrintLine(1, "ChannelCount=" & numEndChannel.Value)
        PrintLine(1, "DimmerChannelRows=" & ChannelControlSetsPerPage)
        PrintLine(1, "LoadonChange=" & chkLoadonChange.Checked)
        PrintLine(1, "LastBank=" & lstBanks.SelectedItem)
        PrintLine(1, "ChannelBulletColour=" & lblChannelBulletColour.BackColor.ToArgb)
        PrintLine(1, "ChannelBackColour=" & lblChannelBackColour.BackColor.ToArgb)
        PrintLine(1, "ChannelFillColour=" & lblChannelFillColour.BackColor.ToArgb)
        PrintLine(1, "ChannelNumberColour=" & lblChannelNumberColour.BackColor.ToArgb)
        PrintLine(1, "SceneBulletColour=" & lblSceneBlackoutColour.BackColor.ToArgb)
        PrintLine(1, "SceneBackColour=" & lblSceneUpColour.BackColor.ToArgb)
        PrintLine(1, "SceneFillColour=" & lblSceneFillColour.BackColor.ToArgb)
        PrintLine(1, "SceneLabelColour=" & lblSceneLabelColour.BackColor.ToArgb)
        PrintLine(1, "MultipleThreadCount=" & tChannelsMultipleThreads)

        FileClose(1)

    End Sub
    Private Sub LoadBanksFromFile()
        lstBanks.Items.Clear()

        For Each S As String In Directory.GetDirectories(Application.StartupPath & "\Save Files\")
            Dim a() As String = Split(S, "\")
            lstBanks.Items.Add(a(a.Length - 1))
        Next S
        Application.DoEvents()
    End Sub
    Private Sub LoadScenesFromFile()

        lstDramaPresets.Items.Clear()
        lstSongEditPresets.Items.Clear()
        cmbChannelPresetSelection.Items.Clear()
        Dim I As Integer = 1
        Dim PresetsInBank() As String = Directory.GetFiles(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\", "*.dmr")
        Do Until I >= SceneData.Length
            ReDim SceneData(I).ChannelValues(2048)
            ' SET DEFAULTS
            SceneData(I).Automation.tTimer = New Windows.Forms.Timer
            SceneData(I).Automation.tTimer.Interval = 100
            SceneData(I).Automation.tTimer.Tag = I
            AddHandler SceneData(I).Automation.tTimer.Tick, AddressOf tmrPreset_Tick

            'lstDramaPresets.Items.Add(SceneData(I).SceneName)
            'cmbChannelPresetSelection.Items.Add(I & " | " & SceneData(I).SceneName)


            If I <= PresetsInBank.Length Then    '---------- IS A SAVE FILE ----------------
                Dim a1() As String = Split(PresetsInBank(I - 1), "\")
                SceneData(I).SceneName = Mid(a1(a1.Length - 1), 1, a1(a1.Length - 1).Length - 4)
                lstDramaPresets.Items.Add(SceneData(I).SceneName)
                lstSongEditPresets.Items.Add(SceneData(I).SceneName)

                cmbChannelPresetSelection.Items.Add(I & " | " & SceneData(I).SceneName)

                SceneData(I).Automation.Max = 100 ' Set Default
                SceneData(I).Automation.Min = 0 ' Set Default
                SceneData(I).Automation.TimeBetweenMinAndMax = 0 ' Set Default

                FileOpen(1, Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & SceneData(I).SceneName & ".dmr", OpenMode.Input)
                Do Until EOF(1)
                    Dim a() As String = Split(LineInput(1), "|")
                    Select Case a(0)
                        Case "M"
                            a(0) = "P"
                        Case "P"
                            a(1) = 0 'sets preset starting value to 0 because whats the point of something going up on bank change?
                            SceneData(I).MasterValue = a(1)
                        Case "ChangeMS"
                            SceneData(I).Automation.TimeBetweenMinAndMax = a(1)
                        Case Is > 0
                            With SceneData(I).ChannelValues(a(0))
                                .Automation.tTimer = New Windows.Forms.Timer
                                .Automation.tTimer.Interval = 100 ' Set Default
                                .Automation.tTimer.Tag = I & "|" & a(0)
                                .Automation.ProgressInOrder = True
                                .Automation.ProgressLoop = True
                                .Automation.ProgressRandomTimed = False
                                .Automation.ProgressSoundActivated = False
                                .Automation.ProgressList = New List(Of Integer)

                                Dim tempTimerEnabled As Boolean = False
                                For Each s As String In a
                                    Dim b() As String = Split(s, ",")
                                    Select Case b(0) 'SceneData(I).ChannelValues(a(0))
                                        Case "v"
                                            .Value = b(1)
                                        Case "TimerEnabled", "timerenabled"
                                            tempTimerEnabled = Convert.ToBoolean(b(1))
                                        Case "AutoTimeBetween"
                                            If b(1) = 0 Then
                                                .Automation.tTimer.Interval = 100
                                            Else
                                                .Automation.tTimer.Interval = b(1)
                                            End If

                                        Case "RandomStart"
                                            .Automation.ProgressRandomTimed = Convert.ToBoolean(b(1))
                                        Case "InOrder"
                                            .Automation.ProgressInOrder = Convert.ToBoolean(b(1))
                                        Case "RandomSound"
                                            .Automation.ProgressSoundActivated = Convert.ToBoolean(b(1))
                                        Case "IsLooped"
                                            .Automation.ProgressLoop = Convert.ToBoolean(b(1))
                                        Case "ProgressList"
                                            If b.Length = 1 Then
                                                'nothing in progress list
                                            Else

                                                For Each iList As String In b
                                                    If Not iList = "ProgressList" Then
                                                        .Automation.ProgressList.Add(Val(iList))
                                                    End If
                                                Next
                                            End If


                                    End Select
                                Next s
                                .Automation.tTimer.Enabled = tempTimerEnabled
                                AddHandler .Automation.tTimer.Tick, AddressOf tmrTimer_Tick
                                '.Automation.IntervalSteps = (.Automation.Max - .Automation.Min) / (.Automation.TimeBetweenMinAndMax / 10)
                            End With

                    End Select


                Loop
                Dim I2 As Integer = 1
                Do Until I2 >= SceneData(I).ChannelValues.Length
                    If SceneData(I).ChannelValues(I2).Automation.tTimer Is Nothing Then
                        SceneData(I).ChannelValues(I2).Automation.tTimer = New Windows.Forms.Timer
                        SceneData(I).ChannelValues(I2).Automation.tTimer.Tag = I & "|" & I2
                        AddHandler SceneData(I).ChannelValues(I2).Automation.tTimer.Tick, AddressOf tmrTimer_Tick
                    End If
                    I2 += 1
                Loop
                FileClose(1)

            Else '---------- IS NO SAVE FILE ----------------

                SceneData(I).SceneName = ""
                'lstDramaPresets.Items.Add(SceneData(I).SceneName)
                cmbChannelPresetSelection.Items.Add(I & " | " & SceneData(I).SceneName)

                Dim I1 As Integer = 1

                SceneData(I).MasterValue = 0
                SceneData(I).Automation.TimeBetweenMinAndMax = 1000
                SceneData(I).Automation.Max = 100
                SceneData(I).Automation.Min = 0

                Do Until I1 >= ChannelFaders.Count

                    With SceneData(I).ChannelValues(I1)
                        .Automation.tTimer = New Windows.Forms.Timer
                        .Value = 0
                        .Automation.tTimer.Interval = 100
                        .Automation.tTimer.Enabled = False
                        .Automation.tTimer.Tag = I & "|" & I1
                        .Automation.ProgressInOrder = False
                        .Automation.ProgressLoop = False
                        .Automation.ProgressRandomTimed = False
                        .Automation.ProgressSoundActivated = False
                    End With
                    AddHandler SceneData(I).ChannelValues(I1).Automation.tTimer.Tick, AddressOf tmrTimer_Tick
                    I1 += 1
                Loop

            End If


















            I += 1
        Loop



        If cmbChannelPresetSelection.SelectedIndex = -1 Then cmbChannelPresetSelection.SelectedIndex = 0



        'Dim I As Integer = 1
        'Do Until I >= PresetControls.Length
        '    If PresetControls(I).PresetName = "" Then Exit Do

        '    FileOpen(1, Application.StartupPath & "\Save Files\" & cmbBank.SelectedItem & "\" & PresetControls(I).PresetName & ".dmr", OpenMode.Input)
        '    Do Until EOF(1)
        '        Dim a() As String = Split(LineInput(1), "|")
        '        Select Case a(0)
        '            Case "M"
        '                a(0) = "P"
        '            Case "P"
        '                a(1) = 0 'sets preset starting value to 0 because whats the point of something going up on bank change?
        '                PresetControls(I).vScroll.Value = a(1)
        '                PresetControls(I).vtxtBox.Text = a(1)
        '                If a(1) > 0 Then
        '                    PresetControls(I).cmdTouchbutton.BackColor = Color.Red
        '                End If
        '            Case "ChangeMS"
        '                PresetControls(I).Automation.numChangeMS.Value = a(1)
        '            Case Is > 0
        '                With PresetControls(I).Dmrs(a(0))
        '                    For Each s As String In a
        '                        Dim b() As String = Split(s, ",")
        '                        Select Case b(0)
        '                            Case "v"
        '                                '.vScroll.Value = b(1)
        '                                .vtxtBox.Text = b(1)
        '                            Case "tmr"
        '                                .Automation.tTimer.Interval = b(1)
        '                            Case "timerenabled"
        '                                .Automation.tTimer.Enabled = Convert.ToBoolean(b(1))
        '                            Case "AutoMax"
        '                                .Automation.Max = b(1)
        '                            Case "AutoMin"
        '                                .Automation.Min = b(1)
        '                            Case "AutoTimeBetween"
        '                                .Automation.Timebetween = b(1)
        '                            Case "RandomStart"
        '                                .Automation.randomstart = Convert.ToBoolean(b(1))
        '                        End Select
        '                    Next s
        '                End With

        '        End Select

        '    Loop

        '    FileClose(1)

        '    I += 1
        'Loop

        'Try
        '    FileClose(1)
        'Catch ex As Exception

        'End Try
    End Sub

    Private Sub cmdReloadChannelLocations_Click(sender As Object, e As EventArgs) Handles cmdReloadChannelLocations.Click
        GenerateChannelFormControls()
    End Sub

    Private Sub cmdReloadPresetLocations_Click(sender As Object, e As EventArgs) Handles cmdReloadPresetLocations.Click
        GeneratePresetFormControls()
    End Sub
    Private Sub SetupThreads()

        If tChannelsMultipleThreads = False Then
            tChannels(1) = New Thread(AddressOf threadloop)
            tChannels(1).Name = "tChannel"
            tChannels(1).Start()
        Else
            Dim I As Integer = 0
            Do Until I >= numEndChannel.Value
                tChannels(I) = New Thread(Sub() Me.MultipleThreadLoops(I))
                tChannels(I).Name = "tChannel" & I
                tChannels(I).Start()
                I += 1
            Loop

        End If

        tCrashResist = New Thread(AddressOf CrashResistLoop)
        tCrashResist.Name = "tCrashResist"
        tCrashResist.Start()


    End Sub
    Private Sub GenerateChannelFormControls()
        'tbpChannels.Controls.Clear()
        'tbpChannels.Controls.Add(cmdReloadChannelLocations)
        'tbpChannels.Controls.Add(numChannelFadersStart)
        'tbpChannels.Controls.Add(cmdChannelFadersDown)
        'tbpChannels.Controls.Add(cmdChannelFadersUp)

        'For Each c As Windows.Forms.Control In tbpChannelsControls
        '    ' If tbpChannels.Controls.Contains(c) = False Then
        '    tbpChannels.Controls.Add(c)
        '    'End If
        'Next

        Dim StartX As Integer = 12
        Dim StartY As Integer = 24
        Dim IntervalX As Integer = 35
        Dim IntervalY As Integer = 289
        'Dim ChanXupto As Integer = StartX - IntervalX
        'Dim ChanYupto As Integer = StartY
        Dim cFixtureDescrYDiff As Integer = 249
        Dim vScrollXDiff As Integer = 0 '-3
        Dim vScrollYDiff As Integer = 26
        Dim sButtonXDiff As Integer = 0 '-3
        Dim sButtonYDiff As Integer = 197
        Dim vtxtBoxXDiff As Integer = 0 '-3
        Dim vtxtBoxYDiff As Integer = 226

        Dim XUpTo As Integer = StartX
        Dim YUpTo As Integer = StartY


        Dim RunningRowNum As Integer = 1

        Dim I As Integer = 1

        frmMain.Enabled = False

        Do Until I >= ChannelFaders.Length

            If ChannelFaders(I).cFixtureDescr Is Nothing Then ChannelFaders(I).cFixtureDescr = New Label

            If ToolTip1.GetToolTip(ChannelFaders(I).cFixtureDescr).Count = 0 Then
                ToolTip1.SetToolTip(ChannelFaders(I).cFixtureDescr, FixtureControls(I).LongDescr)
            End If
            With ChannelFaders(I).cFixtureDescr
                .AutoSize = False
                .Size = New Point(34, 16)
                .ContextMenuStrip = ctxFixtureLabels
                If Not FixtureControls(I).FixtureName = "" Then
                    .BackColor = FixtureControls(I).BackColour
                    .ForeColor = FixtureControls(I).ForeColour
                    Dim a() As String = Split(FixtureControls(I).ActionAndValues, ",")
                    .Text = a(0)
                    .Tag = I
                    .Name = "dmrlblFC" & I
                    .Visible = True
                Else
                    .ForeColor = Color.BlueViolet
                    .BackColor = Color.Black
                    .Text = I
                    .Tag = I
                    .Name = "dmrlblC" & I
                    .Visible = False
                End If
            End With

            If ChannelFaders(I).cChannelLabel Is Nothing Then ChannelFaders(I).cChannelLabel = New Label
            With ChannelFaders(I).cChannelLabel
                .AutoSize = False
                .Size = New Point(26, 13)
                If FixtureControls(I).IsFirst = True Then
                    .Text = FixtureControls(I).FixtureName
                    .AutoSize = True
                    .BringToFront()
                Else
                    .Text = I
                End If
                .Tag = I
                .Name = "dmrlblTop" & I
                .ForeColor = lblChannelNumberColour.BackColor
            End With

            If ChannelFaders(I).cSelected Is Nothing Then ChannelFaders(I).cSelected = New Button
            With ChannelFaders(I).cSelected
                .Size = New Point(23, 23)
                .Text = "S"
                .ContextMenuStrip = ctxCMDs
                .Name = "dmrbtn" & I
                .BackColor = controlcolour
                .Tag = I
            End With

            If ChannelFaders(I).cFader Is Nothing Then ChannelFaders(I).cFader = New GScrollBar
            With ChannelFaders(I).cFader
                '.LargeChange = 1
                .Orientation = GControlOrientation.Vertical
                .BackColor = lblChannelBackColour.BackColor
                .FillColor = lblChannelFillColour.BackColor
                .BulletColor = lblChannelBulletColour.BackColor
                .Maximum = 255
                .Value = 0 '255
                .Size = New System.Drawing.Size(23, 168)
                .Name = "dmrvs" & I
                .Tag = I
            End With

            If ChannelFaders(I).cTxtVal Is Nothing Then ChannelFaders(I).cTxtVal = New TextBox
            With ChannelFaders(I).cTxtVal
                .Size = New Point(24, 20)
                '.BackColor = controlcolour
                .BackColor = Color.Black
                .ForeColor = lblChannelNumberColour.BackColor
                .Text = "0"
                .Name = "dmrtxtv" & I
                .Tag = I
            End With

            'If ChannelFaders(I).cLongDescr Is Nothing Then ChannelFaders(I).cLongDescr = New ToolTip
            'With ChannelFaders(I).cLongDescr
            '    '.BackColor = controlcolour
            '    .BackColor = Color.Black
            '    .ForeColor = lblChannelNumberColour.BackColor
            '    .
            '    .Name = "dmrtxtv" & I
            '    .Tag = I
            'End With


            ChannelFaders(I).cChannelLabel.Location = New Point(StartX + XUpTo, StartY + YUpTo)
            ChannelFaders(I).cFader.Location = New Point(StartX + XUpTo + vScrollXDiff, StartY + YUpTo + vScrollYDiff)
            ChannelFaders(I).cSelected.Location = New Point(StartX + XUpTo + sButtonXDiff, StartY + YUpTo + sButtonYDiff)
            ChannelFaders(I).cTxtVal.Location = New Point(StartX + XUpTo + vtxtBoxXDiff, StartY + YUpTo + vtxtBoxYDiff)
            ChannelFaders(I).cFixtureDescr.Location = New Point(StartX + XUpTo, StartY + YUpTo + cFixtureDescrYDiff)

            RemoveHandler ChannelFaders(I).cFader.ValueChanged, AddressOf cFader_Scroll
            AddHandler ChannelFaders(I).cFader.ValueChanged, AddressOf cFader_Scroll

            RemoveHandler ChannelFaders(I).cSelected.Click, AddressOf cSelected_Click
            AddHandler ChannelFaders(I).cSelected.Click, AddressOf cSelected_Click

            RemoveHandler ChannelFaders(I).cFixtureDescr.DoubleClick, AddressOf cFixtureDescr_DoubleClick
            AddHandler ChannelFaders(I).cFixtureDescr.DoubleClick, AddressOf cFixtureDescr_DoubleClick

            RemoveHandler ChannelFaders(I).cTxtVal.TextChanged, AddressOf cTxtVal_TextChanged
            AddHandler ChannelFaders(I).cTxtVal.TextChanged, AddressOf cTxtVal_TextChanged

            If tbpChannels.Controls.Contains(ChannelFaders(I).cFader) = False Then tbpChannels.Controls.Add(ChannelFaders(I).cFader)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cSelected) = False Then tbpChannels.Controls.Add(ChannelFaders(I).cSelected)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cFixtureDescr) = False Then tbpChannels.Controls.Add(ChannelFaders(I).cFixtureDescr)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cTxtVal) = False Then tbpChannels.Controls.Add(ChannelFaders(I).cTxtVal)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cChannelLabel) = False Then tbpChannels.Controls.Add(ChannelFaders(I).cChannelLabel)




            XUpTo += IntervalX

            If StartX + XUpTo + vScrollXDiff + ChannelFaders(I).cFixtureDescr.Size.Width > tbpChannels.Size.Width Then
                XUpTo = StartX
                YUpTo += IntervalY
                RunningRowNum += 1
            End If
            If StartY + YUpTo + cFixtureDescrYDiff > tbpChannels.Size.Height Then

                GoTo DoneGeneration
                Exit Do
            End If
            'If RunningRowNum > DimmerChannelRows Then
            '    GoTo DoneGeneration
            '    Exit Do
            'End If

            I += 1

        Loop

        numChannelFadersStart.Value = 1


DoneGeneration:

        cmdChannelFadersUp.Text = "+" & I
        cmdChannelFadersDown.Text = "-" & I
        ChannelControlSetsPerPage = I
        I += 1
        Do Until I >= ChannelFaders.Length
            If tbpChannels.Controls.Contains(ChannelFaders(I).cFader) = True Then tbpChannels.Controls.Add(ChannelFaders(I).cFader)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cSelected) = True Then tbpChannels.Controls.Remove(ChannelFaders(I).cSelected)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cFixtureDescr) = True Then tbpChannels.Controls.Remove(ChannelFaders(I).cFixtureDescr)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cTxtVal) = True Then tbpChannels.Controls.Remove(ChannelFaders(I).cTxtVal)
            If tbpChannels.Controls.Contains(ChannelFaders(I).cChannelLabel) = True Then tbpChannels.Controls.Remove(ChannelFaders(I).cChannelLabel)
            I += 1
        Loop

        frmMain.Enabled = True

        For Each c As System.Windows.Forms.Control In tbpChannels.Controls
            AddHandler c.KeyDown, AddressOf Form1_KeyDown
            AddHandler c.KeyUp, AddressOf Form1_KeyUp
        Next c

        RebuildTextOnChannelLabels()







    End Sub
    Sub GeneratePresetFormControls()
        tbpPresets.Controls.Clear()

        For Each c As Windows.Forms.Control In tbpPresetsControls
            tbpPresets.Controls.Add(c)
        Next

        ' lstDramaPresets.Items.Clear()
        'cmbChannelPresetSelection.Items.Clear()

        Dim StartX As Integer = 8
        Dim StartY As Integer = 8
        Dim IntervalX As Integer = 301 '546
        Dim IntervalY As Integer = 48
        'Dim vscrDiffX As Integer = 119
        'Dim vscrDiffY As Integer = 0
        Dim txtDiffX As Integer = 119 '364
        Dim txtDiffY As Integer = 0
        Dim numChangeMSDiffX As Integer = 119 '364
        Dim numChangeMSDiffY As Integer = 21
        Dim cmdBlackoutDiffX As Integer = 231 '170 '415
        Dim cmdBlackoutDiffY As Integer = 0 ' -1
        Dim cmdFullDiffX As Integer = 170 '415
        Dim cmdFullDiffY As Integer = 0 '21 - 1

        Dim XUpTo As Integer = 0
        Dim YUpTo As Integer = 0

        Dim RunningColumnNum As Integer = 1

        Dim I As Integer = 1

        Dim PresetModifier As Integer = 0
        If cmdPresetP1.BackColor = Color.Red Then PresetModifier = 0
        If cmdPresetP2.BackColor = Color.Red Then PresetModifier = PresetFadersTotal
        If cmdPresetP3.BackColor = Color.Red Then PresetModifier = PresetFadersTotal * 2
        If cmdPresetP4.BackColor = Color.Red Then PresetModifier = PresetFadersTotal * 3
        If cmdPresetP5.BackColor = Color.Red Then PresetModifier = PresetFadersTotal * 4
        If cmdPresetP6.BackColor = Color.Red Then PresetModifier = PresetFadersTotal * 5

        Do Until I > PresetFaders.Count - 1

            PresetFaders(I).cAutoTime = New Windows.Forms.NumericUpDown
            With PresetFaders(I).cAutoTime
                .Size = New Point(50, 23)
                .Name = "prsnumAutoTime" & (I + PresetModifier)
                .BackColor = Color.Black
                .ForeColor = lblSceneLabelColour.BackColor
                .Tag = I + PresetModifier
                .Maximum = 10000
                .Minimum = 0
                .Value = 2000
            End With

            PresetFaders(I).cBlackout = New Button
            With PresetFaders(I).cBlackout
                .Size = New Point(60, 42) '(60, 22)
                .Text = "Blackout"
                .Name = "prscmdBlackout" & (I + PresetModifier)
                '.BackColor = controlcolour
                .BackColor = lblSceneBlackoutColour.BackColor
                .ForeColor = lblSceneLabelColour.BackColor
                .FlatStyle = FlatStyle.Flat
                .Tag = I + PresetModifier
            End With

            PresetFaders(I).cFull = New Button
            With PresetFaders(I).cFull
                .Size = New Point(60, 42) '(60, 22)
                .Text = "Full"
                .Name = "prscmdFull" & (I + PresetModifier)
                '.BackColor = controlcolour
                .BackColor = Color.Black
                .ForeColor = lblSceneLabelColour.BackColor
                .FlatStyle = FlatStyle.Flat
                .Tag = I + PresetModifier
            End With

            PresetFaders(I).cPresetName = New Label
            With PresetFaders(I).cPresetName
                .Size = New Point(113, 42)
                .Text = I & " | " & SceneData(I).SceneName
                .Name = "prslbl" & (I + PresetModifier)
                .BackColor = Color.Black
                .ForeColor = lblSceneLabelColour.BackColor
                .BorderStyle = BorderStyle.FixedSingle
                .Tag = I + PresetModifier
                .ContextMenuStrip = ctxPresetLabelActions
            End With

            'PresetFaders(I).cFader = New GScrollBar
            'With PresetFaders(I).cFader
            '    '.LargeChange = 1
            '    .Orientation = GControlOrientation.Horizontal
            '    .BackColor = lblSceneBackColour.BackColor
            '    .FillColor = lblSceneFillColour.BackColor
            '    .BulletColor = lblSceneBulletColour.BackColor
            '    .Maximum = 100
            '    .Value = 0
            '    .Size = New System.Drawing.Size(239, 42)
            '    .Name = "prsvScroll" & (I + PresetModifier)
            '    .Tag = I + PresetModifier
            'End With

            PresetFaders(I).cTxtVal = New TextBox
            With PresetFaders(I).cTxtVal
                .Size = New Point(50, 23)
                .BackColor = Color.Black
                .ForeColor = lblSceneLabelColour.BackColor
                .Text = "0"
                .Name = "prsvtxt" & (I + PresetModifier)
                .Tag = I + PresetModifier
            End With




            PresetFaders(I).cPresetName.Location = New Point(StartX + XUpTo, StartY + YUpTo)
            'PresetFaders(I).cFader.Location = New Point(StartX + XUpTo + vscrDiffX, StartY + YUpTo + vscrDiffY)
            PresetFaders(I).cTxtVal.Location = New Point(StartX + XUpTo + txtDiffX, StartY + YUpTo + txtDiffY)
            PresetFaders(I).cAutoTime.Location = New Point(StartX + XUpTo + numChangeMSDiffX, StartY + YUpTo + numChangeMSDiffY)
            PresetFaders(I).cBlackout.Location = New Point(StartX + XUpTo + cmdBlackoutDiffX, StartY + YUpTo + cmdBlackoutDiffY)
            PresetFaders(I).cFull.Location = New Point(StartX + XUpTo + cmdFullDiffX, StartY + YUpTo + cmdFullDiffY)



            'AddHandler PresetFaders(I).cFader.ValueChanged, AddressOf cPresetFader_Scroll
            AddHandler PresetFaders(I).cTxtVal.TextChanged, AddressOf cPresetTxtVal_TextChanged
            AddHandler PresetFaders(I).cAutoTime.ValueChanged, AddressOf cAutoTime_ValueChanged
            AddHandler PresetFaders(I).cBlackout.Click, AddressOf cPresetBlackout_Click
            AddHandler PresetFaders(I).cFull.Click, AddressOf cPresetFull_Click


            tbpPresets.Controls.Add(PresetFaders(I).cPresetName)
            'tbpPresets.Controls.Add(PresetFaders(I).cFader)
            tbpPresets.Controls.Add(PresetFaders(I).cTxtVal)
            tbpPresets.Controls.Add(PresetFaders(I).cAutoTime)
            tbpPresets.Controls.Add(PresetFaders(I).cBlackout)
            tbpPresets.Controls.Add(PresetFaders(I).cFull)




            YUpTo += IntervalY

            If StartY + YUpTo + PresetFaders(I).cPresetName.Size.Height >= lstPresetsSongs.Location.Y Then
                YUpTo = 0
                XUpTo += IntervalX
                RunningColumnNum += 1
            End If
            If StartX + XUpTo + cmdBlackoutDiffX + PresetFaders(I).cBlackout.Size.Width >= cmdPresetP1.Location.X Then
                GoTo DoneGeneration
                Exit Do
            End If




            I += 1
        Loop




DoneGeneration:

        PresetFadersTotal = I

    End Sub

    Private Sub RenamePresetFaderControls()
        PagingChanged = True
        Dim I As Integer = 1

        If cmdPresetP1.BackColor = Color.Red Then PresetFaderControlModifier = 0
        If cmdPresetP2.BackColor = Color.Red Then PresetFaderControlModifier = PresetFadersTotal
        If cmdPresetP3.BackColor = Color.Red Then PresetFaderControlModifier = PresetFadersTotal * 2
        If cmdPresetP4.BackColor = Color.Red Then PresetFaderControlModifier = PresetFadersTotal * 3
        If cmdPresetP5.BackColor = Color.Red Then PresetFaderControlModifier = PresetFadersTotal * 4
        If cmdPresetP6.BackColor = Color.Red Then PresetFaderControlModifier = PresetFadersTotal * 5

        Do Until I > PresetFadersTotal
            If Not I + PresetFaderControlModifier >= PresetFaders.Length Then

                PresetFaders(I).cAutoTime.Tag = I + PresetFaderControlModifier
                PresetFaders(I).cAutoTime.Name = "prsnumAutoTime" & (I + PresetFaderControlModifier)
                PresetFaders(I).cAutoTime.Value = SceneData(I + PresetFaderControlModifier).Automation.TimeBetweenMinAndMax

                PresetFaders(I).cBlackout.Tag = I + PresetFaderControlModifier
                PresetFaders(I).cBlackout.Name = "prscmdBlackout" & (I + PresetFaderControlModifier)

                PresetFaders(I).cFull.Tag = I + PresetFaderControlModifier
                PresetFaders(I).cFull.Name = "prscmdFull" & (I + PresetFaderControlModifier)

                PresetFaders(I).cPresetName.Tag = I + PresetFaderControlModifier
                PresetFaders(I).cPresetName.Name = "prslbl" & (I + PresetFaderControlModifier)
                PresetFaders(I).cPresetName.Text = (I + PresetFaderControlModifier) & " | " & SceneData(I + PresetFaderControlModifier).SceneName

                'PresetFaders(I).cFader.Tag = I + PresetFaderControlModifier
                'PresetFaders(I).cFader.Name = "prsvScroll" & (I + PresetFaderControlModifier)
                'PresetFaders(I).cFader.Value = SceneData(I + PresetFaderControlModifier).MasterValue

                PresetFaders(I).cTxtVal.Tag = I + PresetFaderControlModifier
                PresetFaders(I).cTxtVal.Name = "prsvtxt" & (I + PresetFaderControlModifier)
                PresetFaders(I).cTxtVal.Text = SceneData(I + PresetFaderControlModifier).MasterValue

            Else
                PresetFaders(I).cPresetName.Text = ""

            End If


            I += 1
            If I > PresetFaders.Length Then
                I = PresetFadersTotal + 5
            End If
        Loop
        PagingChanged = False
    End Sub

#End Region

#Region "Start Channel Fader Controls"
    Private Sub cmdChannelFadersUp_Click(sender As Object, e As EventArgs) Handles cmdChannelFadersUp.Click
        If numChannelFadersStart.Value + Val(Mid(sender.text, 2)) > (numEndChannel.Value + 8) Then
            ' numChannelFadersStart.Value = 254 - Val(Mid(sender.text, 2))
        Else
            numChannelFadersStart.Value += Val(Mid(sender.text, 2))
        End If

    End Sub
    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.Shift = True Then
            shiftdown = True
            'Label2.Text = "Shift Down"
        ElseIf e.Control = True Then
            ctrldown = True
            'Label2.Text = "Ctrl Down"
        ElseIf e.KeyCode = Keys.Escape Then
            cmdUnselectAll_Click(sender, Nothing)
        End If
    End Sub

    Private Sub Form1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        If shiftdown = True Then
            shiftdown = False
            lblUpDownTest.Text = "Shift Up"
        End If
        If ctrldown = True Then
            ctrldown = False
            lblUpDownTest.Text = "Ctrl Up"
        End If

    End Sub
    Private Sub cmdUnselectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'ChannelFaders(I).cSelected
        Dim J As Integer = 1
        Do Until J >= ChannelFaders.Length
            If Not ChannelFaders(J).cSelected Is Nothing Then
                ChannelFaders(J).cSelected.BackColor = controlcolour
            End If
            J += 1
        Loop

        Dim SceneIndex As Integer = 1
        Do Until SceneData(SceneIndex).SceneName = Split(cmbChannelPresetSelection.SelectedItem, "| ")(1) : SceneIndex += 1 : Loop
        Dim I As Integer = 1
        Do Until I >= SceneData(SceneIndex).ChannelValues.Length
            SceneData(SceneIndex).ChannelValues(I).Selected = False
            I += 1
        Loop


    End Sub

    Private Sub cmdChannelFadersDown_Click(sender As Object, e As EventArgs) Handles cmdChannelFadersDown.Click
        If numChannelFadersStart.Value - Val(Mid(sender.text, 2)) < 1 Then
            numChannelFadersStart.Value = 1
        Else
            numChannelFadersStart.Value -= Val(Mid(sender.text, 2))
        End If

    End Sub
    Private Sub numChannelFadersStart_ValueChanged(sender As Object, e As EventArgs) Handles numChannelFadersStart.ValueChanged
        If formopened = False Then Exit Sub
        RebuildTextOnChannelLabels()
    End Sub
    Private Sub RebuildTextOnChannelLabels()
        If formopened = False Then Exit Sub
        FadersRenaming = True
        Dim I As Integer = 1
        Dim uptoChannel As Integer = numChannelFadersStart.Value
        Dim SceneIndex As Integer = 1
        Do Until SceneData(SceneIndex).SceneName = Split(cmbChannelPresetSelection.SelectedItem, "| ")(1) : SceneIndex += 1 : Loop

        Do Until I > ChannelControlSetsPerPage
            '  If I > ChannelControlSetsPerPage Then Exit Sub

            With ChannelFaders(I).cChannelLabel
                If FixtureControls(uptoChannel).IsFirst = True Then
                    .Text = FixtureControls(uptoChannel).FixtureName
                    .AutoSize = True
                    .BringToFront()
                Else
                    .Text = uptoChannel
                    .AutoSize = False
                End If

                .Name = "dmrlblTop" & I
                .Tag = uptoChannel
                .Visible = True
            End With

            With ChannelFaders(I).cSelected
                .Name = "dmrlblbtn" & I
                .Tag = uptoChannel
                .Visible = True
                If SceneData(SceneIndex).ChannelValues(uptoChannel).Selected = True Then
                    .BackColor = Color.Red
                Else
                    .BackColor = controlcolour
                End If
            End With

            With ChannelFaders(I).cFader
                .Name = "dmrlblvs" & I
                .Tag = uptoChannel
                .Visible = True
                .Value = SceneData(SceneIndex).ChannelValues(uptoChannel).Value
            End With

            With ChannelFaders(I).cTxtVal
                .Name = "dmrtxtv" & I
                .Tag = uptoChannel
                .Visible = True
                .Text = SceneData(SceneIndex).ChannelValues(uptoChannel).Value
            End With

            With ChannelFaders(I).cFixtureDescr

                If Not FixtureControls(uptoChannel).FixtureName = "" Then
                    .BackColor = FixtureControls(uptoChannel).BackColour
                    .ForeColor = FixtureControls(uptoChannel).ForeColour
                    Dim a() As String = Split(FixtureControls(uptoChannel).ActionAndValues, ",")
                    .Text = a(0)
                    .Tag = uptoChannel
                    .Name = "dmrlblFixtureChannel" & I
                    .Visible = True
                Else
                    .Text = uptoChannel
                    .Tag = uptoChannel
                    .Name = "dmrlblFixtureChannel" & I
                    .Visible = False
                End If



            End With

            UpdateFixtureLabel(I)
            ChannelFaders(I).internalChannelFaderNumber = uptoChannel

            If uptoChannel > numEndChannel.Value Or uptoChannel >= ChannelFaders.Count Then
                ChannelFaders(I).cChannelLabel.Visible = False
                ChannelFaders(I).cSelected.Visible = False
                ChannelFaders(I).cFader.Visible = False
                ChannelFaders(I).cTxtVal.Visible = False
                ChannelFaders(I).cFixtureDescr.Visible = False
            End If

            uptoChannel += 1
            I += 1
        Loop
        FadersRenaming = False
    End Sub

    Private Sub cFader_Scroll(ByVal Sender As System.Object) 'ByVal sender As System.Object, ByVal e As System.EventArgs)
        If otherChanged = True Then Exit Sub
        If FadersRenaming = True Then Exit Sub
        Dim SceneIndex As Integer = 1
        Do Until SceneData(SceneIndex).SceneName = Split(cmbChannelPresetSelection.SelectedItem, "| ")(1) : SceneIndex += 1 : Loop
        Dim FaderNo As Integer = Val(Sender.tag) - numChannelFadersStart.Value + 1
        Dim SceneChannelNo As Integer = Val(Sender.tag)
        ' UpdateFixtureLabel(FaderNo)
        If Not ChannelFaders(FaderNo).cTxtVal.Text = Sender.value Then
            ChannelFaders(FaderNo).cTxtVal.Text = Sender.value
            SceneData(SceneIndex).ChannelValues(SceneChannelNo).Value = Sender.value
        End If

    End Sub
    Private Sub cTxtVal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If otherChanged = True Then Exit Sub
        If FadersRenaming = True Then Exit Sub
        Dim SceneIndex As Integer = 1
        Do Until SceneData(SceneIndex).SceneName = Split(cmbChannelPresetSelection.SelectedItem, "| ")(1) : SceneIndex += 1 : Loop
        Dim FaderNo As Integer = Val(sender.tag) - numChannelFadersStart.Value + 1
        Dim SceneChannelNo As Integer = Val(sender.tag)
        ' UpdateFixtureLabel(FaderNo)
        If Not ChannelFaders(FaderNo).cFader.Value = Val(sender.text) Then
            ChannelFaders(FaderNo).cFader.Value = Val(sender.text)
            SceneData(SceneIndex).ChannelValues(SceneChannelNo).Value = Val(sender.text)
        End If
    End Sub
    Private Sub UpdateFixtureLabel(Optional ByVal channelno As Integer = 0)
        If Not channelno = 0 Then
            'Actionsandvalues= "Str1,0-79,Str2,80-160,Str3,161-255"
            Dim a() As String = Split(FixtureControls(channelno - 1 + numChannelFadersStart.Value).ActionAndValues, ",")
            If a.Length > 2 Then
                Dim ActionIndex As Integer = 1
                Do Until ActionIndex >= a.Length
                    Dim b() As String = Split(a(ActionIndex), "-")
                    If Val(ChannelFaders(channelno).cTxtVal.Text) >= b(0) And Val(ChannelFaders(channelno).cTxtVal.Text) <= b(1) Then
                        'found value
                        Exit Do
                    End If
                    ActionIndex += 2
                Loop

                'Val(ChannelFaders(channelno).cTxtVal.Text) >= ActionLow And Val(ChannelFaders(channelno).cTxtVal.Text) >= ActionHigh
                ChannelFaders(channelno).cFixtureDescr.Text = a(ActionIndex - 1)
            End If
        Else

        End If
    End Sub
    Private Sub cSelected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim SceneIndex As Integer = 1
        Do Until SceneData(SceneIndex).SceneName = Split(cmbChannelPresetSelection.SelectedItem, "| ")(1) : SceneIndex += 1 : Loop
        Dim SceneChannelNo As Integer = Val(sender.tag)


        If sender.backcolor = Color.Red Then
            sender.backcolor = controlcolour
            SceneData(SceneIndex).ChannelValues(SceneChannelNo).Selected = False
            'GoTo ModsDown
        ElseIf sender.backcolor = controlcolour Then
            sender.backcolor = Color.Red
            SceneData(SceneIndex).ChannelValues(SceneChannelNo).Selected = True
        End If



        'ModsDown:
        If shiftdown = True Then
            Dim FaderControlNo As Integer = 1
            Do Until Val(ChannelFaders(FaderControlNo).cSelected.Tag) = LastSelectedChannel : FaderControlNo += 1 : Loop
            Dim I As Integer = LastSelectedChannel '                                  10         
            If SceneChannelNo > LastSelectedChannel Then '                            20 > 10    
                Do Until I > SceneChannelNo '                                         10 > 20    
                    ChannelFaders(FaderControlNo).cSelected.BackColor = Color.Red   ' Red 10     
                    SceneData(SceneIndex).ChannelValues(I).Selected = True   '        True 10    
                    FaderControlNo += 1
                    I += 1
                Loop
            End If
        End If

        'If ctrldown = True Then

        '    Dim I As Integer = LastSelectedChannel
        '    If SceneChannelNo > LastSelectedChannel Then
        '        Do Until I > SceneChannelNo
        '            ChannelFaders(I).cSelected.BackColor = Color.Red
        '            I += 1
        '        Loop
        '    End If
        'End If

        'Dim d() As String = Split(sender.tag, "|")

        LastSelectedChannel = SceneChannelNo
    End Sub
    Private Sub cFixtureDescr_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not ctrldown = True Then cmdUnselectAll_Click(sender, Nothing)

        Dim fixname As String = FixtureControls(Val(sender.tag)).FixtureName
        Dim fixchan As Integer = FixtureControls(Val(sender.tag)).ChannelOfFixture
        Dim fixIndex As Integer = Val(sender.tag)

        'Dim FaderControlNo As Integer = 1
        'Do Until ChannelFaders(FaderControlNo).cFixtureDescr.Name = sender.name : FaderControlNo += 1 : Loop

        Dim I As Integer = 1

        Do Until I >= FixtureControls.Length - 1
            If FixtureControls(I).FixtureName = fixname Then
                If FixtureControls(I).ChannelOfFixture = fixchan Then
                    'FixtureControls(I).sButton.BackColor = Color.Red
                    SceneData(GetSceneIndex(Split(cmbChannelPresetSelection.Text, "| ")(1))).ChannelValues(I).Selected = True
                    ChannelFaders(I + (numChannelFadersStart.Value - 1)).cSelected.BackColor = Color.Red
                End If
            End If
            I += 1
        Loop
        LastSelectedChannel = fixIndex
    End Sub
    Private Sub tmrTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If formopened = False Then Exit Sub
        Dim SceneIndex As Integer = Split(sender.tag, "|")(0)
        Dim ChannelIndex As Integer = Split(sender.tag, "|")(1)

        With SceneData(SceneIndex).ChannelValues(ChannelIndex)

            ' List In Order
            If .Automation.ProgressInOrder = True Then
                If .Automation.CurrentIofList >= .Automation.ProgressList.Count - 1 Then
                    .Automation.CurrentIofList = 0
                    If .Automation.ProgressLoop = False Then
                        .Automation.tTimer.Stop()
                    End If
                Else
                    .Automation.CurrentIofList += 1
                    .Value = .Automation.ProgressList(.Automation.CurrentIofList)
                End If
            End If

            ' List Timed Random
            If .Automation.ProgressRandomTimed = True Then
                .Automation.CurrentIofList = GetRandom(0, .Automation.ProgressList.Count)
                .Value = .Automation.ProgressList(.Automation.CurrentIofList)
            End If

            ' List Sound Random
            If .Automation.ProgressSoundActivated = True Then
                .Automation.CurrentIofList = GetRandom(0, .Automation.ProgressList.Count)
                .Value = .Automation.ProgressList(.Automation.CurrentIofList)
            End If


            ' After .Value is changed update controls
            If cmbChannelPresetSelection.SelectedIndex = SceneIndex - 1 Then ' And tbcControls1.SelectedTab Is tbpChannels Then
                UpdateFixtureLabel(ChannelIndex)

                Dim I As Integer = 1
                Do Until I >= ChannelFaders.Count
                    If Not ChannelFaders(I).cFader Is Nothing Then
                        If ChannelFaders(I).cFader.Tag = ChannelIndex Then
                            ChannelFaders(I).cFader.Value = .Value
                            Exit Do
                        End If
                        If ChannelIndex < Val(ChannelFaders(I).cFader.Tag) Then Exit Do
                    End If

                    I += 1
                Loop

            End If



            'If .Automation.tmrDirection = "Down" Then
            '    If (.Value - .Automation.IntervalSteps) <= .Automation.Min Then
            '        .Value = .Automation.Min
            '        .Automation.tmrDirection = "Up"
            '        'ElseIf (.Value - .Automation.IntervalSteps) = .Automation.Min Then
            '        '    .Automation.tmrDirection = "Up"
            '        '    .Value += .Automation.IntervalSteps
            '    Else
            '        .Value -= .Automation.IntervalSteps
            '    End If
            'ElseIf .Automation.tmrDirection = "Up" Then
            '    If (.Value + .Automation.IntervalSteps) >= .Automation.Max Then
            '        .Value = .Automation.Max
            '        .Automation.tmrDirection = "Down"
            '        'ElseIf (.Value + .Automation.IntervalSteps) = .Automation.Max Then
            '        '    .Automation.tmrDirection = "Down"
            '        '    .Value -= .Automation.IntervalSteps
            '    Else
            '        .Value += .Automation.IntervalSteps
            '    End If
            'Else ' Doesn't have a direction
            '    Dim I As Integer = GetRandom(1, 2)
            '    If I = 1 Then
            '        .Automation.tmrDirection = "Down"
            '    Else
            '        .Automation.tmrDirection = "Up"
            '    End If
            'End If


            'If I > PresetFaderControlModifier And I <= (PresetFaderControlModifier + PresetFadersTotal) Then
            '    PresetFaders(I - PresetFaderControlModifier).cTxtVal.Text = SceneData(I).MasterValue
            'End If

        End With


    End Sub
#End Region

#Region "Scene Fader Controls"
    Private Sub cPresetFader_Scroll(ByVal Sender As System.Object) ' Handles GScrollBar1.ValueChanged 'ByVal sender As System.Object, ByVal e As System.EventArgs)
        'If PagingChanged = True Then Exit Sub
        'Dim chno As Integer = 1
        'Do Until PresetFaders(chno).cFader.Name = Sender.Name : chno += 1 : Loop

        'If Not PresetFaders(chno).cTxtVal.Text = Sender.value Then
        '    PresetFaders(chno).cTxtVal.Text = Sender.value
        '    SceneData(Val(Sender.tag)).MasterValue = Sender.value
        '    '  ListBox2.Items.Add(chno)
        'End If

    End Sub
    Private Sub cAutoTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) ' Handles TextBox1.TextChanged
        If formopened = False Then Exit Sub
        Dim chno As Integer = 1
        Do Until PresetFaders(chno).cAutoTime.Name = sender.Name : chno += 1 : Loop

        'If Not PresetFaders(chno).cFader.Value = Val(sender.text) Then
        SceneData(Val(sender.tag)).Automation.TimeBetweenMinAndMax = Val(sender.value)
        SavePreset(SceneData(Val(sender.tag)).SceneName)
        'End If
    End Sub
    Private Sub cPresetTxtVal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) ' Handles TextBox1.TextChanged
        'If otherChanged = True Then otherChanged = False : Exit Sub
        Dim chno As Integer = 1
        Do Until PresetFaders(chno).cTxtVal.Name = sender.Name : chno += 1 : Loop
        If Val(sender.text) > 100 Then sender.text = 100

        'If Not PresetFaders(chno).cFader.Value = Val(sender.text) Then
        'PresetFaders(chno).cFader.Value = Val(sender.text)
        SceneData(Val(sender.tag)).MasterValue = Val(sender.text)
        'End If
    End Sub
    Public Sub cPresetFull_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If formopened = False Then Exit Sub
        Dim I As Integer = Val(sender.tag)
        'SceneData(I).cmdTouchbutton.BackColor = Color.Red
        'SceneData(I).Automation.numChangeMS = PresetFaders(I - PresetModifier).cAutoTime.Value

        If SceneData(I).Automation.TimeBetweenMinAndMax = 0 Then 'numPresetChangeMS.Value = 0 Then
            SceneData(I).MasterValue = 100
            UpdatePresetControls(100, I)
        Else
            With SceneData(I)
                .Automation.tmrDirection = "Up"
                '.Automation.tmrUpto = 
                .Automation.IntervalSteps = SceneData(I).Automation.Max / (.Automation.TimeBetweenMinAndMax / .Automation.tTimer.Interval)

                .Automation.tTimer.Start()
            End With
        End If
    End Sub

    Public Sub cPresetBlackout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If formopened = False Then Exit Sub
        Dim I As Integer = Val(sender.tag)
        'SceneData(I).cmdTouchbutton.BackColor = controlcolour
        SceneData(I).Automation.TimeBetweenMinAndMax = PresetFaders(I).cAutoTime.Value
        If SceneData(I).Automation.TimeBetweenMinAndMax = 0 Then
            'PresetControls(I).vtxtBox.Text = "100"
            SceneData(I).MasterValue = 0
            UpdatePresetControls(0, I)
        Else
            With SceneData(I)
                .Automation.tmrDirection = "Down"
                '.Automation.tmrUpto = .vtxtBox.Text
                .Automation.IntervalSteps = SceneData(I).Automation.Max / (.Automation.TimeBetweenMinAndMax / .Automation.tTimer.Interval)
                .Automation.tTimer.Start()
            End With
        End If
    End Sub
    Private Sub tmrPreset_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If formopened = False Then Exit Sub
        Dim I As Integer = Val(sender.tag)
        If SceneData(I).Automation.tmrDirection = "Down" Then
            If (SceneData(I).MasterValue - SceneData(I).Automation.IntervalSteps) <= 0 Then
                SceneData(I).Automation.tTimer.Stop()
                SceneData(I).Automation.tmrDirection = "lol"
                SceneData(I).MasterValue = 0
                'PresetFaders(getpres
            Else
                SceneData(I).MasterValue -= SceneData(I).Automation.IntervalSteps
            End If
        ElseIf SceneData(I).Automation.tmrDirection = "Up" Then
            If (SceneData(I).MasterValue + SceneData(I).Automation.IntervalSteps) >= 100 Then
                SceneData(I).Automation.tTimer.Stop()
                SceneData(I).Automation.tmrDirection = "lol"
                SceneData(I).MasterValue = 100
            Else
                SceneData(I).MasterValue += SceneData(I).Automation.IntervalSteps
            End If
        End If
        UpdatePresetControls(SceneData(I).MasterValue, I)
        'PresetFaders(I).cFader.Value = SceneData(I).MasterValue
        If I > PresetFaderControlModifier And I <= (PresetFaderControlModifier + PresetFadersTotal) Then
            PresetFaders(I - PresetFaderControlModifier).cTxtVal.Text = SceneData(I).MasterValue
        End If

    End Sub
    Private Sub cmdPresetP1_Click(sender As Object, e As EventArgs) Handles cmdPresetP1.Click, cmdPresetP2.Click, cmdPresetP3.Click, cmdPresetP4.Click, cmdPresetP5.Click, cmdPresetP6.Click
        cmdPresetP1.BackColor = controlcolour
        cmdPresetP2.BackColor = controlcolour
        cmdPresetP3.BackColor = controlcolour
        cmdPresetP4.BackColor = controlcolour
        cmdPresetP5.BackColor = controlcolour
        cmdPresetP6.BackColor = controlcolour

        cmdPresetP1.ForeColor = Color.Black
        cmdPresetP2.ForeColor = Color.Black
        cmdPresetP3.ForeColor = Color.Black
        cmdPresetP4.ForeColor = Color.Black
        cmdPresetP5.ForeColor = Color.Black
        cmdPresetP6.ForeColor = Color.Black

        sender.backcolor = Color.Red
        sender.forecolor = Color.White
        RenamePresetFaderControls()
    End Sub
    Private Sub ckxPresetLabelEditChannels_Click(sender As Object, e As EventArgs) Handles ctxPresetLabelEditChannels.Click
        Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)

        cmbChannelPresetSelection.SelectedItem = cms.SourceControl.Text
        ChannelFaderPageCurrentSceneDataIndex = GetSceneIndex(Split(cmbChannelPresetSelection.Text, "| ")(1))
        tbcControls1.SelectedIndex = 2
    End Sub

    Private Sub ctxPresetLabelName_Click(sender As Object, e As EventArgs) Handles ctxPresetLabelName.Click
        Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)

        MessageBox.Show("Name: " & cms.SourceControl.Name & vbCrLf & "Tag: " & cms.SourceControl.Tag)
    End Sub
    Private Sub ctxPresetRenameScene_Click(sender As Object, e As EventArgs) Handles ctxPresetRenameScene.Click
        Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)
        Dim oldprefix As String = ""
        Dim oldname As String = ""
        Dim I As Integer = 1
        Do Until I >= PresetFaders.Count
            If PresetFaders(I).cPresetName.Text = cms.SourceControl.Text Then
                oldprefix = Split(cms.SourceControl.Text, " |")(0)
                oldname = Split(cms.SourceControl.Text, " |")(1)
                Exit Do
            End If
            I += 1
        Loop
        Dim newname As String = InputBox("Please Enter New Scene Name:", "Editing Scene #" & cms.SourceControl.Tag, SceneData(cms.SourceControl.Tag).SceneName)
        SceneData(cms.SourceControl.Tag).SceneName = newname
        PresetFaders(I).cPresetName.Text = oldprefix & " | " & newname
        cmbChannelPresetSelection.Items.Item(I - 1) = oldprefix & " | " & newname

    End Sub

    Private Sub cmbChannelPresetSelection_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbChannelPresetSelection.SelectedIndexChanged
        If formopened = False Then Exit Sub
        ChannelFaderPageCurrentSceneDataIndex = GetSceneIndex(Split(cmbChannelPresetSelection.Text, "| ")(1))
        RebuildTextOnChannelLabels()
    End Sub

    Private Sub cmdPresetsBlackoutAllTimer_Click(sender As Object, e As EventArgs) Handles cmdPresetsBlackoutAllTimer.Click, cmdDramaBlackoutAllTimer.Click
        If formopened = False Then Exit Sub
        Dim I As Integer = 1
        Do Until I >= SceneData.Length

            'SceneData(I).cmdTouchbutton.BackColor = controlcolour
            'SceneData(I).Automation.numChangeMS = PresetFaders(I).cAutoTime.Value

            If Not SceneData(I).MasterValue = 0 Then
                If SceneData(I).Automation.TimeBetweenMinAndMax = 0 Then
                    'PresetControls(I).vtxtBox.Text = "100"
                    SceneData(I).MasterValue = 0
                Else
                    With SceneData(I)
                        .Automation.tmrDirection = "Down"
                        '.Automation.tmrUpto = .vtxtBox.Text
                        .Automation.IntervalSteps = 100 / (.Automation.TimeBetweenMinAndMax / .Automation.tTimer.Interval)
                        .Automation.tTimer.Start()
                    End With
                End If
            End If
            I += 1
        Loop
        lstDramaPresets.ClearSelected()
    End Sub

    Private Sub cmdPresetsBlackoutAllInstant_Click(sender As Object, e As EventArgs) Handles cmdPresetsBlackoutAllInstant.Click, cmdDramaBlackoutAllInstant.Click
        If formopened = False Then Exit Sub
        Dim I As Integer = 1
        Do Until I >= SceneData.Length
            SceneData(I).MasterValue = 0
            SceneData(I).Automation.tmrDirection = "lol"
            If I < PresetFaders.Length Then
                If tbpPresets.Controls.Contains(PresetFaders(I).cTxtVal) Then
                    PresetFaders(I).cTxtVal.Text = 0
                End If
            End If
            I += 1
        Loop
        lstDramaPresets.ClearSelected()

    End Sub


#End Region

#Region "ThreadLoop Stuff"
    Private Sub threadloop()
        Do While closethreads = False

            For DMXChannelNumber = 1 To numEndChannel.Value ' Looping through channels


                If DMXChannelNumber = 1 Then
                    'Dim ts As String = ""

                End If
                Dim LargestNo As Integer = 0
                Dim I As Integer = 1
                Do Until I >= SceneData.Count ' Looping through Scenes
                    If BankChanged = True Then GoTo SkipLoops
                    If Not SceneData(I).ChannelValues Is Nothing Then
                        If (((SceneData(I).ChannelValues(DMXChannelNumber).Value / 100) * SceneData(I).MasterValue) / 100) * vsMaster.Value > LargestNo Then
                            LargestNo = (((SceneData(I).ChannelValues(DMXChannelNumber).Value / 100) * SceneData(I).MasterValue) / 100) * vsMaster.Value
                        End If
                    End If
                    I += 1
                Loop
                If Not SentChannelValues(DMXChannelNumber) = LargestNo Then

                    SetChannelData(DMXChannelNumber, LargestNo)
                    SentChannelValues(DMXChannelNumber) = LargestNo


                End If
            Next DMXChannelNumber
            GoTo LoopsDone
SkipLoops:

            Thread.Sleep(10)
LoopsDone:
            Thread.Sleep(1)
        Loop
    End Sub
    Private Sub MultipleThreadLoops(ByVal DMXno As Integer)
        Do While closethreads = False

            ' For DMXChannelNumber = 1 To numEndChannel.Value ' Looping through channels

            Dim LargestNo As Integer = 0
            Dim I As Integer = 1
            Do Until I >= SceneData.Count ' Looping through Scenes
                If BankChanged = True Then GoTo SkipLoops
                If Not SceneData(I).ChannelValues Is Nothing Then
                    If (((SceneData(I).ChannelValues(DMXno).Value / 100) * SceneData(I).MasterValue) / 100) * vsMaster.Value > LargestNo Then
                        LargestNo = (((SceneData(I).ChannelValues(DMXno).Value / 100) * SceneData(I).MasterValue) / 100) * vsMaster.Value
                    End If
                End If
                I += 1
            Loop
            If Not SentChannelValues(DMXno) = LargestNo Then

                SetChannelData(DMXno, LargestNo)
                SentChannelValues(DMXno) = LargestNo


            End If
            ' Next DMXChannelNumber
            GoTo LoopsDone
SkipLoops:

            Thread.Sleep(10)
LoopsDone:
            Thread.Sleep(5)
        Loop
    End Sub

    Private Sub CrashResistLoop()
        'Do
        '    FileOpen(100, Application.StartupPath & "\Crashresist\Dmrs.txt", OpenMode.Output)
        '    For I = 1 To SentChannelValues.Length - 1
        '        PrintLine(100, I & "=" & SentChannelValues(I))
        '    Next
        '    FileClose(100)
        '    Thread.Sleep(1000)
        'Loop
    End Sub
    Private Sub SetChannelData(ByVal Channel As Integer, ByVal Value As Integer)

        If Testmode = True Then Exit Sub
        EnttecOpenDMX.OpenDMX.setDmxValue(Channel, Value)
    End Sub
#End Region

#Region "Music Players"
    Private Sub chkEnableSongEdit_CheckedChanged(sender As Object, e As EventArgs) Handles chkEnableSongEdit.CheckedChanged
        If lstMusicSongs.SelectedIndex = -1 Then
            chkEnableSongEdit.Checked = False
            Exit Sub
        End If

        If chkEnableSongEdit.Checked = True Then
            vSongEdit.Visible = True
            lstSongEditPresets.Visible = True
            lblFadeIn.Visible = True
            lblFadeOut.Visible = True
            numFadeIn.Visible = True
            numFadeOut.Visible = True
            chkRecordspace.Visible = True

            lbleditposition.Visible = True
            lbleditPositionMilli.Visible = True
            cmdCreatelink.Visible = True
            cmdEditSongCopyNew.Visible = True
            cmdEditSongSave.Visible = True

            Label20.Visible = True
            lbleditRemaining.Visible = True
            cmdEditPlay.Visible = True
            cmdEditStop.Visible = True


            'lstMusicSongChanges.Location = New Point(461, 482)

            'lstMusicSongChanges.Size = New Point(lstSongEditPresets.Size)
            'lstMusicSongChanges.Anchor = 3

            'lstSongEditPresets.Items.Clear()
            Dim I As Integer = 1
            'Do Until I >= PresetControls.Length
            '    If PresetControls(I).PresetName = "" Then
            '        Exit Do
            '    Else
            '        lstPrsets.Items.Add(PresetControls(I).PresetName)
            '    End If
            '    I += 1
            'Loop
        Else
            vSongEdit.Visible = False
            lstSongEditPresets.Visible = False
            lblFadeIn.Visible = False
            lblFadeOut.Visible = False
            numFadeIn.Visible = False
            numFadeOut.Visible = False

            lbleditposition.Visible = False
            lbleditPositionMilli.Visible = False
            cmdCreatelink.Visible = False
            cmdEditSongCopyNew.Visible = False
            cmdEditSongSave.Visible = False
            chkRecordspace.Visible = False

            Label20.Visible = False
            lbleditRemaining.Visible = False
            cmdEditPlay.Visible = False
            cmdEditStop.Visible = False
            ' lstMusicSongChanges.Location = New Point(414, 47)
            'lstMusicSongChanges.Size = New Point(231, 160)
            'lstMusicSongChanges.Anchor = AnchorStyles.Top
        End If


        'Dim wavdata As ReadWav1 = ReadWav("C:\Tempfiles\03 - Save A Horse (Ride A Cowboy).wav")


        'Dim ms As System.IO.FileStream = System.IO.File.OpenRead("C:\Users\Markus\Dropbox\ESC VB.NET\Super Awesome Lighting DMX board v4\bin\Debug\Save Files\Bank1\03 - Save A Horse (Ride A Cowboy).mp3")

        'Dim rdr As Mp3FileReader = New Mp3FileReader(ms)
        ''Dim wavStream As Mp3FileReader = WaveFormatConversionStream.CreatePcmStream(rdr)
        ''Dim baStream As BlockAlignReductionStream = New BlockAlignReductionStream(wavStream)
        ''Dim wave As WaveChannel32 = New WaveChannel32(baStream)


        ''Dim retMs = New MemoryStream()
        ''Dim rs = New RawSourceWaveStream(rdr, New WaveFormat(16000, 2))
        'Dim rs = New RawSourceWaveStream(rdr, New WaveFormat(44100, 16, 2))
        'Dim pcmStream As WaveStream = WaveFormatConversionStream.CreatePcmStream(rs)

        'Dim wave As WaveChannel32 = New WaveChannel32(pcmStream)

        'CustomWaves1.BackColor = Color.White
        'CustomWaves1.WaveStream = New NAudio.Wave.WaveFileReader("C:\Tempfiles\03 - Save A Horse (Ride A Cowboy).wav")
        ''CustomWaves1.WaveStream = pcmStream
        'CustomWaves1.Visible = True
        'CustomWaves1.FitToScreen()
        ''WaveViewer1.BackColor = Color.White
        ''WaveViewer1.WaveStream = pcmStream
        ''WaveViewer1.Visible = True

    End Sub

    Dim waveOut As WaveOut = New WaveOut(WaveCallbackInfo.FunctionCallback())

    Structure ReadWav1
        Dim audio
        Dim sampleRate
    End Structure
    Function ReadWav(ByVal filename As String)

        Using afr = New NAudio.Wave.AudioFileReader(filename)
            Dim sampleRate As Integer = afr.WaveFormat.SampleRate
            Dim sampleCount As Integer = Val(afr.Length / afr.WaveFormat.BitsPerSample / 8)
            Dim channelCount As Integer = afr.WaveFormat.Channels
            Dim audio = New List(Of Double)(sampleCount)
            Dim buffer = New Single(sampleRate * channelCount - 1) {}
            Dim samplesRead As Integer = 0
            'while ((samplesRead = afr.Read(buffer, 0, buffer.Length)) > 0)
            While (afr.Read(buffer, 0, buffer.Length)) > 0
                samplesRead = afr.Read(buffer, 0, buffer.Length)
                'audio.AddRange(buffer.Take(samplesRead).Select(x => (double)x));
                'audio.AddRange(buffer.Take(samplesRead).Select(Function(x) New With {Key x}))

                'mcArr.Select(Function(m) Double.Parse(m.ToString())).ToArray()
                audio.AddRange(buffer.Take(samplesRead).Select(Function(x) Double.Parse(x)))


                'mcArr.Select(Function(m) Double.Parse(m.ToString())).ToArray()
                'Dim numarr() As Double = Array.ConvertAll(Of Single, Double)(buffer.Take(samplesRead), Function(s) CDbl(s))
                'audio.AddRange(numarr)
                'audio.AddRange(Array.ConvertAll(buffer.Take(samplesRead), Function(X) Double.Parse(X)))


                'audio.AddRange(buffer.Take(samplesRead).Select(Of x >= (Double)x))
            End While

            Dim return1 As ReadWav1
            return1.audio = audio.ToArray()
            return1.sampleRate = sampleRate
            Return return1
        End Using
    End Function
    Private Sub tmrMP3_Tick(sender As Object, e As EventArgs) Handles tmrMP3.Tick
        updatePlayer()
    End Sub

    Private Sub tmrMP32_Tick(sender As Object, e As EventArgs) Handles tmrMP32.Tick
        updatePlayer2()
    End Sub
    Private Sub updatePlayer()
        tmrchangedmp3 = True

        ' Update TrackPostion
        With vSongEdit
            .Minimum = 0
            .Maximum = CInt(Player.currentMedia.duration)
            .Value = CInt(Player.controls.currentPosition())
        End With
        ' Display Current Time Position and Duration
        'lblMP3PositionMilli.Text = Player.controls.currentPosition ## is lower down
        lblPresetsMP3Duration.Text = Player.currentMedia.durationString
        lblMusicMP3Duration.Text = lblPresetsMP3Duration.Text
        lblDramaViewMP3Duration.Text = lblPresetsMP3Duration.Text

        lblPresetsMP3Position.Text = Player.controls.currentPositionString
        lblMusicMP3Position.Text = lblPresetsMP3Position.Text
        lblDramaViewMP3Position.Text = lblPresetsMP3Position.Text

        trkPresetsVolume.Value = Player.settings.volume
        trkMusicVolume.Value = trkPresetsVolume.Value
        trkDramaViewVolume.Value = trkPresetsVolume.Value

        Dim PositionMilli As Double = Math.Round(Player.controls.currentPosition, 2)
        lblPresetsMP3PositionMilli.Text = PositionMilli
        lblMusicMP3PositionMilli.Text = PositionMilli
        lblDramaViewMP3PositionMilli.Text = PositionMilli
        lbleditPositionMilli.Text = PositionMilli

        vSongEdit.Value = Val(lblPresetsMP3PositionMilli.Text)

        'If Val(Player.currentMedia.durationString) <= 0 Then Exit Sub

        If SongChanges1.Count > 0 Then
            If SongChangeIndexUpTo1 > -2 Then
                If SongChanges1(SongChangeIndexUpTo1 + 1).TimeCode <= Player.controls.currentPosition Then '    If NextMP3Change <= Player.controls.currentPosition And NextMP3Change > -1 Then 'MS
                    'do change
                    SongChangeIndexUpTo1 += 1
                    lstPresetsSongChanges.SelectedIndex = SongChangeIndexUpTo1
                    lstMusicSongChanges.SelectedIndex = SongChangeIndexUpTo1
                    lstDramaViewSongChanges.SelectedIndex = SongChangeIndexUpTo1

                    'Dim d() As String = Split(lstPresetsSongChanges.SelectedItem, "|")                          ' 0|Blue|0|0    TIMECONDE | SCENENAME | UP-TIME | DOWN-TIME

                    If SongChangeIndexUpTo1 = 0 Then ' FIRST CHANGE OF THE SONG
                        cmdPresetsBlackoutAllInstant_Click(Nothing, Nothing)

                        If SongChanges1(SongChangeIndexUpTo1).TimeToGoUp = 0 Then 'numPresetChangeMS.Value = 0 Then
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).MasterValue = 100
                            UpdatePresetControls(100, SongChanges1(SongChangeIndexUpTo1).SceneIndex)
                        Else
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.tmrDirection = "Up"
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.IntervalSteps = SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.Max / (SongChanges1(SongChangeIndexUpTo1).TimeToGoUp / SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.tTimer.Interval)
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.tTimer.Start()
                        End If
                    Else  ' IN THE MIDDLE OF A SONG
                        'Dim e1() As String = Split(lstPresetsSongChanges.Items.Item(lstPresetsSongChanges.SelectedIndex - 1), "|")
                        ' Dim PreviousSceneIndex As Integer = GetSceneIndex(e1(1))

                        If SongChanges1(SongChangeIndexUpTo1 - 1).TimeToGoDown = 0 Then 'numPresetChangeMS.Value = 0 Then
                            SceneData(SongChanges1(SongChangeIndexUpTo1 - 1).SceneIndex).MasterValue = 0
                            UpdatePresetControls(0, SongChanges1(SongChangeIndexUpTo1 - 1).SceneIndex)
                        Else
                            SceneData(SongChanges1(SongChangeIndexUpTo1 - 1).SceneIndex).Automation.tmrDirection = "Down"
                            SceneData(SongChanges1(SongChangeIndexUpTo1 - 1).SceneIndex).Automation.IntervalSteps = SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.Max / (SongChanges1(SongChangeIndexUpTo1).TimeToGoDown / SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.tTimer.Interval)
                            SceneData(SongChanges1(SongChangeIndexUpTo1 - 1).SceneIndex).Automation.tTimer.Start()
                        End If  'cmdPresetBlackout_Click(PresetControls(PreviousSceneIndex).cmdBlackout, Nothing)


                        If SongChanges1(SongChangeIndexUpTo1).TimeToGoUp = 0 Then 'numPresetChangeMS.Value = 0 Then
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).MasterValue = 100
                            UpdatePresetControls(100, SongChanges1(SongChangeIndexUpTo1).SceneIndex)
                        Else
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.tmrDirection = "Up"
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.IntervalSteps = SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.Max / (SongChanges1(SongChangeIndexUpTo1).TimeToGoUp / SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.tTimer.Interval)
                            SceneData(SongChanges1(SongChangeIndexUpTo1).SceneIndex).Automation.tTimer.Start()
                        End If 'cmdPresetFull_Click(PresetControls(NextSceneIndex).cmdFull, Nothing)


                    End If


                    'prep next change
                    If SongChanges1.Count <= SongChangeIndexUpTo1 + 1 Then ' no more changes
                        SongChangeIndexUpTo1 = -2
                        'Else
                        'Dim c1() As String = Split(lstPresetsSongChanges.Items.Item(lstPresetsSongChanges.SelectedIndex + 1), "|")
                        'NextMP3Change = c1(0)
                    End If
                End If

            End If

        End If

        'tmrMP3.Interval = 10
        tmrchangedmp3 = False

    End Sub

    Private Sub updatePlayer2()
        tmrchangedmp32 = True

        ' Update TrackPostion
        'With vSongEdit
        '    .Minimum = 0
        '    .Maximum = CInt(Player.currentMedia.duration)
        '    .Value = CInt(Player.controls.currentPosition())
        'End With
        ' Display Current Time Position and Duration
        'lblMP3PositionMilli.Text = Player.controls.currentPosition ## is lower down
        lblPresetsMP3Duration2.Text = Player2.currentMedia.durationString
        lblMusicMP3Duration2.Text = lblPresetsMP3Duration2.Text
        lblDramaViewMP3Duration2.Text = lblPresetsMP3Duration2.Text

        lblPresetsMP3Position2.Text = Player2.controls.currentPositionString
        lblMusicMP3Position2.Text = lblPresetsMP3Position2.Text
        lblDramaViewMP3Position2.Text = lblPresetsMP3Position2.Text

        trkPresetsVolume2.Value = Player2.settings.volume
        trkMusicVolume2.Value = trkPresetsVolume2.Value
        trkDramaViewVolume2.Value = trkPresetsVolume2.Value

        Dim PositionMilli As Double = Math.Round(Player2.controls.currentPosition, 2)
        lblPresetsMP3PositionMilli2.Text = PositionMilli
        lblMusicMP3PositionMilli2.Text = PositionMilli
        lblDramaViewMP3PositionMilli2.Text = PositionMilli
        ' lbleditPositionMilli.Text = PositionMilli

        'vSongEdit.Value = Val(lblPresetsMP3PositionMilli2.Text)

        'If Val(Player.currentMedia.durationString) <= 0 Then Exit Sub

        If SongChanges2.Count > 0 Then
            If SongChangeIndexUpTo2 > -2 Then
                If SongChanges2(SongChangeIndexUpTo2 + 1).TimeCode <= Player2.controls.currentPosition Then '    If NextMP3Change <= Player.controls.currentPosition And NextMP3Change > -1 Then 'MS
                    'do change
                    SongChangeIndexUpTo2 += 1
                    lstPresetsSongChanges2.SelectedIndex = SongChangeIndexUpTo2
                    lstMusicSongChanges2.SelectedIndex = SongChangeIndexUpTo2
                    lstDramaViewSongChanges2.SelectedIndex = SongChangeIndexUpTo2

                    'Dim d() As String = Split(lstPresetsSongChanges.SelectedItem, "|")                          ' 0|Blue|0|0    TIMECONDE | SCENENAME | UP-TIME | DOWN-TIME

                    If SongChangeIndexUpTo2 = 0 Then ' FIRST CHANGE OF THE SONG
                        cmdPresetsBlackoutAllInstant_Click(Nothing, Nothing)

                        If SongChanges2(SongChangeIndexUpTo2).TimeToGoUp = 0 Then 'numPresetChangeMS.Value = 0 Then
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).MasterValue = 100
                            UpdatePresetControls(100, SongChanges2(SongChangeIndexUpTo2).SceneIndex)
                        Else
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.tmrDirection = "Up"
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.IntervalSteps = SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.Max / (SongChanges2(SongChangeIndexUpTo2).TimeToGoUp / SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.tTimer.Interval)
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.tTimer.Start()
                        End If
                    Else  ' IN THE MIDDLE OF A SONG
                        'Dim e1() As String = Split(lstPresetsSongChanges.Items.Item(lstPresetsSongChanges.SelectedIndex - 1), "|")
                        ' Dim PreviousSceneIndex As Integer = GetSceneIndex(e1(1))

                        If SongChanges2(SongChangeIndexUpTo2 - 1).TimeToGoDown = 0 Then 'numPresetChangeMS.Value = 0 Then
                            SceneData(SongChanges2(SongChangeIndexUpTo2 - 1).SceneIndex).MasterValue = 0
                            UpdatePresetControls(0, SongChanges2(SongChangeIndexUpTo2 - 1).SceneIndex)
                        Else
                            SceneData(SongChanges2(SongChangeIndexUpTo2 - 1).SceneIndex).Automation.tmrDirection = "Down"
                            SceneData(SongChanges2(SongChangeIndexUpTo2 - 1).SceneIndex).Automation.IntervalSteps = SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.Max / (SongChanges2(SongChangeIndexUpTo2).TimeToGoDown / SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.tTimer.Interval)
                            SceneData(SongChanges2(SongChangeIndexUpTo2 - 1).SceneIndex).Automation.tTimer.Start()
                        End If  'cmdPresetBlackout_Click(PresetControls(PreviousSceneIndex).cmdBlackout, Nothing)


                        If SongChanges2(SongChangeIndexUpTo2).TimeToGoUp = 0 Then 'numPresetChangeMS.Value = 0 Then
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).MasterValue = 100
                            UpdatePresetControls(100, SongChanges2(SongChangeIndexUpTo2).SceneIndex)
                        Else
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.tmrDirection = "Up"
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.IntervalSteps = SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.Max / (SongChanges2(SongChangeIndexUpTo2).TimeToGoUp / SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.tTimer.Interval)
                            SceneData(SongChanges2(SongChangeIndexUpTo2).SceneIndex).Automation.tTimer.Start()
                        End If 'cmdPresetFull_Click(PresetControls(NextSceneIndex).cmdFull, Nothing)


                    End If


                    'prep next change
                    If SongChanges2.Count <= SongChangeIndexUpTo2 + 1 Then ' no more changes
                        SongChangeIndexUpTo2 = -2
                        'Else
                        'Dim c1() As String = Split(lstPresetsSongChanges.Items.Item(lstPresetsSongChanges.SelectedIndex + 1), "|")
                        'NextMP3Change = c1(0)
                    End If
                End If

            End If

        End If

        'tmrMP3.Interval = 10
        tmrchangedmp32 = False

    End Sub

    Public Sub UpdatePresetControls(ByVal Value As Integer, ByVal SceneIndex As Integer)
        Dim I As Integer = 1
        Do Until I >= SceneData.Length
            If SceneData(SceneIndex).SceneName = "" Then
                I = SceneIndex
            End If
            If I < PresetFaders.Length Then
                If Not PresetFaders(I).cPresetName Is Nothing Then
                    If Split(PresetFaders(I).cPresetName.Text, "| ")(1) = SceneData(SceneIndex).SceneName Then

                        If tbpPresets.Controls.Contains(PresetFaders(I).cTxtVal) Then
                            PresetFaders(I).cTxtVal.Text = Value
                            If Value = 0 Then
                                PresetFaders(I).cBlackout.BackColor = lblSceneBlackoutColour.BackColor
                                PresetFaders(I).cFull.BackColor = Color.Black
                            ElseIf Value = 100 Then
                                PresetFaders(I).cBlackout.BackColor = Color.Black
                                PresetFaders(I).cFull.BackColor = lblSceneUpColour.BackColor
                            Else

                                If SceneData(SceneIndex).Automation.tTimer.Enabled = True And SceneData(SceneIndex).Automation.tmrDirection = "Up" Then
                                    PresetFaders(I).cBlackout.BackColor = Color.Black
                                    PresetFaders(I).cFull.BackColor = ControlPaint.Light(lblSceneUpColour.BackColor)
                                ElseIf SceneData(SceneIndex).Automation.tTimer.Enabled = True And SceneData(SceneIndex).Automation.tmrDirection = "Down" Then
                                    PresetFaders(I).cBlackout.BackColor = ControlPaint.LightLight(lblSceneBlackoutColour.BackColor)
                                    PresetFaders(I).cFull.BackColor = lblSceneUpColour.BackColor

                                End If

                            End If
                            Exit Do
                        End If
                    End If
                Else
                    Exit Do
                End If
            End If
            I += 1
        Loop
    End Sub

    Private Sub cmdPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPresetsPlay.Click, cmdEditPlay.Click, cmdDramaViewPlay.Click, cmdMusicPlay.Click
        'Dim iSelectIndex As String = sender.name
        If lstPresetsSongs.SelectedIndex = -1 Then Exit Sub
        'lstPresetsSongs.SelectedIndex = iSelectIndex
        'lstMusicSongs.SelectedIndex = iSelectIndex
        'lstDramaViewSongs.SelectedIndex = iSelectIndex


        If cmdPresetsPlay.Text = "Play" Then
            Player.settings.volume = trkPresetsVolume.Value


            Player.controls.play()

            If lstPresetsSongChanges.Items.Count > 0 Then
                Dim a() As String = Split(lstPresetsSongChanges.Items.Item(0), "|")
                SongChangeIndexUpTo1 = -1
                lstPresetsSongChanges.SelectedIndex = -1
                lstMusicSongChanges.SelectedIndex = -1
                lstDramaViewSongChanges.SelectedIndex = -1
            End If

            cmdPresetsPlay.Text = "Pause"
            cmdMusicPlay.Text = "Pause"
            cmdEditPlay.Text = "Pause"
            cmdDramaViewPlay.Text = "Pause"
            tmrMP3.Interval = 50
            tmrMP3.Start()
            tmrMP3_Tick(sender, e)
            lstPresetsSongs.Enabled = False
            lstMusicSongs.Enabled = False
            lstDramaViewSongs.Enabled = False
            Exit Sub
        ElseIf cmdPresetsPlay.Text = "Pause" Then
            'MP3.MP3Pause()
            Player.controls.pause()
            cmdPresetsPlay.Text = "Resume"
            cmdMusicPlay.Text = "Resume"
            cmdEditPlay.Text = "Resume"
            cmdDramaViewPlay.Text = "Resume"
            tmrMP3.Enabled = False
            Exit Sub
        ElseIf cmdPresetsPlay.Text = "Resume" Then
            Player.controls.play()
            cmdPresetsPlay.Text = "Pause"
            cmdMusicPlay.Text = "Pause"
            cmdEditPlay.Text = "Pause"
            cmdDramaViewPlay.Text = "Pause"
            'MP3.MP3Resume()
            tmrMP3.Start()
            Exit Sub
        End If
    End Sub

    Private Sub cmdStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPresetsStop.Click, cmdEditStop.Click, cmdDramaViewStop.Click, cmdMusicStop.Click
        Player.controls.stop()
        tmrMP3.Stop()
        cmdPresetsPlay.Text = "Play"
        cmdEditPlay.Text = "Play"
        cmdDramaViewPlay.Text = "Play"
        cmdMusicPlay.Text = "Play"
        lstPresetsSongs.Enabled = True
        lstMusicSongs.Enabled = True
        lstDramaViewSongs.Enabled = True
    End Sub

    Private Sub cmdSkip_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPresetsSkip.Click, cmdDramaViewSkip.Click, cmdMusicSkip.Click
        If lstPresetsSongs.Items.Count >= (lstPresetsSongs.SelectedIndex + 1) Then
            Player.controls.stop()
            tmrMP3.Stop()
            cmdPresetsPlay.Text = "Play"
            cmdEditPlay.Text = "Play"
            cmdMusicPlay.Text = "Play"
            cmdDramaViewPlay.Text = "Play"
            lstPresetsSongs.Enabled = True

            If lstPresetsSongs.Items.Count > lstPresetsSongs.SelectedIndex + 1 Then
                lstPresetsSongs.SelectedIndex += 1
                cmdPlay_Click(sender, e)
            Else
                cmdStop_Click(sender, e)
            End If

        End If
    End Sub

    Private Sub trkVolume_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkPresetsVolume.Scroll, trkDramaViewVolume.Scroll, trkMusicVolume.Scroll
        Player.settings.volume = sender.Value
        trkPresetsVolume.Value = Player.settings.volume
        trkDramaViewVolume.Value = Player.settings.volume
        trkMusicVolume.Value = Player.settings.volume
    End Sub
    Private Sub cmdPlay2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPresetsPlay2.Click, cmdDramaViewPlay2.Click, cmdMusicPlay2.Click
        'Dim iSelectIndex As String = sender.name
        If lstPresetsSongs2.SelectedIndex = -1 Then Exit Sub
        'lstPresetsSongs.SelectedIndex = iSelectIndex
        'lstMusicSongs.SelectedIndex = iSelectIndex
        'lstDramaViewSongs.SelectedIndex = iSelectIndex


        If cmdPresetsPlay2.Text = "Play" Then
            Player2.settings.volume = trkPresetsVolume2.Value


            Player2.controls.play()

            If lstPresetsSongChanges2.Items.Count > 0 Then
                Dim a() As String = Split(lstPresetsSongChanges2.Items.Item(0), "|")
                SongChangeIndexUpTo2 = -1
                lstPresetsSongChanges2.SelectedIndex = -1
                lstMusicSongChanges2.SelectedIndex = -1
                lstDramaViewSongChanges2.SelectedIndex = -1
            End If

            cmdPresetsPlay2.Text = "Pause"
            cmdMusicPlay2.Text = "Pause"
            cmdDramaViewPlay2.Text = "Pause"
            tmrMP32.Interval = 50
            tmrMP32.Start()
            tmrMP32_Tick(sender, e)
            lstPresetsSongs2.Enabled = False
            lstMusicSongs2.Enabled = False
            lstDramaViewSongs2.Enabled = False
            Exit Sub
        ElseIf cmdPresetsPlay2.Text = "Pause" Then
            'MP3.MP3Pause()
            Player2.controls.pause()
            cmdPresetsPlay2.Text = "Resume"
            cmdMusicPlay2.Text = "Resume"
            cmdDramaViewPlay2.Text = "Resume"
            tmrMP32.Enabled = False
            Exit Sub
        ElseIf cmdPresetsPlay2.Text = "Resume" Then
            Player2.controls.play()
            cmdPresetsPlay2.Text = "Pause"
            cmdMusicPlay2.Text = "Pause"
            cmdDramaViewPlay2.Text = "Pause"
            'MP3.MP3Resume()
            tmrMP32.Start()
            Exit Sub
        End If
    End Sub

    Private Sub cmdStop2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPresetsStop2.Click, cmdDramaViewStop2.Click, cmdMusicStop2.Click
        Player2.controls.stop()
        tmrMP32.Stop()
        cmdPresetsPlay2.Text = "Play"
        cmdDramaViewPlay2.Text = "Play"
        cmdMusicPlay2.Text = "Play"
        lstPresetsSongs2.Enabled = True
        lstMusicSongs2.Enabled = True
        lstDramaViewSongs2.Enabled = True
    End Sub

    Private Sub cmdSkip2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPresetsSkip2.Click, cmdDramaViewSkip2.Click, cmdMusicSkip2.Click
        If lstPresetsSongs2.Items.Count >= (lstPresetsSongs2.SelectedIndex + 1) Then
            Player2.controls.stop()
            tmrMP32.Stop()
            cmdPresetsPlay2.Text = "Play"
            cmdMusicPlay2.Text = "Play"
            cmdDramaViewPlay2.Text = "Play"
            lstPresetsSongs2.Enabled = True

            If lstPresetsSongs2.Items.Count > lstPresetsSongs2.SelectedIndex + 1 Then
                lstPresetsSongs2.SelectedIndex += 1
                cmdPlay2_Click(sender, e)
            Else
                cmdStop2_Click(sender, e)
            End If

        End If
    End Sub

    Private Sub trkVolume2_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trkPresetsVolume2.Scroll, trkDramaViewVolume2.Scroll, trkMusicVolume2.Scroll
        Player2.settings.volume = sender.Value
        trkPresetsVolume2.Value = Player2.settings.volume
        trkDramaViewVolume2.Value = Player2.settings.volume
        trkMusicVolume2.Value = Player2.settings.volume
    End Sub

    Private Function GetSceneIndex(ByVal SceneName As String) As Integer
        Dim I As Integer = 1
        Do Until SceneData(I).SceneName = SceneName
            I += 1
            If I >= SceneData.Length Then
                I = -1
                Exit Do
            End If
        Loop
        Return I
    End Function

    Private Sub LoadMusicTracks()

        lstPresetsSongs.Items.Clear()
        lstPresetsSongs2.Items.Clear()
        lstMusicSongs.Items.Clear()
        lstMusicSongs2.Items.Clear()
        lstDramaViewSongs.Items.Clear()
        lstDramaViewSongs2.Items.Clear()



        'lstPresetsSongChanges.Items.Clear()
        'lstPresetsSongChanges2.Items.Clear()
        'lstMusicSongChanges.Items.Clear()
        'lstMusicSongChanges2.Items.Clear()
        'lstDramaViewSongChanges.Items.Clear()
        'lstDramaViewSongChanges.Items.Clear()

        Dim I As Integer = 0
        Dim MusicMP3InBank() As String = Directory.GetFiles(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\", "*.mp3")
        Do Until I >= MusicMP3InBank.Length
            Dim a() As String = Split(MusicMP3InBank(I), "\")
            Dim songname As String = Mid(a(a.Length - 1), 1, Len(a(a.Length - 1)) - 4)

            lstPresetsSongs.Items.Add(songname)
            lstPresetsSongs2.Items.Add(songname)
            lstMusicSongs.Items.Add(songname)
            lstMusicSongs2.Items.Add(songname)
            lstDramaViewSongs.Items.Add(songname)
            lstDramaViewSongs2.Items.Add(songname)

            MusicCues(I).SongFileName = songname
            ReDim MusicCues(I).SongChanges(200)
            I += 1
        Loop


    End Sub
    Private Sub lstSongs_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstPresetsSongs.SelectedIndexChanged, lstMusicSongs.SelectedIndexChanged, lstDramaViewSongs.SelectedIndexChanged
        If sender.SelectedIndex = -1 Then Exit Sub
        Dim iSelectIndex = sender.selectedindex
        lstPresetsSongs.SelectedIndex = iSelectIndex
        lstMusicSongs.SelectedIndex = iSelectIndex
        lstDramaViewSongs.SelectedIndex = iSelectIndex

        Dim I As Integer = 0
        lstPresetsSongChanges.Items.Clear()
        lstMusicSongChanges.Items.Clear()
        lstDramaViewSongChanges.Items.Clear()
        SongChanges1.Clear()

        If File.Exists(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstPresetsSongs.SelectedItem & ".chg") = False Then GoTo AfterChgFile

        FileOpen(1, Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstPresetsSongs.SelectedItem & ".chg", OpenMode.Input)

        Do Until EOF(1)
            Dim newline As String = LineInput(1)
            lstPresetsSongChanges.Items.Add(newline)
            lstMusicSongChanges.Items.Add(newline)
            lstDramaViewSongChanges.Items.Add(newline)

            Dim NewSongChange As New SongChangesStr
            Dim a() As String = Split(newline, "|")
            NewSongChange.TimeCode = a(0)
            NewSongChange.SceneName = a(1)
            NewSongChange.SceneIndex = GetSceneIndex(a(1))
            NewSongChange.TimeToGoUp = a(2)
            NewSongChange.TimeToGoDown = a(3)
            SongChanges1.Add(NewSongChange)

        Loop

        'Do Until EOF(1)
        '    Dim a() As String = Split(LineInput(1), "|") 'time|Preset
        '    Mp3Changes(I).Time = a(0)
        '    Mp3Changes(I).PresetName = a(1)
        '    I += 1
        'Loop
        FileClose(1)


AfterChgFile:

        'Make sure no mp3 is playing
        'MP3.MP3Stop()
        'Player.controls.stop()
        'load mp3 and play


        Player.URL = Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstPresetsSongs.SelectedItem & ".mp3"

        lblPresetsMP3Duration.Text = Player.currentMedia.durationString
        lblMusicMP3Duration.Text = Player.currentMedia.durationString
        lblDramaViewMP3Duration.Text = Player.currentMedia.durationString

    End Sub

    Private Sub lstSongs2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstPresetsSongs2.SelectedIndexChanged, lstMusicSongs2.SelectedIndexChanged, lstDramaViewSongs2.SelectedIndexChanged
        If sender.SelectedIndex = -1 Then Exit Sub
        Dim iSelectIndex = sender.selectedindex
        lstPresetsSongs2.SelectedIndex = iSelectIndex
        lstMusicSongs2.SelectedIndex = iSelectIndex
        lstDramaViewSongs2.SelectedIndex = iSelectIndex
        SongChanges2.Clear()

        Dim I As Integer = 0
        lstPresetsSongChanges2.Items.Clear()
        lstMusicSongChanges2.Items.Clear()
        lstDramaViewSongChanges2.Items.Clear()
        SongChanges2.Clear()

        If File.Exists(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstPresetsSongs2.SelectedItem & ".chg") = False Then GoTo AfterChgFile

        FileOpen(1, Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstPresetsSongs2.SelectedItem & ".chg", OpenMode.Input)
        Do Until EOF(1)
            Dim newline As String = LineInput(1)
            lstPresetsSongChanges2.Items.Add(newline)
            lstMusicSongChanges2.Items.Add(newline)
            lstDramaViewSongChanges2.Items.Add(newline)

            Dim NewSongChange As New SongChangesStr
            Dim a() As String = Split(newline, "|")
            NewSongChange.TimeCode = a(0)
            NewSongChange.SceneName = a(1)
            NewSongChange.SceneIndex = GetSceneIndex(a(1))
            NewSongChange.TimeToGoUp = a(2)
            NewSongChange.TimeToGoDown = a(3)
            SongChanges2.Add(NewSongChange)

        Loop

        'Do Until EOF(1)
        '    Dim a() As String = Split(LineInput(1), "|") 'time|Preset
        '    Mp3Changes(I).Time = a(0)
        '    Mp3Changes(I).PresetName = a(1)
        '    I += 1
        'Loop
        FileClose(1)


AfterChgFile:

        'Make sure no mp3 is playing
        'MP3.MP3Stop()
        'Player.controls.stop()
        'load mp3 and play


        Player2.URL = Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstPresetsSongs2.SelectedItem & ".mp3"

        lblPresetsMP3Duration2.Text = Player2.currentMedia.durationString
        lblMusicMP3Duration2.Text = Player2.currentMedia.durationString
        lblDramaViewMP3Duration2.Text = Player2.currentMedia.durationString
    End Sub
    Public Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
        Static Generator As System.Random = New System.Random()
        Return Generator.Next(Min, Max)
        'Return CInt(Math.Ceiling(Rnd() * Max))
    End Function

#End Region

#Region "Banks"
    Private Sub cmdBankNew_Click(sender As Object, e As EventArgs) Handles cmdBankNew.Click
        Dim s As String = InputBox("Name of new bank:")
        If s = "" Then Exit Sub
        Directory.CreateDirectory(Application.StartupPath & "\Save Files\" & s)
        LoadBanksFromFile()
    End Sub

    Private Sub cmdBankRename_Click(sender As Object, e As EventArgs) Handles cmdBankRename.Click
        If lstBanks.SelectedIndex = -1 Then Exit Sub
        Dim s As String = InputBox("Name of new bank:")
        If s = "" Then Exit Sub
        Directory.Move(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem, Application.StartupPath & "\Save Files\" & s)
        LoadBanksFromFile()
    End Sub

    Private Sub cmd4KSize_Click(sender As Object, e As EventArgs) Handles cmd4KSize.Click
        frmMain.Size = New Point(3840, 2160)
    End Sub

    Private Sub lstBanks_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstBanks.SelectedIndexChanged
        If formopened = False Then Exit Sub

        'Dim I As Integer = 1
        'Do Until I >= SceneData.Length
        '    Dim I1 As Integer = 1

        '    SceneData(I).SceneName = ""
        '    SceneData(I).MasterValue = 0
        '    SceneData(I).Automation.TimeBetweenMinAndMax = 1000
        '    SceneData(I).Automation.Max = 100
        '    SceneData(I).Automation.Min = 0

        '    'SceneData(I).ChannelValues = Nothing

        '    'Do Until I1 >= 512
        '    '    SceneData(I).ChannelValues = Nothing
        '    '    With SceneData(I).ChannelValues(I1)
        '    '        .Automation.tTimer = New Windows.Forms.Timer
        '    '        .Value = 0
        '    '        .Automation.tTimer.Interval = 10
        '    '        .Automation.tTimer.Enabled = False
        '    '        .Automation.Max = 255
        '    '        .Automation.Min = 0
        '    '        .Automation.TimeBetweenMinAndMax = 1000
        '    '        .Automation.randomstart = False
        '    '    End With
        '    '    I1 += 1
        '    'Loop
        '    I += 1
        'Loop
        BankChanged = True

        LoadScenesFromFile()
        LoadMusicTracks()

        cmdPresetP1.BackColor = Color.Red
        cmdPresetP2.BackColor = controlcolour
        cmdPresetP3.BackColor = controlcolour
        cmdPresetP4.BackColor = controlcolour
        cmdPresetP5.BackColor = controlcolour
        cmdPresetP6.BackColor = controlcolour

        cmdPresetP1.ForeColor = Color.White
        cmdPresetP2.ForeColor = Color.Black
        cmdPresetP3.ForeColor = Color.Black
        cmdPresetP4.ForeColor = Color.Black
        cmdPresetP5.ForeColor = Color.Black
        cmdPresetP6.ForeColor = Color.Black

        RenamePresetFaderControls()

        BankChanged = False

    End Sub






#End Region

    Private Sub FormMain_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        ' Form is closing, so shutdown player
        Player.close()
        Player2.close()
        If Testmode = False Then
            EnttecOpenDMX.OpenDMX.done = True
        End If

        'If tChannelsMultipleThreads = False Then
        '    tChannels(1).Abort()
        'Else
        '    Dim I As Integer = 0
        '    Do Until I >= 512
        '        tChannels(I).Abort()
        '        I += 1
        '    Loop
        'End If
        closethreads = True
        If Not tTouchPadLoad Is Nothing Then tTouchPadLoad.Abort()
        tCrashResist.Abort()
        File.Delete(Application.StartupPath & "\Crashresist\Dmrs.txt")
        Application.Exit()

    End Sub

    Private Sub cmdOpenTouchpad_Click(sender As Object, e As EventArgs) Handles cmdOpenTouchpad.Click
        frmTouchPad.Show()
    End Sub

    Private Sub ctxNameofbutton_Click(sender As Object, e As EventArgs) Handles ctxNameofbutton.Click
        Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)

        MessageBox.Show(cms.SourceControl.Name)
    End Sub

    Private Sub ctxDimmerAutomation_Click(sender As Object, e As EventArgs) Handles ctxDimmerAutomation.Click
        Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)
        'frmDimmerAutomation = New FormDimmerAutomation

        frmDimmerAutomation.Location = Windows.Forms.Cursor.Position
        frmDimmerAutomation.SceneIndex = ChannelFaderPageCurrentSceneDataIndex
        frmDimmerAutomation.isLoaded = False
        frmDimmerAutomation.Generate()
        frmDimmerAutomation.Show()
        frmDimmerAutomation.isLoaded = True
    End Sub


    Private Sub cmdChannelsSave_Click(sender As Object, e As EventArgs) Handles cmdChannelsSave.Click
        SavePreset(cmbChannelPresetSelection.SelectedItem)
    End Sub
    Sub SavePreset(ByVal filename As String)
        If PagingChanged = True Then Exit Sub
        If BankChanged = True Then Exit Sub

        Dim I1 As Integer = 1
        Dim SaveFileName As String = ""
        Do Until I1 >= SceneData.Length
            Dim a() As String = Split(filename, "| ")
            If a.Length > 1 Then
                If SceneData(I1).SceneName = a(1) Then
                    SaveFileName = a(1)
                    Exit Do
                End If
            ElseIf a.Length = 1 Then
                If SceneData(I1).SceneName = a(0) Then
                    SaveFileName = a(0)
                    Exit Do
                End If
            End If

            I1 += 1
        Loop
        If SceneData(I1).SceneName = "" Then Exit Sub

        FileOpen(1, Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & SaveFileName & ".dmr", OpenMode.Output)
        PrintLine(1, "P|" & "0")
        PrintLine(1, "ChangeMS|" & SceneData(I1).Automation.TimeBetweenMinAndMax)  '(PresetIndex(cmbPresets.SelectedItem)).Automation.numChangeMS.Value)
        Dim I As Integer = 1
        Do Until I > numEndChannel.Value '1|v,0|tmr,100|timerenabled,false
            Dim chanline As String = I & "|"
            With SceneData(I1).ChannelValues(I)
                chanline &= "v," & .Value & "|"
                'chanline &= "tmr," & .Automation.tTimer.Interval & "|"
                chanline &= "TimerEnabled," & .Automation.tTimer.Enabled & "|"
                chanline &= "AutoTimeBetween," & .Automation.tTimer.Interval & "|"
                chanline &= "RandomStart," & .Automation.ProgressRandomTimed & "|"

                chanline &= "InOrder," & .Automation.ProgressInOrder & "|"
                chanline &= "RandomSound," & .Automation.ProgressSoundActivated & "|"
                chanline &= "IsLooped," & .Automation.ProgressLoop & "|"
                chanline &= "ProgressList"

                Dim iList As Integer = 0
                If Not .Automation.ProgressList Is Nothing Then
                    Do Until iList >= .Automation.ProgressList.Count
                        chanline &= "," & .Automation.ProgressList(iList)
                        iList += 1
                    Loop
                End If
            End With
            PrintLine(1, chanline)
            I += 1
        Loop
        FileClose(1)

    End Sub

    Private Sub lstDramaPresets_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstDramaPresets.SelectedIndexChanged
        'PresetControls(PresetIndex(lstPrsets.SelectedItem)).vtxtBox.Text = 100
        If lstDramaPresets.SelectedIndex = -1 Then Exit Sub

        Dim I As Integer = 1
        Do Until I >= SceneData.Length
            If SceneData(I).MasterValue > 0 Then 'preset is above blackout
                If isDramaPresetSelected(I) = False Then
                    With SceneData(I)
                        .Automation.tmrDirection = "Down"
                        .Automation.IntervalSteps = 255 / (.Automation.TimeBetweenMinAndMax / .Automation.tTimer.Interval)
                        .Automation.tTimer.Start()
                    End With
                End If
            ElseIf SceneData(I).MasterValue = 0 Then 'preset is at blackout
                If isDramaPresetSelected(I) = True Then
                    With SceneData(I)
                        .Automation.tmrDirection = "Up"
                        .Automation.IntervalSteps = 255 / (.Automation.TimeBetweenMinAndMax / .Automation.tTimer.Interval)
                        .Automation.tTimer.Start()
                    End With
                End If
            End If

            I += 1
        Loop

    End Sub
    Function isDramaPresetSelected(ByVal PresetControlsIndex As Integer) As Boolean
        Dim I As Integer = 0
        Do Until I >= lstDramaPresets.SelectedItems.Count
            If lstDramaPresets.SelectedItems(I) = SceneData(PresetControlsIndex).SceneName Then
                Return True
                Exit Function
            End If
            I += 1
        Loop
        Return False
    End Function


#Region " Master Controls "
    Private Sub vsMaster_ValueChanged(sender As Object) Handles vsMaster.ValueChanged
        If PagingChanged = True Then Exit Sub
        If Not Val(txtMaster.Text) = sender.value Then
            txtMaster.Text = sender.value
        End If
    End Sub

    Private Sub txtMaster_TextChanged(sender As Object, e As EventArgs) Handles txtMaster.TextChanged
        If PagingChanged = True Then Exit Sub
        If Not vsMaster.Value = Val(sender.text) Then
            vsMaster.Value = Val(sender.text)
        End If
    End Sub

    Private Sub cmdMasterFull_Click(sender As Object, e As EventArgs) Handles cmdMasterFull.Click
        frmTouchPad.cmdMasterUp.BackColor = Color.Red
        If numChangeMS.Value = 0 Then
            txtMaster.Text = 100
            vsMaster.Value = Val(txtMaster.Text)
        Else
            tmrMasterWay = "Up"
            tmrMasterUpto = txtMaster.Text
            tmrMasterInterval = vsMaster.Maximum / (numChangeMS.Value / tmrMaster.Interval)
            tmrMaster.Start()
        End If
    End Sub

    Private Sub tmrMaster_Tick(sender As Object, e As EventArgs) Handles tmrMaster.Tick
        If tmrMasterWay = "Down" Then
            Label8.Visible = False
            If (vsMaster.Value - tmrMasterInterval) <= 0 Then
                tmrMaster.Stop()
                tmrMasterWay = "lol"
                Label8.Visible = True
            End If
            vsMaster.Value -= tmrMasterInterval

        ElseIf tmrMasterWay = "Up" Then
            Label8.Visible = False
            If (vsMaster.Value + tmrMasterInterval) >= 100 Then
                tmrMaster.Stop()
                tmrMasterWay = "lol"
                Label8.Visible = True
            End If
            vsMaster.Value += tmrMasterInterval

        End If
    End Sub

    Private Sub cmdMasterBlackout_Click(sender As Object, e As EventArgs) Handles cmdMasterBlackout.Click
        frmTouchPad.cmdMasterUp.BackColor = controlcolour
        If numChangeMS.Value = 0 Then
            txtMaster.Text = 0
            vsMaster.Value = Val(txtMaster.Text)
        Else
            tmrMasterWay = "Down"
            tmrMasterUpto = txtMaster.Text
            'tmrMasterInterval = (numChangeMS.Value / 100) '20 times
            tmrMasterInterval = vsMaster.Value / (numChangeMS.Value / tmrMaster.Interval)
            tmrMaster.Start()
        End If
    End Sub
#End Region

#Region " Colour Pickers "
    Private Sub cmdChannelBulletColour_Click(sender As Object, e As EventArgs) Handles cmdChannelBulletColour.Click
        Dim coldialog As New ColorDialog
        coldialog.Color = lblChannelBulletColour.BackColor
        coldialog.ShowDialog()
        lblChannelBulletColour.BackColor = coldialog.Color

        Dim I As Integer = 1
        Do Until I >= ChannelFaders.Length
            If Not ChannelFaders(I).cFader Is Nothing Then
                ChannelFaders(I).cFader.BulletColor = coldialog.Color
            Else
                Exit Do
            End If
            I += 1
        Loop
    End Sub

    Private Sub cmdChannelBackColour_Click(sender As Object, e As EventArgs) Handles cmdChannelBackColour.Click
        Dim coldialog As New ColorDialog
        coldialog.Color = lblChannelBackColour.BackColor
        coldialog.ShowDialog()
        lblChannelBackColour.BackColor = coldialog.Color

        Dim I As Integer = 1
        Do Until I >= ChannelFaders.Length
            If Not ChannelFaders(I).cFader Is Nothing Then
                ChannelFaders(I).cFader.BackColor = coldialog.Color
            Else
                Exit Do
            End If
            I += 1
        Loop
    End Sub

    Private Sub cmdChannelFillColour_Click(sender As Object, e As EventArgs) Handles cmdChannelFillColour.Click
        Dim coldialog As New ColorDialog
        coldialog.Color = lblChannelFillColour.BackColor
        coldialog.ShowDialog()
        lblChannelFillColour.BackColor = coldialog.Color

        Dim I As Integer = 1
        Do Until I >= ChannelFaders.Length
            If Not ChannelFaders(I).cFader Is Nothing Then
                ChannelFaders(I).cFader.FillColor = coldialog.Color
            Else
                Exit Do
            End If

            I += 1
        Loop
    End Sub
    Private Sub cmdChannelNumberColour_Click(sender As Object, e As EventArgs) Handles cmdChannelNumberColour.Click
        Dim coldialog As New ColorDialog
        coldialog.Color = lblChannelNumberColour.BackColor
        coldialog.ShowDialog()
        lblChannelNumberColour.BackColor = coldialog.Color

        Dim I As Integer = 1
        Do Until I >= ChannelFaders.Length
            If Not ChannelFaders(I).cChannelLabel Is Nothing Then
                ChannelFaders(I).cChannelLabel.ForeColor = coldialog.Color
            Else
                Exit Do
            End If

            I += 1
        Loop
    End Sub

    Private Sub cmdSceneBlackoutColour_Click(sender As Object, e As EventArgs) Handles cmdSceneBlackoutColour.Click
        Dim coldialog As New ColorDialog
        coldialog.Color = lblSceneBlackoutColour.BackColor
        coldialog.ShowDialog()
        lblSceneBlackoutColour.BackColor = coldialog.Color

        Dim I As Integer = 1
        Do Until I >= PresetFaders.Length
            If Not PresetFaders(I).cBlackout Is Nothing Then
                If Val(PresetFaders(I).cTxtVal.Text) = 0 Then
                    PresetFaders(I).cBlackout.BackColor = coldialog.Color
                End If
            Else
                Exit Do
            End If
            I += 1
        Loop
    End Sub

    Private Sub cmdSceneUpColour_Click(sender As Object, e As EventArgs) Handles cmdSceneUpColour.Click
        Dim coldialog As New ColorDialog
        coldialog.Color = lblSceneUpColour.BackColor
        coldialog.ShowDialog()
        lblSceneUpColour.BackColor = coldialog.Color

        Dim I As Integer = 1
        Do Until I >= PresetFaders.Length
            If Not PresetFaders(I).cFull Is Nothing Then
                If Val(PresetFaders(I).cTxtVal.Text) > 0 Then
                    PresetFaders(I).cFull.BackColor = coldialog.Color
                End If
            Else
                Exit Do
            End If
            I += 1
        Loop
    End Sub

    Private Sub cmdSceneFillColour_Click(sender As Object, e As EventArgs) Handles cmdSceneFillColour.Click
        'Dim coldialog As New ColorDialog
        'coldialog.Color = lblSceneFillColour.BackColor
        'coldialog.ShowDialog()
        'lblSceneFillColour.BackColor = coldialog.Color

        'Dim I As Integer = 1
        'Do Until I >= PresetFaders.Length
        '    If Not PresetFaders(I).cFader Is Nothing Then
        '        PresetFaders(I).cFader.FillColor = coldialog.Color
        '    Else
        '        Exit Do
        '    End If
        '    I += 1
        'Loop
    End Sub

    Private Sub cmdSceneLabelColour_Click(sender As Object, e As EventArgs) Handles cmdSceneLabelColour.Click
        Dim coldialog As New ColorDialog
        coldialog.Color = lblSceneLabelColour.BackColor
        coldialog.ShowDialog()
        lblSceneLabelColour.BackColor = coldialog.Color

        Dim I As Integer = 1
        Do Until I >= PresetFaders.Length
            If Not PresetFaders(I).cPresetName Is Nothing Then
                PresetFaders(I).cPresetName.ForeColor = coldialog.Color
            Else
                Exit Do
            End If
            I += 1
        Loop
    End Sub
#End Region

    Private Sub vsSelected_ValueChanged(sender As Object) Handles vsSelected.ValueChanged
        If otherChanged = True Then Exit Sub
        txtSelected.Text = vsSelected.Value
    End Sub

    Private Sub txtSelected_TextChanged(sender As Object, e As EventArgs) Handles txtSelected.TextChanged
        'If otherChanged = True Then otherChanged = False : Exit Sub
        If txtSelected.Text = "" Then Exit Sub
        If formopened = False Then Exit Sub
        If BankChanged = True Then Exit Sub

        If Val(txtSelected.Text) > 255 Then txtSelected.Text = 255
        If Val(txtSelected.Text) < 0 Then txtSelected.Text = 0
        otherChanged = True
        vsSelected.Value = Val(txtSelected.Text)


        'Application.DoEvents()
        ' Dim SceneIndexI As Integer = GetSceneIndex(Split(cmbChannelPresetSelection.Text, "| ")(1))

        Dim I As Integer = 0
        Do Until I >= SceneData(ChannelFaderPageCurrentSceneDataIndex).ChannelValues.Count
            If SceneData(ChannelFaderPageCurrentSceneDataIndex).ChannelValues(I).Selected = True Then
                ' otherChanged = True

                SceneData(ChannelFaderPageCurrentSceneDataIndex).ChannelValues(I).Value = Val(txtSelected.Text)
                ' otherChanged = False
            End If

            If Not ChannelFaders(I).cSelected Is Nothing Then
                If ChannelFaders(I).cSelected.BackColor = Color.Red Then
                    ' otherChanged = True
                    ChannelFaders(I).cFader.Value = Val(txtSelected.Text)
                    ChannelFaders(I).cTxtVal.Text = Val(txtSelected.Text)
                    UpdateFixtureLabel(I)
                    ' otherChanged = False
                End If
            End If


            I += 1
        Loop
        'I = 1
        'Do Until I >= ChannelFaders.Count
        '    If ChannelFaders(I).cSelected Is Nothing Then Exit Do
        '    If ChannelFaders(I).cSelected.BackColor = Color.Red Then
        '        ChannelFaders(I).cFader.Value = (255 / 100) * Val(txtSelected.Text)
        '    End If
        '    I += 1
        'Loop
        otherChanged = False

    End Sub

    Private Sub cmdSaveSettings_Click(sender As Object, e As EventArgs) Handles cmdSaveSettings.Click
        SaveSettingsToFile()
    End Sub

    Private Sub lstSongEditPresets_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstSongEditPresets.SelectedIndexChanged
        'PresetControls(PresetIndex(lstPrsets.SelectedItem)).vtxtBox.Text = 100
        If lstSongEditPresets.SelectedIndex = -1 Then Exit Sub

        cmdPresetsBlackoutAllInstant_Click(sender, e)
        ' PresetControls(PresetIndex(lstPrsets.SelectedItem)).vtxtBox.Text = 100

        Dim I As Integer = 1
        Do Until I >= SceneData.Length
            ' If SceneData(I).MasterValue = 0 Then 'preset is above blackout
            Dim J As Integer = 0
            Do Until J >= lstSongEditPresets.SelectedItems.Count
                If lstSongEditPresets.SelectedItems(J) = SceneData(I).SceneName Then

                    With SceneData(I)
                        .Automation.tmrDirection = "Up"
                        .Automation.IntervalSteps = 255 / (.Automation.TimeBetweenMinAndMax / .Automation.tTimer.Interval)
                        .Automation.tTimer.Start()
                    End With

                End If
                J += 1
            Loop
            '  End If

            I += 1
        Loop
    End Sub

    Private Sub vSongEdit_ValueChanged(sender As Object) Handles vSongEdit.ValueChanged
        If formopened = False Then Exit Sub
        If tmrchangedmp3 = True Then Exit Sub

        Player.controls.currentPosition = vSongEdit.Value

        updatePlayer()

    End Sub

    Private Sub cmdCreatelink_Click(sender As Object, e As EventArgs) Handles cmdCreatelink.Click
        If lstSongEditPresets.SelectedIndex = -1 Then Exit Sub

        lstMusicSongChanges.Items.Add(Math.Round(Player.controls.currentPosition, 2) & "|" & lstSongEditPresets.SelectedItem & "|" & numFadeOut.Value & "|" & numFadeIn.Value)
        'lstPresetsSongChanges.Items.Add(Player.controls.currentPosition & "|" & lstSongEditPresets.SelectedItem & "|" & numFadeOut.Value & "|" & numFadeIn.Value)
        ' lstDramaViewSongChanges.Items.Add(Player.controls.currentPosition & "|" & lstSongEditPresets.SelectedItem & "|" & numFadeOut.Value & "|" & numFadeIn.Value)
    End Sub

    Private Sub cmdEditSongOverwrite_Click(sender As Object, e As EventArgs) Handles cmdEditSongCopyNew.Click
        If lstSongEditPresets.SelectedIndex = -1 Then Exit Sub
        'If lstMusicSongChanges.SelectedIndex = -1 Then Exit Sub

        Dim defaultnewname As String = lstSongEditPresets.SelectedItem
        Dim newname As String = InputBox("Enter name of new Scene preset", , defaultnewname & " copy")
        If File.Exists(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstSongEditPresets.SelectedItem & ".dmr") = True Then
            If File.Exists(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & newname & ".dmr") = False Then
                File.Copy(Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstSongEditPresets.SelectedItem & ".dmr", Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & newname & ".dmr")
                lstSongEditPresets.Items.Add(newname)
                lstDramaPresets.Items.Add(newname)

                Dim I As Integer = 1
                Do Until I >= SceneData.Count
                    If SceneData(I).SceneName = "" Then
                        SceneData(I).SceneName = newname
                        SceneData(I).Automation = SceneData(GetSceneIndex(lstSongEditPresets.SelectedItem)).Automation
                        SceneData(I).ChannelValues = SceneData(GetSceneIndex(lstSongEditPresets.SelectedItem)).ChannelValues
                        'PresetFaders(I).cPresetName.Text = oldprefix & " | " & newname
                        Dim J As Integer = 1
                        Do Until Split(PresetFaders(J).cPresetName.Text, "| ")(1) = ""
                            J += 1
                            If J >= PresetFaders.Count Then Exit Do
                        Loop

                        If Val(PresetFaders(J).cTxtVal.Tag) = I Then
                            Dim oldprefix As String = PresetFaders(J).cPresetName.Text
                            cmbChannelPresetSelection.Items.Item(I - 1) = oldprefix & newname
                            PresetFaders(J).cPresetName.Text = oldprefix & newname

                            lstMusicSongChanges.Items.Add(Math.Round(Player.controls.currentPosition, 2) & "|" & newname & "|" & numFadeOut.Value & "|" & numFadeIn.Value)
                            lstPresetsSongChanges.Items.Add(Math.Round(Player.controls.currentPosition, 2) & "|" & newname & "|" & numFadeOut.Value & "|" & numFadeIn.Value)
                            lstDramaViewSongChanges.Items.Add(Math.Round(Player.controls.currentPosition, 2) & "|" & newname & "|" & numFadeOut.Value & "|" & numFadeIn.Value)
                            Exit Do
                        End If



                    End If
                    I += 1
                Loop


            End If

        End If

        'lstMusicSongChanges.Items.Item(lstMusicSongChanges.SelectedIndex) = Math.Round(Player.controls.currentPosition, 2) & "|" & lstSongEditPresets.SelectedItem & "|" & numFadeOut.Value & "|" & numFadeIn.Value
    End Sub

    Private Sub cmdEditSongSave_Click(sender As Object, e As EventArgs) Handles cmdEditSongSave.Click

        SongChanges1.Clear()
        FileOpen(1, Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstMusicSongs.SelectedItem & ".chg", OpenMode.Output)
        For Each S As String In lstMusicSongChanges.Items
            PrintLine(1, S)
            Dim NewSongChange As New SongChangesStr
            Dim a() As String = Split(S, "|")
            NewSongChange.TimeCode = a(0)
            NewSongChange.SceneName = a(1)
            NewSongChange.SceneIndex = GetSceneIndex(a(1))
            NewSongChange.TimeToGoUp = a(2)
            NewSongChange.TimeToGoDown = a(3)

            SongChanges1.Add(NewSongChange)
        Next S
        FileClose(1)
        Thread.Sleep(10)
        'lstSongs_SelectedIndexChanged(lstMusicSongs, e)


        Exit Sub

        'FileOpen(1, Application.StartupPath & "\Save Files\" & lstBanks.SelectedItem & "\" & lstPresetsSongs.SelectedItem & ".chg", OpenMode.Input)

        'Do Until EOF(1)
        '    Dim newline As String = LineInput(1)
        '    lstPresetsSongChanges.Items.Add(newline)
        '    lstMusicSongChanges.Items.Add(newline)
        '    lstDramaViewSongChanges.Items.Add(newline)



        'Loop

        ''Do Until EOF(1)
        ''    Dim a() As String = Split(LineInput(1), "|") 'time|Preset
        ''    Mp3Changes(I).Time = a(0)
        ''    Mp3Changes(I).PresetName = a(1)
        ''    I += 1
        ''Loop
        'FileClose(1)
    End Sub

    Private Sub lstMusicSongChanges_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstMusicSongChanges.SelectedIndexChanged
        If lstMusicSongChanges.SelectedIndex = -1 Then Exit Sub
        If chkEnableSongEdit.Checked = False Then Exit Sub
        If EditUpdate = True Then Exit Sub
        Dim a() As String = Split(lstMusicSongChanges.SelectedItem, "|")
        txtEditTime.Text = a(0)
        lstSongEditPresets.SelectedItem = a(1)
        numFadeOut.Value = a(2)
        numFadeIn.Value = a(3)

    End Sub
    Dim EditUpdate As Boolean = False
    Private Sub cmdEditUpdate_Click(sender As Object, e As EventArgs) Handles cmdEditUpdate.Click
        If chkEnableSongEdit.Checked = False Then Exit Sub
        If lstMusicSongChanges.SelectedIndex = -1 Then Exit Sub
        EditUpdate = True
        Dim a() As String = Split(lstMusicSongChanges.SelectedItem, "|")
        lstMusicSongChanges.Items(lstMusicSongChanges.SelectedIndex) = txtEditTime.Text & "|" & lstSongEditPresets.SelectedItem & "|" & numFadeIn.Value & "|" & numFadeOut.Value
        Application.DoEvents()
        EditUpdate = False
    End Sub

    Private Sub cmdColourTest_Click(sender As Object, e As EventArgs) Handles cmdColourTest.Click
        frmGradientColour.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        frmCustomColourPicker.ColorPicker2.Value = Color.Fuchsia
        frmCustomColourPicker.ShowDialog()
        'frmCustomColourPicker.ColorPicker2.Value.Name
    End Sub

    Private Sub ctxPickRGBColourTool_Click(sender As Object, e As EventArgs) Handles ctxPickRGBColourTool.Click
        Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)

        Dim ChNo As Integer = Mid(cms.SourceControl.Tag, GetIndexOfNumber(cms.SourceControl.Tag) + 1) 'Val(cms.SourceControl.Tag)
    End Sub

    Private Sub ctxFixtureLabelsControlName_Click(sender As Object, e As EventArgs) Handles ctxFixtureLabelsControlName.Click
        Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)

        MessageBox.Show(cms.SourceControl.Name)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Arduinos(0).Serial.Write("UID," & Arduinos(0).PortNo & vbCrLf)
    End Sub

    Private Sub cmdSerialClear_Click(sender As Object, e As EventArgs) Handles cmdSerialClear.Click
        txtSerialIn.Text = ""
    End Sub

    Private Sub ctxFixtureLabels_Opening(sender As Object, e As CancelEventArgs) Handles ctxFixtureLabels.Opening

        Dim parentitem As String = sender.SourceControl.Name.ToString

        'Dim myItem As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        'Dim cms As ContextMenuStrip = CType(myItem.Owner, ContextMenuStrip)

        'MessageBox.Show(cms.SourceControl.Name)
        LoadFixtureFavourites(Mid(parentitem, GetIndexOfNumber(parentitem) + 1))
    End Sub
    Public Function GetIndexOfNumber(ByVal str As String) As Integer

        For n As Integer = 0 To str.Length - 1

            If IsNumeric(str.Substring(n, 1)) Then

                Return n

            End If

        Next

        Return -1

    End Function
    Sub LoadFixtureFavourites(ByVal channel As Integer)

        Dim firstchan As Integer = channel - FixtureControls(channel).ChannelOfFixture + 1

        ctxFixtureFavourites.DropDownItems.Clear()
        Dim I As Integer = 0
        If Not FixtureControls(firstchan).Favourites Is Nothing Then

            Do Until I >= FixtureControls(firstchan).Favourites.Count
                If FixtureControls(firstchan).Favourites(I) Is Nothing Then Exit Do
                Dim newTT As New ToolStripMenuItem
                newTT.Text = FixtureControls(firstchan).Favourites(I)
                newTT.Name = firstchan
                newTT.Tag = firstchan
                ctxFixtureFavourites.DropDownItems.Add(newTT)
                AddHandler newTT.Click, AddressOf ctxFixtureFavouriteItem_Click
                I += 1

            Loop
        End If

    End Sub
    Private Sub ctxFixtureFavouriteItem_Click(sender As Object, e As EventArgs)
        Dim chno As Integer = sender.tag
        Dim Favname As String = sender.Text

        Dim iCurrentScene As Integer = 0
        Do Until iCurrentScene >= SceneData.Length
            If Split(cmbChannelPresetSelection.SelectedItem, "| ")(1) = SceneData(iCurrentScene).SceneName Then Exit Do
            iCurrentScene += 1
        Loop

        'MessageBox.Show(chno & vbCrLf & Favname)
        FileOpen(1, Application.StartupPath & "\Fixtures\" & FixtureControls(chno).FixtureName & "\" & Favname & ".dmr", OpenMode.Input)
        Do Until EOF(1)
            Dim a() As String = Split(LineInput(1), "|")
            Dim I As Integer = 0
            Do Until I >= a.Length
                Dim b() As String = Split(a(I), ",")
                Select Case b(0)

                    Case "v"
                        SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Value = b(1)
                        ChannelFaders(chno - 1 + a(0)).cFader.Value = b(1)
                    Case "TimerEnabled", "timerenabled"
                        SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Automation.tTimer.Enabled = Convert.ToBoolean(b(1))
                    Case "AutoTimeBetween"
                        SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Automation.tTimer.Interval = b(1)
                    Case "RandomStart"
                        SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Automation.ProgressRandomTimed = Convert.ToBoolean(b(1))
                    Case "InOrder"
                        SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Automation.ProgressInOrder = Convert.ToBoolean(b(1))
                    Case "RandomSound"
                        SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Automation.ProgressSoundActivated = Convert.ToBoolean(b(1))
                    Case "IsLooped"
                        SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Automation.ProgressLoop = Convert.ToBoolean(b(1))
                    Case "ProgressList"
                        If b.Length = 1 Then
                            'nothing in progress list
                        Else

                            For Each iList As String In b
                                If Not iList = "ProgressList" Then
                                    SceneData(iCurrentScene).ChannelValues(chno - 1 + a(0)).Automation.ProgressList.Add(Val(iList))
                                End If
                            Next
                        End If
                End Select

                I += 1
            Loop

        Loop
        FileClose(1)

    End Sub

End Class
